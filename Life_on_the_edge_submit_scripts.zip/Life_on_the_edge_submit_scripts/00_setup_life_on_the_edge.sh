#!/bin/bash                                                                                                                            
#SBATCH --job-name=setup_Life_on_the_edge
#SBATCH --mail-user=$YOUR_EMAIL
#SBATCH --mail-type=ALL
#SBATCH --chdir=$YOUR_WORK_DIR
#SBATCH --output=$YOUR_WORK_DIR/%x-%j.log
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=50G
#SBATCH --time=12:00:00 
 
#load environment
#source activate /gpfs0/global/apps/plink_1.90/

# using bioconductor_3.14.sif copied in my cluster account....
# user would simply download this file and then follow below to install r packages into the container

cd $YOUR_WORK_DIR
export R_LIBS_USER=$HOME/R/4.1.3:$R_LIBS_USER # link to local libs

# open singularity container
singularity shell $YOUR_WORK_DIR/bioconductor_3.14.sif #load container

# load R and install packages
R
install.packages(c('rnaturalearthdata','countrycode','CoordinateCleaner','rgeos','rgbif','dplyr','plyr','raster','rgdal','sp','maps','spThin','dismo','maptools','sdm','SDMtune','tidyverse','reshape2','ggplot2','ggpubr','usdm','SDMtune','rasterVis','plotROC','zeallot','kableExtra','LEA','adegenet','vegan','lfmm','qvalue','psych','stringr','robust','data.table','matlib','sf','tibble','reshape2','rworldmap','viridis','tmap','spatstat','gstat','grobblR'))
install.packages("BiocManager")
library(BiocManager)
BiocManager::install("qvalue", force=TRUE)
BiocManager::install("LEA", force=TRUE)

# terra
url <- 'https://cran.r-project.org/src/contrib/terra_1.7-3.tar.gz'
install.packages(url, repos=NULL, type="source")

# biomod2
url <- 'https://cran.r-project.org/src/contrib/biomod2_4.2-2.tar.gz'
install.packages(url, repos=NULL, type="source")