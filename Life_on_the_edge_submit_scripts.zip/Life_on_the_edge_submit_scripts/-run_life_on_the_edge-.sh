#!/bin/bash                                                                                                                            

cd $YOUR_SUBMIT_SCRIPTS_DIR/

# Each species as a separate job

for SPECIES in Afrixalus_fornasini Afrixalus_delicatus Afrixalus_sylvaticus; do
  sbatch -J LOE_$SPECIES ./01_run_life_on_the_edge.sh $SPECIES
done

