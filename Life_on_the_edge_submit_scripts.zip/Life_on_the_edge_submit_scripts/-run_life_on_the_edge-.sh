#!/bin/bash                                                                                                                            

cd $YOUR_SUBMIT_SCRIPTS_DIR/

#first setup
#sbatch 00_setup_life_on_the_edge.sh

# then each species as a separate job

#for SPECIES in Alytes_obstetricans Afrixalus_delicatus Afrixalus_sylvaticus Afrixalus_fornasini Arthroleptis_xenodactyloides Leptopelis_argenteus Leptopelis_concolor Leptopelis_flavomaculatus Salamandra_algira Salamandra_atra Salamandra_corsica Salamandra_salamandra Salamandra_infraimmaculata Rana_temporaria; do
#  sbatch -J LOE_$SPECIES ./01_run_life_on_the_edge.sh $SPECIES
#done

for SPECIES in Afrixalus_fornasini; do
  sbatch -J LOE_$SPECIES ./01_run_life_on_the_edge.sh $SPECIES
done

