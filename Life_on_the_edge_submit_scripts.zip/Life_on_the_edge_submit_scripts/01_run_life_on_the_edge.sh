#!/bin/bash                                                                                                                            
#SBATCH --job-name=LOE
#SBATCH --mail-user=$YOUR_EMAIL
#SBATCH --mail-type=ALL
#SBATCH --chdir=$YOUR_WORK_DIR
#SBATCH --output=$YOUR_WORK_DIR/%x-%j.log
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=100G
#SBATCH --time=720:00:00 
 
# load Julia
module purge
module load Julia/1.7.2-linux-x86_64
export JULIA_NUM_THREADS=1

#load Java
module load GCCcore/10.2.0
module load ANTLR/2.7.7-Java-11
export JVM_ARGS="-Xms100M -Xmx100G"

# chdir and export link to local libs to pickup R packages
cd ~/work/Life_on_the_edge_pipeline/
export R_LIBS_USER=$HOME/R/4.1.3:$R_LIBS_USER

# run the relevant parts of the LOE toolbox 
# Exposure (including data prep and SDMs)
singularity exec $YOUR_WORK_DIR/bioconductor_3.14.sif Rscript ./-scripts-/run_LOE_exposure.R $1; 

# run local adaptation simulations
singularity exec ~$YOUR_WORK_DIR/bioconductor_3.14.sif Rscript ./-scripts-/simulations/-00_parameter_exploration-.R $1; 
singularity exec $YOUR_WORK_DIR/bioconductor_3.14.sif Rscript ./-scripts-/simulations/-01_empirical_data-.R $1; 
singularity exec $YOUR_WORK_DIR/bioconductor_3.14.sif Rscript ./-scripts-/simulations/-02_randomise_data-.R $1; 
singularity exec $YOUR_WORK_DIR/bioconductor_3.14.sif Rscript ./-scripts-/simulations/-03_perform_simulations-.R $1; 
singularity exec $YOUR_WORK_DIR/bioconductor_3.14.sif Rscript ./-scripts-/simulations/-04_evaluate_significance-.R $1; 

# GEAs (LFMM, RDA)
singularity exec $YOUR_WORK_DIR/bioconductor_3.14.sif Rscript ./-scripts-/-LFMM-.R $1; 

# Sensitivity (individual categorisation, neutral, adaptive sensitivity)
singularity exec $YOUR_WORK_DIR/bioconductor_3.14.sif Rscript ./-scripts-/run_LOE_sensitivity.R $1

# Range shift potential
julia --startup-file=no '$YOUR_WORK_DIR/-outputs-/'$1'/Landscape_barriers/circuitscape/cumulative_circuitscape_layer.jl'
singularity exec $YOUR_WORK_DIR/bioconductor_3.14.sif Rscript ./-scripts-/run_LOE_landscape_barriers.R $1

# Population vulnerability and final outputs
singularity exec $YOUR_WORK_DIR/bioconductor_3.14.sif Rscript ./-scripts-/run_LOE_population_vulnerability.R $1

