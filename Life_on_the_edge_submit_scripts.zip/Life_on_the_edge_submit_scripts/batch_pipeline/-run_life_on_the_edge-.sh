#!/bin/bash                                                                                                                            

cd ~/submit_scripts/LOE_multispecies_synthesis_no_sims/batch_pipeline/

# 37 amphibians with good data (missing S. gabonicus)
for SPECIES in Afrixalus_delicatus Afrixalus_fornasini Afrixalus_sylvaticus Alytes_obstetricans Arthroleptis_xenodactyloides Bufotes_boulengeri Bufotes_cypriensis Bufotes_sitibundus Bufotes_turanensis Bufotes_viridis Chiromantis_rufescens Discoglossus_galganoi Discoglossus_pictus Discoglossus_scovazzi Hyla_carthaginiensis Hyla_meridionalis Hyla_savignyi Hyperolius_concolor Hyperolius_mitchelli Leptopelis_argenteus Leptopelis_concolor Leptopelis_flavomaculatus Leptopelis_macrotis Leptopelis_millsoni Leptopelis_rufus Pelodytes_atlanticus Pelodytes_ibericus Pelodytes_punctatus Salamandra_algira Salamandra_atra Salamandra_infraimmaculata Amnirana_albolabris Amnirana_amnicola Amnirana_lepus Conraua_crassipes Leptopelis_ocellatus Salamandra_salamandra; do
  sbatch -J LOE_$SPECIES ./01_run_life_on_the_edge.sh $SPECIES
done



# # 49 species with good data
# for SPECIES in Afrixalus_delicatus Afrixalus_fornasini Afrixalus_sylvaticus Alytes_obstetricans Amnirana_amnicola Amnirana_lepus Arthroleptis_xenodactyloides Bufotes_boulengeri Bufotes_cypriensis Bufotes_sitibundus Bufotes_turanensis Bufotes_viridis Chiromantis_rufescens Conraua_crassipes Discoglossus_galganoi Discoglossus_pictus Discoglossus_scovazzi Hyla_carthaginiensis Hyla_meridionalis Hyla_savignyi Hylomyscus_vulcanorum Hyperolius_concolor Hyperolius_mitchelli Leptopelis_argenteus Leptopelis_concolor Leptopelis_flavomaculatus Leptopelis_macrotis Leptopelis_millsoni Leptopelis_ocellatus Leptopelis_rufus Myotis_crypticus Myotis_escalerai Nanger_granti Pelodytes_atlanticus Pelodytes_ibericus Pelodytes_punctatus Plecotus_austriacus Salamandra_algira Salamandra_atra Salamandra_infraimmaculata Sylvisorex_mundus Sylvisorex_vulcanorum Amnirana_albolabris Bufotes_sitibundus Bufotes_viridis Rana_temporaria Vulpes_vulpes Afrixalus_paradorsalis Scotobleps_gabonicus; do
  # sbatch -J LOE_$SPECIES ./01_run_life_on_the_edge.sh $SPECIES
# done


# B turanensis H concolor