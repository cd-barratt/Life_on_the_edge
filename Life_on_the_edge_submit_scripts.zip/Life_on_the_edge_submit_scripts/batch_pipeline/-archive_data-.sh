#!/bin/bash       
                                                                                                                     
#SBATCH --job-name=archive
#SBATCH --mail-user=christopher_david.barratt@uni-leipzig.de
#SBATCH --mail-type=BEGIN,END,FAIL,TIME_LIMIT
#SBATCH --output=/work/barratt/life_on_the_edge/job_logs/%x-%j.log
#SBATCH --cpus-per-task=1 
#SBATCH --mem-per-cpu=50G
#SBATCH --time=360:00:00




# make archive directory
mkdir /data/life_on_the_edge/-archived_important-/archived_LOE_multispecies_synthesis/

cd ~/work/

cp -r ~/work/LOE_multispecies_synthesis/ ~/work/LOE_multispecies_synthesis_copy/

tar -zcvf /data/life_on_the_edge/-archived_important-/archived_LOE_multispecies_synthesis/archived_LOE_multispecies_synthesis.tgz ./LOE_multispecies_synthesis/


# to untar
# cd /data/life_on_the_edge/-archived_important-/archived_processed_genomic_data/
# tar -xzf /data/life_on_the_edge/-archived_important-/archived_processed_genomic_data/Plecotus_austriacus.tgz


