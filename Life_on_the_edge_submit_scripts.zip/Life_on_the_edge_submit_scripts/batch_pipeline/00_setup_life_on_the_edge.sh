#!/bin/bash                                                                                                                            
#SBATCH --job-name=setup_Life_on_the_edge
#SBATCH --mail-user=christopher_david.barratt@uni-leipzig.de
#SBATCH --mail-type=ALL
#SBATCH --chdir=/work/barratt
#SBATCH --output=/work/barratt/LOE_multispecies_synthesis_no_sims/%x-%j.log
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=50G
#SBATCH --time=12:00:00 
 

#load environment
#source activate /gpfs0/global/apps/plink_1.90/

# using bioconductor_3.14.sif copied in my cluster account....
# user would simply download this file and then follow below to install r packages into the container

cd ~/work/LOE_multispecies_synthesis_no_sims/
export R_LIBS_USER=$HOME/R/4.1.3:$R_LIBS_USER # link to local libs

# load R within container and install packages
singularity shell ~/barratt_software/Singularity_container/bioconductor_3.14.sif
R
## clear all packages (recommended for fresh install)
pkgs <- installed.packages()[, "Package"]
remove.packages(pkgs)

# Load the CSV file (if applicable)
packages <- read.csv("~/submit_scripts/LOE_multispecies_synthesis/batch_pipeline/all_R_packages_list.csv", sep = '	')

# install devtools
install.packages('devtools')

# Install each package with its specific version from the csv file above
for (i in 1:nrow(packages)) {
  devtools::install_version(packages$package[i], version = packages$version[i])
}
# say 3 ('None') every time

install.packages("BiocManager")
library(BiocManager)
BiocManager::install("qvalue", force=TRUE)
BiocManager::install("LEA", force=TRUE)

# terra
url <- 'https://cran.r-project.org/src/contrib/Archive/terra/terra_1.7-3.tar.gz'
install.packages(url, repos=NULL, type="source")

# biomod2 
install.packages(c('mda', 'pROC', 'PresenceAbsence', 'earth'))
url <- 'https://cran.r-project.org/src/contrib/Archive/biomod2/biomod2_4.2-2.tar.gz'
install.packages(url, repos=NULL, type="source")
