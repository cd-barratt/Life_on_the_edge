## Run lfmm to find adaptive SNPs

rm(list=ls(all=TRUE))

# Load packages, set some directories
library(lfmm)         #?lfmm_ridge  # we use the 'ridge penalty' for GEA
library(vegan)        # all things ordination (RDA, dbRDA, PCA, etc.) & more!
library(qvalue)       # false discovery rate calculation
library(psych)        # nice pair plots
library(usdm)         # calculates variance inflation factors
library(adegenet)     # for reading plink files
library(stringr)

root_dir <- ('$YOUR_WORK_DIR')
setwd(root_dir)

genomic_data_path <- './-data-/genomic_data/'
spatial_data_path <- './-data-/spatial_data/'

colours <- c('#ff7f00','#1f78b4','#ffff33','#a6cee3','#33a02c','#e31a1c')

# read args
args <- commandArgs()
print(args)
species_binomial <- args[8]

# set params file
params_all <- read.delim('./Params.tsv')

# Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
params <- params_all[which(params_all$species_binomial==species_binomial),]
species_binomial <- params$species_binomial
  
log_file <- paste0('./-outputs-/log_files/',species_binomial,'.log')
sensitivity_path <- paste0('./-outputs-/',species_binomial,'/Sensitivity/')
dir.create(paste0(sensitivity_path))
output_path <- paste0(sensitivity_path,'Adaptive_sensitivity/')
dir.create(paste0(output_path))

if ((params$skip_gea=='yes')) {
 cat('--------------------------------------------------------------\n', file=log_file, append=T)
 cat('Skipping identifying adaptive loci using LFMM as requested...', '\n', file=log_file, append=T)
 cat('--------------------------------------------------------------\n', file=log_file, append=T)

}else{
  
cat('--------------------------------------------------------------\n', file=log_file, append=T)
cat('Running LFMM (Latent Factor Mixed Models)...\n', file=log_file, append=T)
cat('--------------------------------------------------------------\n', file=log_file, append=T)
##########
# Document correlations of predictor variables (for all Genotype-Environment Association analyses)
cat('> Assessing correlations of predictor variables...\n', file=file.path(log_file), append=T)

#read the data that is extracted automatically from your predictor variables
env <- read.csv(paste0(spatial_data_path,species_binomial,'/',species_binomial,'_full_env_data.csv'))
env <- env[,c(params$env_predictor_1,params$env_predictor_2)] # subset env vars of interest tfor local adaptation analyses

# Look at correlations in predictors before we go on 
png(filename=paste0(output_path,species_binomial,'_env_correlations.png'), 
    type='cairo', units='cm', width=30, height=30, pointsize=12, res=300)
par(cex.main=2, cex.axis=2)
pairs.panels(env, scale=T, cex.cor=2)  # see ?pairs.panels for a description of these biplots
dev.off()
# correlation coefficients are in the upper right diagonal, with their size scaled to the value of |r|
vif(env) # check variance inflation factors, which assess multicollinearity, VIFs > 10 may be problematic; VIFs < 5 mean multicollinearity shouldn't be a problem

# Decide which predictor to cut if needed (change 'X' to the column of the predictor to remove)
# env <- env[ ,c(-4)] 
cat('> Correlations of predictor variables checked and completed...\n', file=file.path(log_file), append=T)
cat('> Variance Inflation Factors for variables are: ', vif(env)$VIF,'\n', file=log_file, append=T)
cat('>>> Output correlation data saved and plotted \n\n', file=log_file, append=T)

#######
cat('> Running LFMM (Latent Factor Mixed Models)...\n', file=log_file, append=T)
##########
# LFMM - detection of adaptive SNPs

# Read in genomic data
gen <- read.table(paste0(genomic_data_path,species_binomial,'/',species_binomial,'_imp.lfmm'), header = FALSE) # read in lfmm file that was imputed in snmf

# Rename the SNPs names to match across all GEA analyses (LFMM, RDA and PCAdapt)
species_binomial.genlight <- read.PLINK(paste0(genomic_data_path,species_binomial,'/',species_binomial,'.raw'), map.file = paste0(genomic_data_path,species_binomial,'/',species_binomial,'.map'),
                                        quiet = FALSE, chunkSize = 1000, parallel = FALSE, n.cores = NULL)
features <- species_binomial.genlight@loc.names
colnames(gen) <- features
gen[1:6,1:10]  # Have a quick look: these are diploids (coded 0 or 1 or 2)
dim(gen)       # Individuals in rows, SNPs in columns  
 
cat('** WARNING: Decision needed for number of populations...\n\n', file=file.path(log_file), append=T)
cat('> Evaluate sNMF and PCA population structure outputs to define K\n', file=file.path(log_file), append=T)

K <- params$k
# your decision(S) for K here, this should be informed by the population structure analyses (sNMF and PCA)
# If K is ambiguous then you could run multiple times for different K values and look for overlap
# But may be useful for data where IBD is prevalent rather than discrete pop structure

# LFMM identify candidate SNPs
species_binomial.lfmm <- lfmm_ridge(Y=gen, X=env, K=K) # k defined based on pop structure results

# Built in function to calculate test statistics for all predictors:
pv <- lfmm_test(Y=gen, X=env, lfmm=species_binomial.lfmm, calibrate='gif')

# The GIFs for the predictors 
# 1=well calibrated, >1=liberal (too many small p-values), <1=conservative (too few small p-values)
# If GIFs are above high (e.g. >2), you can try increasing K
pv$gif 
names(pv)                  # automatically applies the gif to the zscores and pvalues
head(pv$pvalue)            # unadjusted p-values for our predictors
head(pv$calibrated.pvalue) # adjusted p-values for our predictors


# Below needs to be done for each predictor
# So this has been looped based on the number of predictors in the env dataframe
n <- ncol(env) # n=number of predictprs

for (i in 1:(n)) {
predictor <- i
par(mfrow=c(2,1))
hist(pv$pvalue[,predictor], main='unadjusted p-values')        
hist(pv$calibrated.pvalue[,predictor], main='adjusted p-values')
par(mfrow=c(1,1))

# The default adjustment looks too conservative (the distribution is too flat).
# Let's change the GIF and readjust the p-values:
head(pv$score) # the zscores (test statistic) are stored in pv$score
zscore <- pv$score[,predictor] # zscores 
(gif <- pv$gif[predictor])     # default GIF for this predictor

cat('> Predictor variable', names(env[i]), '...\n', file=file.path(log_file), append=T)
cat('> Calculated GIF for predictor variable',names(env[i]),' is: ',gif,'\n', file=file.path(log_file), append=T)
cat('** WARNING: Examine the unadjusted vs. adjusted p-values, if adjustment is too conservative (distribution is too flat, increase the GIF...)\n', file=file.path(log_file), append=T)

scale_gif <- params$scale_gif_lfmm
new.gif <- (gif*scale_gif)               # choose/change your modified GIF
cat('> Updated GIF is: ',new.gif,' (original GIF*',scale_gif,')\n', file=file.path(log_file), append=T)

# Manual adjustment:
adj.pv <- pchisq(zscore^2/new.gif, df=1, lower = FALSE)

png(filename=paste0(output_path,species_binomial,'_LFMM_p_value_distribution_',names(env[i]),'.png'), 
    type='cairo', units='cm', width=30, height=30, pointsize=12, res=300)
par(mar=c(5,3,3,3))
par(cex.main=2, cex.axis=1.5)
par(mfrow=c(3,1))
hist(pv$pvalue[,predictor], main='unadjusted p-values', cex.axis=2, cex.lab=2)        
hist(pv$calibrated.pvalue[,predictor], main='adjusted p-values', cex.axis=2, cex.lab=2)
hist(adj.pv, main='REadjusted p-values', cex.axis=2, cex.lab=2)
dev.off()
cat('>>> Output summary of adjusted vs. unadjusted p-values plotted \n', file=file.path(log_file), append=T)


png(filename=paste0(output_path,species_binomial,'_LFMM_Manhattan_plot.png'), 
    type='cairo', units='cm', width=30, height=20, pointsize=12, res=300)
#par(mar=c(10,3,10,3))
par(mfrow=c(1,1))
plot(-log10(adj.pv), pch=19, cex=0.5, xlab='SNP',ylab='-log10(p-values)',col='navy', cex.lab=1, cex.axis=1)
#abline(h=3.5, lty=2, lwd=1.2, col='red')
dev.off()
cat('>>> Output Manhattan plot of adjusted p-values saved...\n', file=file.path(log_file), append=T)

# Proceed if you're happy with the new distribution, or tweak some more...
par(mfrow=c(1,1))

# Choosing a FDR (False Discovery Rate) cutoff
# qvalues and FDR 0.1 cutoff for env predictors 1:n
lhs1 <- paste('lfmm.qval', names(env[i]), sep='')
rhs1 <- paste ('qvalue(adj.pv)$qvalues')
eq1  <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))
  
lhs2 <- paste('(length(lFDR.1')
rhs2 <- paste0('which(lfmm.qval',names(env[i]),'< 0.1)))')
eq2  <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
eval(parse(text=eq2))

lhs3 <- paste0('lfmm.FDR.1.env',names(env[i]),sep='')
rhs3 <- paste('colnames(gen)[lFDR.1]')
eq3  <- paste(paste(lhs3, rhs3, sep=' <- '), collapse='; ')
eval(parse(text=eq3))

eval(parse(text=lhs3))

# qvalues and FDR 0.05 cutoff for env predictors 1:n
lhs4 <- paste('lfmm.qval', names(env[i]), sep='')
rhs4 <- paste ('qvalue(adj.pv)$qvalues')
eq4  <- paste(paste(lhs4, rhs4, sep=' <- '), collapse='; ')
eval(parse(text=eq4))

lhs5 <- paste('(length(lFDR.05')
rhs5 <- paste0('which(lfmm.qval',names(env[i]),'< 0.05)))')
eq5  <- paste(paste(lhs5, rhs5, sep=' <- '), collapse='; ')
eval(parse(text=eq5))

lhs6 <- paste0('lfmm.FDR.05.env',names(env[i]),sep='')
rhs6 <- paste('colnames(gen)[lFDR.05]')
eq6  <- paste(paste(lhs6, rhs6, sep=' <- '), collapse='; ')
eval(parse(text=eq6))

eval(parse(text=lhs3))

# qvalues and FDR 0.01 cutoff for env predictors 1:n
lhs7 <- paste('lfmm.qval', names(env[i]), sep='')
rhs7 <- paste ('qvalue(adj.pv)$qvalues')
eq7  <- paste(paste(lhs7, rhs7, sep=' <- '), collapse='; ')
eval(parse(text=eq7))

lhs8 <- paste('(length(lFDR.01')
rhs8 <- paste0('which(lfmm.qval',names(env[i]),'< 0.01)))')
eq8  <- paste(paste(lhs8, rhs8, sep=' <- '), collapse='; ')
eval(parse(text=eq8))

lhs9 <- paste0('lfmm.FDR.01.env',names(env[i]),sep='')
rhs9 <- paste('colnames(gen)[lFDR.01]')
eq9  <- paste(paste(lhs9, rhs9, sep=' <- '), collapse='; ')
eval(parse(text=eq9))
eval(parse(text=lhs9))

list <- list((eval(parse(text=lhs3))),(eval(parse(text=lhs6))),(eval(parse(text=lhs9))))
lhs10 <- paste0('all_candidates_predictor_', names(env[i]), sep='')
rhs10 <- paste0("sapply(list, '[', 1:length(list[[1]]))")
eq10  <- paste(paste(lhs10, rhs10, sep=' <- '), collapse='; ')
eval(parse(text=eq10))


# check the all_candidates_predictor file actually has data in it, otherwise make a dummy row
length_predictor_candidates <- eval(parse(text=paste0('nrow(all_candidates_predictor_', names(env[i]),')')))
if(is.numeric(length_predictor_candidates)=='FALSE') # ie it is 'NULL'
{
# add dummy row if required and rename the columns
lhs10.1 <- lhs10
rhs10.1 <- paste0('cbind(0,0,0)')
eq10.1  <- paste(paste(lhs10.1, rhs10.1, sep=' <- '), collapse='; ')
eval(parse(text=eq10.1))
# Write out the candidate SNPs to file
# all candidates by environmental predictor
# we here generalise the code
# grab all_candidates_predictor_* names (however many there may be for each species)
lhs10.2 <- paste0('colnames(all_candidates_predictor_', names(env[i]), ')', sep='')
rhs10.2 <- paste0('c(lfmm.FDR.1.env',names(env[i]),',','lfmm.FDR.05.env',names(env[i]),',','lfmm.FDR.01.env',names(env[i]),')')
rhs10.2 <- gsub("lfmm","'lfmm",rhs10.2)
rhs10.2 <- gsub(",","',",rhs10.2)
rhs10.2 <- gsub(")","')",rhs10.2)
eq10.2  <- paste(paste(lhs10.2, rhs10.2, sep=' <- '), collapse='; ')
eval(parse(text=eq10.2))
}else 
{ 
# Write out the candidate SNPs to file
# all candidates by environmental predictor
# we here generalise the code
# grab all_candidates_predictor_* names (however many there may be for each species)
lhs10.2 <- paste0('colnames(all_candidates_predictor_', names(env[i]), ')', sep='')
rhs10.2 <- paste0('c(lfmm.FDR.1.env',names(env[i]),',','lfmm.FDR.05.env',names(env[i]),',','lfmm.FDR.01.env',names(env[i]),')')
rhs10.2 <- gsub("lfmm","'lfmm",rhs10.2)
rhs10.2 <- gsub(",","',",rhs10.2)
rhs10.2 <- gsub(")","')",rhs10.2)
eq10.2  <- paste(paste(lhs10.2, rhs10.2, sep=' <- '), collapse='; ')
eval(parse(text=eq10.2))
}

}

list_of_all_candidates_predictors <- mget(ls(.GlobalEnv, pattern = "all_candidates_predictor_"))
lhs10.3 <- names(list_of_all_candidates_predictors)
lhs10.3 <- toString(lhs10.3)

# column bind the FDR results above (0.1, 0.05, 0.01) for each predictor into a single dataframe 
# Finding maximum length
pred_1 <- names(list_of_all_candidates_predictors[1])
pred_2 <- names(list_of_all_candidates_predictors[2])
max_ln <- max(c(length(eval(parse(text=pred_1))), length((eval(parse(text=pred_2))))))

# filling and binding (base R)
lhs10.5 <- paste0('all_candidates_by_all_predictors', sep='')
rhs10.5 <- paste0("data.frame(col1 = c(",pred_1,"[,1],rep(NA, max_ln - length(",pred_1,"[,1]))),
                                               col2 = c(",pred_1,"[,2],rep(NA, max_ln - length(",pred_1,"[,2]))),
                                               col3 = c(",pred_1,"[,3],rep(NA, max_ln - length(",pred_1,"[,3]))),
                                               col4 = c(",pred_2,"[,1],rep(NA, max_ln - length(",pred_2,"[,1]))),
                                               col5 = c(",pred_2,"[,2],rep(NA, max_ln - length(",pred_2,"[,2]))),
                                               col6 = c(",pred_2,"[,3],rep(NA, max_ln - length(",pred_2,"[,3]))))")
eq10.5  <- paste(paste(lhs10.5, rhs10.5, sep=' <- '), collapse='; ')
eval(parse(text=eq10.5))

# add the column names
colnames_pred_1 <- eval(parse(text=(paste0('colnames(',pred_1,')'))))
colnames_pred_2 <- eval(parse(text=(paste0('colnames(',pred_2,')'))))
colnames(all_candidates_by_all_predictors) <- c(colnames_pred_1,colnames_pred_2)

#finally write out the files
write.csv(all_candidates_by_all_predictors, paste0(output_path,species_binomial,'_LFMM_candidate_SNPs_by_predictor.csv'))
cat('>>> Output candidate SNPs by predictor saved \n', file=file.path(log_file), append=T)

# Bind all candidates by FDR cutoff (merge candidates across predictors)
all_candidates_by_all_predictors <- read.csv(paste0(output_path,species_binomial,'_LFMM_candidate_SNPs_by_predictor.csv'))
FDR.1 <- all_candidates_by_all_predictors[ , grepl( "FDR.1" , names( all_candidates_by_all_predictors ) ) ]
FDR.05 <- all_candidates_by_all_predictors[ , grepl( "FDR.05" , names( all_candidates_by_all_predictors ) ) ]
FDR.01 <- all_candidates_by_all_predictors[ , grepl( "FDR.01" , names( all_candidates_by_all_predictors ) ) ]

#FDR.1
lhs1 <- paste0('predictor_',1:n)
rhs1 <- paste0('as.data.frame(FDR.1[,', 1:n,']);colnames(predictor_',1:n,")=''", sep='')
eq1  <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))
lhs1 <- toString(lhs1)
lhs2 <- paste0('FDR.1')
rhs2 <- paste0('rbind(',lhs1,')')
eq2  <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
eval(parse(text=eq2))
FDR.1 <- na.omit(FDR.1)
colnames(FDR.1) <- 'LFMM.FDR.1'

#FDR.05
lhs1 <- paste0('predictor_',1:n)
rhs1 <- paste0('as.data.frame(FDR.05[,', 1:n,']);colnames(predictor_',1:n,")=''", sep='')
eq1  <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))
lhs1 <- toString(lhs1)
lhs2 <- paste0('FDR.05')
rhs2 <- paste0('rbind(',lhs1,')')
eq2  <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
eval(parse(text=eq2))
FDR.05 <- na.omit(FDR.05)
colnames(FDR.05) <- 'LFMM.FDR.05'

#FDR.01
lhs1 <- paste0('predictor_',1:n)
rhs1 <- paste0('as.data.frame(FDR.01[,', 1:n,']);colnames(predictor_',1:n,")=''", sep='')
eq1  <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))
lhs1 <- toString(lhs1)
lhs2 <- paste0('FDR.01')
rhs2 <- paste0('rbind(',lhs1,')')
eq2  <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
eval(parse(text=eq2))
FDR.01 <- na.omit(FDR.01)
colnames(FDR.01) <- 'LFMM.FDR.01'

# column bind the FDR results above (0.1, 0.05, 0.01) for each predictor into a single dataframe 
# Finding maximum length
max_ln <- max(c(length(eval(parse(text=FDR.1))), length(eval(parse(text=FDR.05))), length(eval(parse(text=FDR.01)))))
# filling and binding (base R)
lhs10.6 <- paste0('all_candidates', sep='')
rhs10.6 <- paste0("data.frame(col1 = c(",FDR.1,",rep(NA, max_ln - length(",FDR.1,"))),
                                               col2 = c(",FDR.05,",rep(NA, max_ln - length(",FDR.05,"))),
                                               col3 = c(",FDR.01,",rep(NA, max_ln - length(",FDR.01,"))))")
eq10.6  <- paste(paste(lhs10.6, rhs10.6, sep=' <- '), collapse='; ')
eval(parse(text=eq10.6))
colnames(all_candidates) <- c('LFMM.FDR.1', 'LFMM.FDR.05','LFMM.FDR.01')

write.csv(all_candidates, paste0(output_path,species_binomial,'_LFMM_candidate_SNPs.csv'))

cat('>>> Output candidate SNPs (merged) saved \n', file=file.path(log_file), append=T)
cat('>>> Candidate SNPs FDR<0.1:', nrow(FDR.1),'\n', file=file.path(log_file), append=T)
cat('>>> Candidate SNPs FDR<0.05:', nrow(FDR.05),'\n', file=file.path(log_file), append=T)
cat('>>> Candidate SNPs FDR<0.01:', nrow(FDR.01),'\n', file=file.path(log_file), append=T)
cat('> LFMM analysis completed successfully...\n\n', file=file.path(log_file), append=T)

setwd('./-scripts-/')

}


  
