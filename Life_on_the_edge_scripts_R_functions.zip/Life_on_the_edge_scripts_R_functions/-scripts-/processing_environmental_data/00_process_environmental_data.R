rm(list=ls(all=TRUE))

library(raster)

setwd('$YOUR_WORK_DIR')

# for the three GCMs downloaded, strip out the 19 bands to write separate raster files for each variable

# 30s
# HadGEM3-GC31-LL
bioclim_HadGEM3 <- stack('./30s/worldclim_2.1/future/wc2.1_30s_bioc_HadGEM3-GC31-LL_ssp585_2061-2080.tif')
filenames <- c('../environmental_data_processed/hi_res_geodata_processed/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_01.tif', '../hi_res_geodata_processed/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_02.tif', '../hi_res_geodata_processed/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_03.tif', '../hi_res_geodata_processed/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_04.tif', '../hi_res_geodata_processed/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_05.tif', '../hi_res_geodata_processed/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_06.tif', '../hi_res_geodata_processed/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_07.tif', '../hi_res_geodata_processed/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_08.tif', '../hi_res_geodata_processed/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_09.tif', '../hi_res_geodata_processed/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_10.tif', '../hi_res_geodata_processed/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_11.tif', '../hi_res_geodata_processed/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_12.tif', '../hi_res_geodata_processed/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_13.tif', '../hi_res_geodata_processed/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_14.tif', '../hi_res_geodata_processed/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_15.tif', '../hi_res_geodata_processed/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_16.tif', '../hi_res_geodata_processed/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_17.tif', '../hi_res_geodata_processed/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_18.tif', '../hi_res_geodata_processed/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_19.tif')
writeRaster(bioclim_HadGEM3, filename=filenames, bylayer=TRUE)
 # IPSL-CM6A-LR
bioclim_IPSL <- stack('./30s/worldclim_2.1/future/wc2.1_30s_bioc_IPSL-CM6A-LR_ssp585_2061-2080.tif')
filenames <- c('../environmental_data_processed/30s/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_01.tif', '../environmental_data_processed/30s/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_02.tif', '../environmental_data_processed/30s/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_03.tif', '../environmental_data_processed/30s/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_04.tif', '../environmental_data_processed/30s/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_05.tif', '../environmental_data_processed/30s/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_06.tif', '../environmental_data_processed/30s/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_07.tif', '../environmental_data_processed/30s/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_08.tif', '../environmental_data_processed/30s/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_09.tif', '../environmental_data_processed/30s/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_10.tif', '../environmental_data_processed/30s/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_11.tif', '../environmental_data_processed/30s/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_12.tif', '../environmental_data_processed/30s/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_13.tif', '../environmental_data_processed/30s/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_14.tif', '../environmental_data_processed/30s/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_15.tif', '../environmental_data_processed/30s/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_16.tif', '../environmental_data_processed/30s/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_17.tif', '../environmental_data_processed/30s/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_18.tif', '../environmental_data_processed/30s/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_19.tif')
writeRaster(bioclim_IPSL, '../environmental_data_processed/30s/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim.tif', bylayer=TRUE, suffix='numbers')
# MPI-ESM1-2-LR
bioclim_MPI <- stack('./30s/worldclim_2.1/future/wc2.1_30s_bioc_MPI-ESM1-2-LR_ssp585_2061-2080.tif')
filenames <- c('../hi_res_geodata_processed/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_01.tif', '../hi_res_geodata_processed/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_02.tif', '../hi_res_geodata_processed/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_03.tif', '../hi_res_geodata_processed/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_04.tif', '../hi_res_geodata_processed/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_05.tif', '../hi_res_geodata_processed/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_06.tif', '../hi_res_geodata_processed/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_07.tif', '../hi_res_geodata_processed/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_08.tif', '../hi_res_geodata_processed/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_09.tif', '../hi_res_geodata_processed/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_10.tif', '../hi_res_geodata_processed/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_11.tif', '../hi_res_geodata_processed/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_12.tif', '../hi_res_geodata_processed/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_13.tif', '../hi_res_geodata_processed/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_14.tif', '../hi_res_geodata_processed/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_15.tif', '../hi_res_geodata_processed/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_16.tif', '../hi_res_geodata_processed/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_17.tif', '../hi_res_geodata_processed/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_18.tif', '../hi_res_geodata_processed/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_19.tif')
writeRaster(bioclim_MPI, '../hi_res_geodata_processed/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim.tif', bylayer=TRUE, suffix='numbers')


# resample the 30s layers down to match other lower resolutions
# 2.5min
# template
template <- raster('../environmental_data_raw/2.5min/worldclim_2.1/current/wc2.1_2.5m_elev.tif')

# current
bio1_30s <- raster('../environmental_data_processed/30s/current/bioclim_01.tif')
#bio1_2.5min <- resample(bio1_30s,template)
#writeRaster(bio1_2.5min,'../environmental_data_processed/2.5min/current/bioclim_01.tif')
bio2_30s <- raster('../environmental_data_processed/30s/current/bioclim_02.tif')
#bio2_2.5min <- resample(bio2_30s,template)
#writeRaster(bio2_2.5min,'../environmental_data_processed/2.5min/current/bioclim_02.tif')
bio3_30s <- raster('../environmental_data_processed/30s/current/bioclim_03.tif')
#bio3_2.5min <- resample(bio3_30s,template)
#writeRaster(bio3_2.5min,'../environmental_data_processed/2.5min/current/bioclim_03.tif')
bio4_30s <- raster('../environmental_data_processed/30s/current/bioclim_04.tif')
#bio4_2.5min <- resample(bio4_30s,template)
#writeRaster(bio4_2.5min,'../environmental_data_processed/2.5min/current/bioclim_04.tif')
bio5_30s <- raster('../environmental_data_processed/30s/current/bioclim_05.tif')
#bio5_2.5min <- resample(bio5_30s,template)
#writeRaster(bio5_2.5min,'../environmental_data_processed/2.5min/current/bioclim_05.tif')
bio6_30s <- raster('../environmental_data_processed/30s/current/bioclim_06.tif')
#bio6_2.5min <- resample(bio6_30s,template)
#writeRaster(bio6_2.5min,'../environmental_data_processed/2.5min/current/bioclim_06.tif')
bio7_30s <- raster('../environmental_data_processed/30s/current/bioclim_07.tif')
#bio7_2.5min <- resample(bio7_30s,template)
#writeRaster(bio7_2.5min,'../environmental_data_processed/2.5min/current/bioclim_07.tif')
bio8_30s <- raster('../environmental_data_processed/30s/current/bioclim_08.tif')
#bio8_2.5min <- resample(bio8_30s,template)
#writeRaster(bio8_2.5min,'../environmental_data_processed/2.5min/current/bioclim_08.tif')
bio9_30s <- raster('../environmental_data_processed/30s/current/bioclim_09.tif')
#bio9_2.5min <- resample(bio9_30s,template)
#writeRaster(bio9_2.5min,'../environmental_data_processed/2.5min/current/bioclim_09.tif')
bio10_30s <- raster('../environmental_data_processed/30s/current/bioclim_10.tif')
#bio10_2.5min <- resample(bio10_30s,template)
#writeRaster(bio10_2.5min,'../environmental_data_processed/2.5min/current/bioclim_10.tif')
bio11_30s <- raster('../environmental_data_processed/30s/current/bioclim_11.tif')
#bio11_2.5min <- resample(bio11_30s,template)
#writeRaster(bio11_2.5min,'../environmental_data_processed/2.5min/current/bioclim_11.tif')
bio12_30s <- raster('../environmental_data_processed/30s/current/bioclim_12.tif')
#bio12_2.5min <- resample(bio12_30s,template)
#writeRaster(bio12_2.5min,'../environmental_data_processed/2.5min/current/bioclim_12.tif')
bio13_30s <- raster('../environmental_data_processed/30s/current/bioclim_13.tif')
3bio13_2.5min <- resample(bio13_30s,template)
#writeRaster(bio13_2.5min,'../environmental_data_processed/2.5min/current/bioclim_13.tif')
bio14_30s <- raster('../environmental_data_processed/30s/current/bioclim_14.tif')
#bio14_2.5min <- resample(bio14_30s,template)
#writeRaster(bio14_2.5min,'../environmental_data_processed/2.5min/current/bioclim_14.tif')
bio15_30s <- raster('../environmental_data_processed/30s/current/bioclim_15.tif')
#bio15_2.5min <- resample(bio15_30s,template)
#writeRaster(bio15_2.5min,'../environmental_data_processed/2.5min/current/bioclim_15.tif')
bio16_30s <- raster('../environmental_data_processed/30s/current/bioclim_16.tif')
#bio16_2.5min <- resample(bio16_30s,template)
#writeRaster(bio16_2.5min,'../environmental_data_processed/2.5min/current/bioclim_16.tif')
bio17_30s <- raster('../environmental_data_processed/30s/current/bioclim_17.tif')
#bio17_2.5min <- resample(bio17_30s,template)
#writeRaster(bio17_2.5min,'../environmental_data_processed/2.5min/current/bioclim_17.tif')
bio18_30s <- raster('../environmental_data_processed/30s/current/bioclim_18.tif')
#bio18_2.5min <- resample(bio18_30s,template)
#writeRaster(bio18_2.5min,'../environmental_data_processed/2.5min/current/bioclim_18.tif')
bio19_30s <- raster('../environmental_data_processed/30s/current/bioclim_19.tif')
#bio19_2.5min <- resample(bio19_30s,template)
#writeRaster(bio19_2.5min,'../environmental_data_processed/2.5min/current/bioclim_19.tif')

# current 2.5 min
bio_current_30s <- stack(bio1_30s,bio2_30s,bio3_30s,bio4_30s,bio5_30s,bio6_30s,bio7_30s,bio8_30s,bio9_30s,bio10_30s,bio11_30s,bio12_30s,bio13_30s,bio14_30s,bio15_30s,bio16_30s,bio17_30s,bio18_30s,bio19_30s)
bio_current_2.5min <- resample(bio_current_30s,template)
filenames <- c('../environmental_data_processed/2.5min/current/bioclim_01.tif', '../environmental_data_processed/2.5min/current/bioclim_02.tif', '../environmental_data_processed/2.5min/current/bioclim_03.tif', '../environmental_data_processed/2.5min/current/bioclim_04.tif', '../environmental_data_processed/2.5min/current/bioclim_05.tif', '../environmental_data_processed/2.5min/current/bioclim_06.tif', '../environmental_data_processed/2.5min/current/bioclim_07.tif', '../environmental_data_processed/2.5min/current/bioclim_08.tif', '../environmental_data_processed/2.5min/current/bioclim_09.tif', '../environmental_data_processed/2.5min/current/bioclim_10.tif', '../environmental_data_processed/2.5min/current/bioclim_11.tif', '../environmental_data_processed/2.5min/current/bioclim_12.tif', '../environmental_data_processed/2.5min/current/bioclim_13.tif', '../environmental_data_processed/2.5min/current/bioclim_14.tif', '../environmental_data_processed/2.5min/current/bioclim_15.tif', '../environmental_data_processed/2.5min/current/bioclim_16.tif', '../environmental_data_processed/2.5min/current/bioclim_17.tif', '../environmental_data_processed/2.5min/current/bioclim_18.tif', '../environmental_data_processed/2.5min/current/bioclim_19.tif')
writeRaster(bio_current_2.5min, '../environmental_data_processed/2.5min/current/bioclim.tif', bylayer=TRUE, suffix='numbers')
elevation_30s <- raster('../environmental_data_processed/30s/current/elevation.tif')
elevation_2.5min <- resample(elevation_30s,template)
writeRaster(elevation_2.5min,'../environmental_data_processed/2.5min/current/elevation.tif')
land_cover_30s <- raster('../environmental_data_processed/30s/current/land_cover.tif')
land_cover_2.5min <- resample(land_cover_30s,template)
writeRaster(land_cover_2.5min,'../environmental_data_processed/2.5min/current/land_cover.tif')

# current 10 min
bio_current_30s <- stack(bio1_30s,bio2_30s,bio3_30s,bio4_30s,bio5_30s,bio6_30s,bio7_30s,bio8_30s,bio9_30s,bio10_30s,bio11_30s,bio12_30s,bio13_30s,bio14_30s,bio15_30s,bio16_30s,bio17_30s,bio18_30s,bio19_30s)
bio_current_10min <- resample(bio_current_30s,template)
filenames <- c('../environmental_data_processed/10min/current/bioclim_01.tif', '../environmental_data_processed/10min/current/bioclim_02.tif', '../environmental_data_processed/10min/current/bioclim_03.tif', '../environmental_data_processed/10min/current/bioclim_04.tif', '../environmental_data_processed/10min/current/bioclim_05.tif', '../environmental_data_processed/10min/current/bioclim_06.tif', '../environmental_data_processed/10min/current/bioclim_07.tif', '../environmental_data_processed/10min/current/bioclim_08.tif', '../environmental_data_processed/10min/current/bioclim_09.tif', '../environmental_data_processed/10min/current/bioclim_10.tif', '../environmental_data_processed/10min/current/bioclim_11.tif', '../environmental_data_processed/10min/current/bioclim_12.tif', '../environmental_data_processed/10min/current/bioclim_13.tif', '../environmental_data_processed/10min/current/bioclim_14.tif', '../environmental_data_processed/10min/current/bioclim_15.tif', '../environmental_data_processed/10min/current/bioclim_16.tif', '../environmental_data_processed/10min/current/bioclim_17.tif', '../environmental_data_processed/10min/current/bioclim_18.tif', '../environmental_data_processed/10min/current/bioclim_19.tif')
writeRaster(bio_current_10min, '../environmental_data_processed/10min/current/bioclim.tif', bylayer=TRUE, suffix='numbers')
elevation_30s <- raster('../environmental_data_processed/30s/current/elevation.tif')
elevation_10min <- resample(elevation_30s,template)
writeRaster(elevation_10min,'../environmental_data_processed/10min/current/elevation.tif')
land_cover_30s <- raster('../environmental_data_processed/30s/current/land_cover.tif')
land_cover_10min <- resample(land_cover_30s,template)
writeRaster(land_cover_10min,'../environmental_data_processed/10min/current/land_cover.tif')


# future 2.5 min
#HadGEM3-GC31-LL_ssp585_2061-2080
bioclim_HadGEM3_30s <- stack('./30s/worldclim_2.1/future/wc2.1_30s_bioc_HadGEM3-GC31-LL_ssp585_2061-2080.tif')
bioclim_HadGEM3_2.5min <- resample(bioclim_HadGEM3_30s,template)
filenames <- c('../environmental_data_processed/2.5min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_01.tif', '../environmental_data_processed/2.5min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_02.tif', '../environmental_data_processed/2.5min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_03.tif', '../environmental_data_processed/2.5min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_04.tif', '../environmental_data_processed/2.5min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_05.tif', '../environmental_data_processed/2.5min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_06.tif', '../environmental_data_processed/2.5min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_07.tif', '../environmental_data_processed/2.5min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_08.tif', '../environmental_data_processed/2.5min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_09.tif', '../environmental_data_processed/2.5min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_10.tif', '../environmental_data_processed/2.5min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_11.tif', '../environmental_data_processed/2.5min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_12.tif', '../environmental_data_processed/2.5min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_13.tif', '../environmental_data_processed/2.5min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_14.tif', '../environmental_data_processed/2.5min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_15.tif', '../environmental_data_processed/2.5min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_16.tif', '../environmental_data_processed/2.5min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_17.tif', '../environmental_data_processed/2.5min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_18.tif', '../environmental_data_processed/2.5min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_19.tif')
writeRaster(bioclim_HadGEM3_2.5min, '../environmental_data_processed/2.5min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim.tif', bylayer=TRUE, suffix='numbers')

# IPSL-CM6A-LR
bioclim_IPSL_30s <- stack('./30s/worldclim_2.1/future/wc2.1_30s_bioc_IPSL-CM6A-LR_ssp585_2061-2080.tif')
bioclim_IPSL_2.5min <- resample(bioclim_IPSL_30s,template)
filenames <- c('../environmental_data_processed/2.5min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_01.tif', '../environmental_data_processed/2.5min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_02.tif', '../environmental_data_processed/2.5min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_03.tif', '../environmental_data_processed/2.5min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_04.tif', '../environmental_data_processed/2.5min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_05.tif', '../environmental_data_processed/2.5min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_06.tif', '../environmental_data_processed/2.5min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_07.tif', '../environmental_data_processed/2.5min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_08.tif', '../environmental_data_processed/2.5min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_09.tif', '../environmental_data_processed/2.5min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_10.tif', '../environmental_data_processed/2.5min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_11.tif', '../environmental_data_processed/2.5min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_12.tif', '../environmental_data_processed/2.5min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_13.tif', '../environmental_data_processed/2.5min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_14.tif', '../environmental_data_processed/2.5min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_15.tif', '../environmental_data_processed/2.5min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_16.tif', '../environmental_data_processed/2.5min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_17.tif', '../environmental_data_processed/2.5min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_18.tif', '../environmental_data_processed/2.5min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_19.tif')
writeRaster(bioclim_IPSL_2.5min, '../environmental_data_processed/2.5min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim.tif', bylayer=TRUE, suffix='numbers')

# MPI-ESM1-2-LR
bioclim_MPI_30s <- stack('./30s/worldclim_2.1/future/wc2.1_30s_bioc_MPI-ESM1-2-LR_ssp585_2061-2080.tif')
bioclim_MPI_2.5min <- resample(bioclim_MPI_30s,template)
filenames <- c('../environmental_data_processed/2.5min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_01.tif', '../environmental_data_processed/2.5min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_02.tif', '../environmental_data_processed/2.5min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_03.tif', '../environmental_data_processed/2.5min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_04.tif', '../environmental_data_processed/2.5min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_05.tif', '../environmental_data_processed/2.5min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_06.tif', '../environmental_data_processed/2.5min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_07.tif', '../environmental_data_processed/2.5min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_08.tif', '../environmental_data_processed/2.5min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_09.tif', '../environmental_data_processed/2.5min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_10.tif', '../environmental_data_processed/2.5min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_11.tif', '../environmental_data_processed/2.5min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_12.tif', '../environmental_data_processed/2.5min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_13.tif', '../environmental_data_processed/2.5min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_14.tif', '../environmental_data_processed/2.5min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_15.tif', '../environmental_data_processed/2.5min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_16.tif', '../environmental_data_processed/2.5min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_17.tif', '../environmental_data_processed/2.5min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_18.tif', '../environmental_data_processed/2.5min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_19.tif')
writeRaster(bioclim_MPI_2.5min, '../environmental_data_processed/2.5min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim.tif', bylayer=TRUE, suffix='numbers')

# [copy landcover and elevation to each future proj]


# future 10 min
template <- raster('../environmental_data_raw/10min/worldclim_2.1/current/wc2.1_10m_elev.tif')

#HadGEM3-GC31-LL_ssp585_2061-2080
bioclim_HadGEM3_30s <- stack('./30s/worldclim_2.1/future/wc2.1_30s_bioc_HadGEM3-GC31-LL_ssp585_2061-2080.tif')
bioclim_HadGEM3_10min <- resample(bioclim_HadGEM3_30s,template)
filenames <- c('../environmental_data_processed/10min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_01.tif', '../environmental_data_processed/10min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_02.tif', '../environmental_data_processed/10min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_03.tif', '../environmental_data_processed/10min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_04.tif', '../environmental_data_processed/10min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_05.tif', '../environmental_data_processed/10min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_06.tif', '../environmental_data_processed/10min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_07.tif', '../environmental_data_processed/10min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_08.tif', '../environmental_data_processed/10min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_09.tif', '../environmental_data_processed/10min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_10.tif', '../environmental_data_processed/10min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_11.tif', '../environmental_data_processed/10min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_12.tif', '../environmental_data_processed/10min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_13.tif', '../environmental_data_processed/10min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_14.tif', '../environmental_data_processed/10min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_15.tif', '../environmental_data_processed/10min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_16.tif', '../environmental_data_processed/10min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_17.tif', '../environmental_data_processed/10min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_18.tif', '../environmental_data_processed/10min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim_19.tif')
writeRaster(bioclim_HadGEM3_10min, '../environmental_data_processed/10min/future/HadGEM3-GC31-LL_ssp585_2061-2080/bioclim.tif', bylayer=TRUE, suffix='numbers')

# IPSL-CM6A-LR
bioclim_IPSL_30s <- stack('./30s/worldclim_2.1/future/wc2.1_30s_bioc_IPSL-CM6A-LR_ssp585_2061-2080.tif')
bioclim_IPSL_10min <- resample(bioclim_IPSL_30s,template)
filenames <- c('../environmental_data_processed/10min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_01.tif', '../environmental_data_processed/10min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_02.tif', '../environmental_data_processed/10min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_03.tif', '../environmental_data_processed/10min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_04.tif', '../environmental_data_processed/10min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_05.tif', '../environmental_data_processed/10min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_06.tif', '../environmental_data_processed/10min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_07.tif', '../environmental_data_processed/10min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_08.tif', '../environmental_data_processed/10min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_09.tif', '../environmental_data_processed/10min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_10.tif', '../environmental_data_processed/10min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_11.tif', '../environmental_data_processed/10min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_12.tif', '../environmental_data_processed/10min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_13.tif', '../environmental_data_processed/10min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_14.tif', '../environmental_data_processed/10min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_15.tif', '../environmental_data_processed/10min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_16.tif', '../environmental_data_processed/10min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_17.tif', '../environmental_data_processed/10min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_18.tif', '../environmental_data_processed/10min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim_19.tif')
writeRaster(bioclim_IPSL_10min, '../environmental_data_processed/10min/future/IPSL-CM6A-LR_ssp585_2061-2080/bioclim.tif', bylayer=TRUE, suffix='numbers')

# MPI-ESM1-2-LR
bioclim_MPI_30s <- stack('./30s/worldclim_2.1/future/wc2.1_30s_bioc_MPI-ESM1-2-LR_ssp585_2061-2080.tif')
bioclim_MPI_10min <- resample(bioclim_MPI_30s,template)
filenames <- c('../environmental_data_processed/10min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_01.tif', '../environmental_data_processed/10min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_02.tif', '../environmental_data_processed/10min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_03.tif', '../environmental_data_processed/10min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_04.tif', '../environmental_data_processed/10min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_05.tif', '../environmental_data_processed/10min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_06.tif', '../environmental_data_processed/10min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_07.tif', '../environmental_data_processed/10min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_08.tif', '../environmental_data_processed/10min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_09.tif', '../environmental_data_processed/10min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_10.tif', '../environmental_data_processed/10min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_11.tif', '../environmental_data_processed/10min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_12.tif', '../environmental_data_processed/10min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_13.tif', '../environmental_data_processed/10min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_14.tif', '../environmental_data_processed/10min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_15.tif', '../environmental_data_processed/10min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_16.tif', '../environmental_data_processed/10min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_17.tif', '../environmental_data_processed/10min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_18.tif', '../environmental_data_processed/10min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim_19.tif')
writeRaster(bioclim_MPI_10min, '../environmental_data_processed/10min/future/MPI-ESM1-2-LR_ssp585_2061-2080/bioclim.tif', bylayer=TRUE, suffix='numbers')

# [copy landcover and elevation to each future proj]


