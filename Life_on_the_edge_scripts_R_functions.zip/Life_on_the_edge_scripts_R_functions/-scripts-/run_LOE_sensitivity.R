setwd('$YOUR_WORK_DIR')

# source functions
source('./R_functions/life_on_the_edge_functions.R')

  params_all <- read.delim('./Params.tsv')
  
   # read args
  args <- commandArgs()
  print(args)
  species_binomial <- args[8]  
  # This may vary between systems depending on your HPC setup, the list of arguments will be printed at the beginning of your SLURM job logfile so if the jobs fail, make sure that this number matches the number in args[] that matches your species name

 # Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
  params <- params_all[which(params_all$species_binomial==species_binomial),]
  species_binomial <- params$species_binomial
  log_file <- paste0('./-outputs-/log_files/',species_binomial,'.log')

if ((params$skip_gea=='yes')) {
 cat('--------------------------------------------------------------\n', file=log_file, append=T)
 cat('Skipping identifying adaptive loci using RDA as requested...', '\n', file=log_file, append=T)
 cat('--------------------------------------------------------------\n', file=log_file, append=T)

}else{
gea_rda(species_binomial)  #if loop to skip
}
gea_rda_individual_categorisation(species_binomial) # the new one
quantify_local_adaptations(species_binomial)
genomic_offset(species_binomial)
if ((params$build_adaptive_sdms=='yes')) {
 cat('--------------------------------------------------------------\n', file=log_file, append=T)
 cat('Beginning adaptive SDMs as requested...', '\n', file=log_file, append=T)
 cat('--------------------------------------------------------------\n', file=log_file, append=T)
adaptive_sdms_biomod2(species_binomial)
}else{
}
neutral_sensitivity(species_binomial)
adaptive_sensitivity(species_binomial)
create_circuitscape_inputs(species_binomial)
