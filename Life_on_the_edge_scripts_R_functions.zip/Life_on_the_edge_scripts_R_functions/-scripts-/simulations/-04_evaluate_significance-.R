# Compare empirical and simulated results with z scores

rm(list=ls(all=TRUE))

root_dir <- ('$YOUR_WORK_DIR')

setwd(root_dir)

# read args
args <- commandArgs()
print(args)
species_binomial <- args[8]

# set params file
params_all <- read.delim('./Params.tsv')

# Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
params <- params_all[which(params_all$species_binomial==species_binomial),]
species_binomial <- params$species_binomial

log_file <- paste0('./-outputs-/log_files/',species_binomial,'.log')
sensitivity_path <- paste0('./-outputs-/',species_binomial,'/Sensitivity/')
dir.create(paste0(sensitivity_path))
output_path <- paste0(sensitivity_path,'Adaptive_sensitivity/-simulations-/simulated_spatial_data/')
dir.create(paste0(output_path))

cat('Evaluating local adaptation signals in empirical data vs. simulated data using z-scores on SNP p-values...\n', file=log_file, append=T)

# 5. Compare results

#load empirical results
empirical_LFMM_pvals <- read.csv(paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_LFMM_p_values.csv'))
empirical_RDA_pvals <- read.csv(paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_RDA_candidate_SNPs_by_predictor_SD_',params$rda_SD,'.csv'))

n_snps <- as.numeric(nrow(empirical_LFMM_pvals))

#load simulated results
for (i in 1:100) {
  LFMM_filepath <- file.path(paste0("./-outputs-/",species_binomial,"/Sensitivity/Adaptive_sensitivity/-simulations-/spatial_simulations/simulation_", i, "/", species_binomial,"_simulated_data_p_values.csv"))
  RDA_filepath <- file.path(paste0("./-outputs-/",species_binomial,"/Sensitivity/Adaptive_sensitivity/-simulations-/spatial_simulations/simulation_", i, "/", species_binomial,"_RDA_all_SNPs_by_predictor.csv"))
  
  # Construct the assign statements as a string
  LFMM_assign_statement <- paste0("LFMM_simulation_", i, "_pvals <- read.csv('", LFMM_filepath, "', sep = ',')")
   eval(parse(text = LFMM_assign_statement))
  LFMM_retain_predictor_1_statement <- paste0("LFMM_simulation_", i, "_predictor_1_pvals <- LFMM_simulation_", i, "_pvals[,2]")
  eval(parse(text = LFMM_retain_predictor_1_statement))
  LFMM_retain_predictor_2_statement <- paste0("LFMM_simulation_", i, "_predictor_2_pvals <- LFMM_simulation_", i, "_pvals[,3]")
  eval(parse(text = LFMM_retain_predictor_2_statement))
  cat("\nReading LFMM simulation_", i, "results... done!")

  # RDA STATEMENTS
  RDA_assign_statement <- paste0("RDA_simulation_", i, "_pvals <- read.csv('", RDA_filepath, "', sep = ',')")
  # Evaluate the assign statements
  eval(parse(text = RDA_assign_statement))
  RDA_retain_predictor_1_statement <- paste0("RDA_simulation_", i, "_predictor_1_RDA_pvals <- RDA_simulation_", i, "_pvals[,5]")
  eval(parse(text = RDA_retain_predictor_1_statement))
  RDA_retain_predictor_2_statement <- paste0("RDA_simulation_", i, "_predictor_2_RDA_pvals <- RDA_simulation_", i, "_pvals[,7]")
  eval(parse(text = RDA_retain_predictor_2_statement))
  cat("\nReading RDA simulation_", i, "results... done!")
}

# calculate z scores
# In addition, to assess if associations are putatively false positives, we performed a permutation analysis
#. We randomised habitat-assignments 20 times and performed LFMM association analyses on each randomised dataset. 
# Following Fuller et al.86 we determined a significance threshold as the 95th percentile of the Z-score 
# distribution and identified SNPs from the initial LFMM analyses above this threshold as significant. Using the 
# significance cut-off based on randomisation (>99th percentile), we detected a far higher number of associated SNPs

# so make a dataframe where the empirical data and all 100 simulated p-values are side by side
# then take the mean of each row and the SD of each row

# LFMM predictor 1
list_of_LFMM_simulated_data_predictor_1_pvals <- mget(ls(.GlobalEnv,pattern='_predictor_1_pvals'))
list_of_LFMM_simulated_data_predictor_1_pvals <- names(list_of_LFMM_simulated_data_predictor_1_pvals)
list_of_LFMM_simulated_data_predictor_1_pvals <- toString(list_of_LFMM_simulated_data_predictor_1_pvals)

all_LFMM_simulation_predictor_1_pvals <- paste0('cbind(',list_of_LFMM_simulated_data_predictor_1_pvals,')')
all_LFMM_simulation_predictor_1_pvals <- eval(parse(text=paste0(all_LFMM_simulation_predictor_1_pvals)))

all_LFMM_predictor_1_pvals <- cbind(empirical_LFMM_pvals[,2],all_LFMM_simulation_predictor_1_pvals)
all_LFMM_predictor_1_pvals <- as.data.frame(all_LFMM_predictor_1_pvals)
colnames(all_LFMM_predictor_1_pvals) <- 1:101

# LFMM predictor 2
list_of_LFMM_simulated_data_predictor_2_pvals <- mget(ls(.GlobalEnv,pattern='_predictor_2_pvals'))
list_of_LFMM_simulated_data_predictor_2_pvals <- names(list_of_LFMM_simulated_data_predictor_2_pvals)
list_of_LFMM_simulated_data_predictor_2_pvals <- toString(list_of_LFMM_simulated_data_predictor_2_pvals)

all_LFMM_simulation_predictor_2_pvals <- paste0('cbind(',list_of_LFMM_simulated_data_predictor_2_pvals,')')
all_LFMM_simulation_predictor_2_pvals <- eval(parse(text=paste0(all_LFMM_simulation_predictor_2_pvals)))

all_LFMM_predictor_2_pvals <- cbind(empirical_LFMM_pvals[,3],all_LFMM_simulation_predictor_2_pvals)
colnames(all_LFMM_predictor_2_pvals) <- 1:101

# the pvalues associated with the predictors are always the lowest ones, so read in both predictors and make a dataframe
# with the lowest p values for all SNPs - these are the ones that need to be compared with the empirical data

all_LFMM_pvals <- data.frame()

# replace NAs with 0
all_LFMM_predictor_1_pvals[is.na(all_LFMM_predictor_1_pvals)] <- 0
all_LFMM_predictor_2_pvals[is.na(all_LFMM_predictor_2_pvals)] <- 0

for (i in c(1:n_snps)) {
 for (j in c(1:101)) {
if ((all_LFMM_predictor_1_pvals[i,j]) < (all_LFMM_predictor_2_pvals[i,j])) {
  all_LFMM_pvals[i,j] <- all_LFMM_predictor_1_pvals[i,j]}else{
  all_LFMM_pvals[i,j] <- all_LFMM_predictor_2_pvals[i,j]}
}
}
colnames(all_LFMM_pvals) <- 1:101

# Now RDA...
# RDA predictor 1
list_of_RDA_simulated_data_predictor_1_pvals <- mget(ls(.GlobalEnv,pattern='predictor_1_RDA_pvals'))
list_of_RDA_simulated_data_predictor_1_pvals <- names(list_of_RDA_simulated_data_predictor_1_pvals)
list_of_RDA_simulated_data_predictor_1_pvals <- toString(list_of_RDA_simulated_data_predictor_1_pvals)

all_RDA_simulation_predictor_1_pvals <- paste0('cbind(',list_of_RDA_simulated_data_predictor_1_pvals,')')
all_RDA_simulation_predictor_1_pvals <- eval(parse(text=paste0(all_RDA_simulation_predictor_1_pvals)))

all_RDA_predictor_1_pvals <- cbind(empirical_RDA_pvals[,2],all_RDA_simulation_predictor_1_pvals)
colnames(all_RDA_predictor_1_pvals) <- 1:101

# RDA predictor 2
list_of_RDA_simulated_data_predictor_2_pvals <- mget(ls(.GlobalEnv,pattern='predictor_2_RDA_pvals'))
list_of_RDA_simulated_data_predictor_2_pvals <- names(list_of_RDA_simulated_data_predictor_2_pvals)
list_of_RDA_simulated_data_predictor_2_pvals <- toString(list_of_RDA_simulated_data_predictor_2_pvals)

all_RDA_simulation_predictor_2_pvals <- paste0('cbind(',list_of_RDA_simulated_data_predictor_2_pvals,')')
all_RDA_simulation_predictor_2_pvals <- eval(parse(text=paste0(all_RDA_simulation_predictor_2_pvals)))

all_RDA_predictor_2_pvals <- cbind(empirical_RDA_pvals[,3],all_RDA_simulation_predictor_2_pvals)
colnames(all_RDA_predictor_2_pvals) <- 1:101

# the pvalues associated with the predictors are always the lowest ones, so read in both predictors and make a dataframe
# with the lowest p values for all SNPs - these are the ones that need to be compared with the empirical data

all_RDA_pvals <- data.frame()

for (i in c(1:n_snps)) {
  for (j in c(1:101)) {
    if ((all_RDA_predictor_1_pvals[i,j]) < (all_RDA_predictor_2_pvals[i,j])) {
      all_RDA_pvals[i,j] <- all_RDA_predictor_1_pvals[i,j]}else{
        all_RDA_pvals[i,j] <- all_RDA_predictor_2_pvals[i,j]}
  }
}
colnames(all_RDA_pvals) <- 1:101


#colnames(all_predictor_1_pvals) <- 1:11
#all_predictor_1_pvals <- as.numeric(all_predictor_1_pvals)

# for every SNP position, calculate the mean, SD and z-scores for observed and simulated 100 datasets
# for empirical data, identify SNPs with significance in above 95th percentile of the z-score distribution

# LFMM
#Mean pval per SNP:
for (j in 1:n_snps) {
  calculate_means_per_snp_statement <- paste0("SNP_", j, "_mean <- mean(as.numeric(all_LFMM_pvals[j,","]))")
  eval(parse(text = calculate_means_per_snp_statement))
}
  
#Standard deviation per SNP:
for (j in 1:n_snps) {
  calculate_sd_per_snp_statement <- paste0("SNP_", j, "_sd <- sd(as.numeric(all_LFMM_pvals[j,","]))")
  eval(parse(text = calculate_sd_per_snp_statement))
}

# write out
means <- mget(ls(.GlobalEnv,pattern='\\_mean$'))
sds <- mget(ls(.GlobalEnv,pattern='\\_sd$'))

means <- cbind(means)
sds <- cbind(sds)

write.csv(all_LFMM_pvals, paste0(sensitivity_path,'/Adaptive_sensitivity/all_LFMM_pvals.csv'), row.names=FALSE)
write.csv(means, paste0(sensitivity_path,'/Adaptive_sensitivity//LFMM_means.csv'), row.names=FALSE)
write.csv(sds, paste0(sensitivity_path,'/Adaptive_sensitivity//LFMM_sds.csv'), row.names=FALSE)

# RDA
#Mean pval per SNP:
for (j in 1:n_snps) {
  calculate_means_per_snp_statement <- paste0("SNP_", j, "_mean <- mean(as.numeric(all_RDA_pvals[j,","]))")
  eval(parse(text = calculate_means_per_snp_statement))
}
  
#Standard deviation per SNP:
for (j in 1:n_snps) {
  calculate_sd_per_snp_statement <- paste0("SNP_", j, "_sd <- sd(as.numeric(all_RDA_pvals[j,","]))")
  eval(parse(text = calculate_sd_per_snp_statement))
}

# write out
means <- mget(ls(.GlobalEnv,pattern='\\_mean$'))
sds <- mget(ls(.GlobalEnv,pattern='\\_sd$'))

means <- cbind(means)
sds <- cbind(sds)

write.csv(all_RDA_pvals, paste0(sensitivity_path,'/Adaptive_sensitivity/all_RDA_pvals.csv'), row.names=FALSE)
write.csv(means, paste0(sensitivity_path,'/Adaptive_sensitivity//RDA_means.csv'), row.names=FALSE)
write.csv(sds, paste0(sensitivity_path,'/Adaptive_sensitivity//RDA_sds.csv'), row.names=FALSE)


# Now calculate z scores 
rm(list=ls(all=TRUE))

root_dir <- ('$YOUR_WORK_DIR')

setwd(root_dir)

# read args
args <- commandArgs()
print(args)
species_binomial <- args[8]

sensitivity_path <- paste0('./-outputs-/',species_binomial,'/Sensitivity/')
setwd(sensitivity_path)

log_file <- paste0(root_dir,'/-outputs-/log_files/',species_binomial,'.log')

observed_v_simulated_path <- paste0('./Adaptive_sensitivity/-simulations-/observed_v_simulated/')
dir.create(observed_v_simulated_path)

#Sys.setenv(R_MAX_VSIZE = 16e9) # if needed to increase R available memory

# Do this for all LFMM SNPs
all_LFMM_pvals <- read.csv('./Adaptive_sensitivity/all_LFMM_pvals.csv')
LFMM_means <- read.csv('./Adaptive_sensitivity/LFMM_means.csv')
LFMM_sds <- read.csv('./Adaptive_sensitivity/LFMM_sds.csv')

n_snps <- as.numeric(nrow(all_LFMM_pvals))

# then go through all identified SNPs, calculate z-scores for observed data and 100 simulations and check if they are in te 95th percentile of the distribution
for (j in 1:100) {
#  for (k in 1:100) {
      for (k in 1:n_snps) {
  #    for (k in 1:n_snps) {
          calculate_means_per_snp_statement <- paste0("z_score_sim_", j, "_snp_",k," <- (all_LFMM_pvals[",k,",",j,"]-LFMM_means[",k,",])/LFMM_sds[",k,",]")
  eval(parse(text = calculate_means_per_snp_statement))
  }
}

# bind all together
for (k in 1:n_snps) {
          store_and_save_all_z_scores_per_snp <- paste0("LFMM_snp_",k," <- mget(ls(.GlobalEnv,pattern='snp_",k,"$')); snp_",k," <- cbind(LFMM_snp_",k,"); LFMM_snp_",k," <- tail(LFMM_snp_",k,",n=100); write.table(LFMM_snp_",k,",'./Adaptive_sensitivity/-simulations-/observed_v_simulated/LFMM_snp_",k,".csv', col.names=FALSE, row.names=FALSE)")
          eval(parse(text = store_and_save_all_z_scores_per_snp))
          }
          
#all_predictor_1_pvals <- read.csv('./all_predictor_1_pvals.csv')
observed_data <- all_LFMM_pvals[,1]

for (k in 1:n_snps) {
  check_zscore_observed_vs_simulation_statement <- paste0("snp_", k, " <- read.csv('./Adaptive_sensitivity/-simulations-/observed_v_simulated/LFMM_snp_",k,".csv', header=FALSE); LFMM_snp_",k," <- as.data.frame(LFMM_snp_",k,"); LFMM_snp_",k," <- LFMM_snp_",k,"[,1]; LFMM_snp_",k,"_quantile <- quantile(LFMM_snp_",k,",0.95, na.rm=TRUE)")
  eval(parse(text = check_zscore_observed_vs_simulation_statement))
  take_observed_data <- paste0("LFMM_snp_", k, "_observed <- observed_data[",k,"]")
  eval(parse(text = take_observed_data))
  evaluate_observed_vs_simulated <- paste0("snp_", k, "_LFMM_final <- LFMM_snp_", k, "_observed > LFMM_snp_",k, "_quantile")
  eval(parse(text = evaluate_observed_vs_simulated))
}

#bind and write out to file
all_LFMM_snps_validated <- mget(ls(.GlobalEnv,pattern='_LFMM_final$'))
all_LFMM_snps_validated <- c(all_LFMM_snps_validated)
all_LFMM_snps_validated <- as.data.frame(all_LFMM_snps_validated)

write.csv(all_LFMM_snps_validated,'./Adaptive_sensitivity/-simulations-/observed_v_simulated/all_snps_LFMM_validated.csv')

cat('> Empirical LFMM results DONE!\n', file=log_file, append=T)

# Do this for all RDA SNPs
all_RDA_pvals <- read.csv('./Adaptive_sensitivity/all_RDA_pvals.csv')
RDA_means <- read.csv('./Adaptive_sensitivity/RDA_means.csv')
RDA_sds <- read.csv('./Adaptive_sensitivity/RDA_sds.csv')

# then go through all identified SNPs, calculate z-scores for observed data and 100 simulations and check if they are in te 95th percentile of the distribution
for (j in 1:100) {
#  for (k in 1:100) {
      for (k in 1:n_snps) {
  #    for (k in 1:n_snps) {
          calculate_means_per_snp_statement <- paste0("z_score_sim_", j, "_snp_",k," <- (all_RDA_pvals[",k,",",j,"]-RDA_means[",k,",])/RDA_sds[",k,",]")
  eval(parse(text = calculate_means_per_snp_statement))
  }
}

# bind all together
for (k in 1:n_snps) {
          store_and_save_all_z_scores_per_snp <- paste0("RDA_snp_",k," <- mget(ls(.GlobalEnv,pattern='snp_",k,"$')); snp_",k," <- cbind(RDA_snp_",k,"); RDA_snp_",k," <- tail(RDA_snp_",k,",n=100); write.table(RDA_snp_",k,",'./Adaptive_sensitivity/-simulations-/observed_v_simulated/RDA_snp_",k,".csv', col.names=FALSE, row.names=FALSE)")
          eval(parse(text = store_and_save_all_z_scores_per_snp))
          }
          
#all_predictor_1_pvals <- read.csv('./all_predictor_1_pvals.csv')
observed_data <- all_RDA_pvals[,1]

for (k in 1:n_snps) {
  check_zscore_observed_vs_simulation_statement <- paste0("snp_", k, " <- read.csv('./Adaptive_sensitivity/-simulations-/observed_v_simulated/RDA_snp_",k,".csv', header=FALSE); RDA_snp_",k," <- as.data.frame(RDA_snp_",k,"); RDA_snp_",k," <- RDA_snp_",k,"[,1]; RDA_snp_",k,"_quantile <- quantile(RDA_snp_",k,",0.95)")
  eval(parse(text = check_zscore_observed_vs_simulation_statement))
  take_observed_data <- paste0("RDA_snp_", k, "_observed <- observed_data[",k,"]")
  eval(parse(text = take_observed_data))
  evaluate_observed_vs_simulated <- paste0("snp_", k, "_RDA_final <- RDA_snp_", k, "_observed > RDA_snp_",k, "_quantile")
  eval(parse(text = evaluate_observed_vs_simulated))
}

#bind and write out to file
all_RDA_snps_validated <- mget(ls(.GlobalEnv,pattern='_RDA_final$'))
all_RDA_snps_validated <- c(all_RDA_snps_validated)
all_RDA_snps_validated <- as.data.frame(all_RDA_snps_validated)

write.csv(all_RDA_snps_validated,'./Adaptive_sensitivity/-simulations-/observed_v_simulated/all_snps_RDA_validated.csv')

cat('> Empirical RDA results DONE!\n', file=log_file, append=T)

######
# LAST STEP
# now remake the RDA for plotting candidate SNP confidence
###########################################################################################################
############################################### RDA ######################################################
###########################################################################################################
# Run RDA to find adaptive SNPs

rm(list=ls(all=TRUE))

# Load packages, set some directories
library(adegenet)   # for reading files
library(vegan)
library(psych)      # nice pair plots
library(usdm)       # calculates variance inflation factors
library(robust)     # for robust mahalanobis distance calculation
library(qvalue)     # false discovery rate calculation
library(qpcR)       # for binding columns of candidate SNPs with different lengths
library(stringr)    # for counting adaptive and validated SNPs

root_dir <- ('$YOUR_WORK_DIR')

setwd(root_dir)

genomic_data_path <- './-data-/genomic_data/'
spatial_data_path <- './-data-/spatial_data/'

colours <- c('#ff7f00','#1f78b4','#ffff33','#a6cee3','#33a02c','#e31a1c')

# read args
args <- commandArgs()
print(args)
species_binomial <- args[8]

# set params file
params_all <- read.delim('./Params.tsv')

# Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
params <- params_all[which(params_all$species_binomial==species_binomial),]
species_binomial <- params$species_binomial

log_file <- paste0('./-outputs-/log_files/',species_binomial,'.log')
sensitivity_path <- paste0('./-outputs-/',species_binomial,'/Sensitivity/')
output_path <- paste0(sensitivity_path,'Adaptive_sensitivity/')

cat('Plotting results of simulation validations...\n', file=log_file, append=T)

##########
# Detection of adaptive SNPs

# Function to detect outliers from RDA: (courtesy of Brenna Forester)
# -------------------------------------
# r <- 1               # which RDA axis to process
# z <- 3               # how many st.dev. from mean loading
# x <- load.species_binomial       # loadings from RDA
# e <- species_binomial.env        # env - HARD CODED FOR 2 ENV.
# s <- species_binomial.scale      # snps

outliers <- function(r,z,x,e,s) {
  dat <- x[,r]
  lims <- mean(dat) + c(-1, 1) * z * sd(dat)    
  out.load <- dat[dat < lims[1] | dat > lims[2]]   #load
  out.name <- names(out.load)                      #SNPs
  
  if (length(out.load) > 0) {
    axis <- rep(r, length(out.load))
    outdat <- t(rbind(out.name, as.numeric(out.load), axis))
    snpcors <- matrix(NA, nrow=length(out.load), ncol=2*ncol(e))
    
    for (k in 1:length(out.load)) {
      outsnp <- s[,out.name[k]]
      snpcors[k,1] <- as.numeric(cor.test(outsnp, e[,1])$estimate)
      snpcors[k,2] <- as.numeric(cor.test(outsnp, e[,1])$p.value)
      snpcors[k,3] <- as.numeric(cor.test(outsnp, e[,2])$estimate)
      snpcors[k,4] <- as.numeric(cor.test(outsnp, e[,2])$p.value )  }
    outdata <- cbind.data.frame(outdat, snpcors)
    return(outdata)
  }
}    

output_path <- paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/')

# Read in the empirical per_snp true/false data 
# i.e. whether the z-score from the empirical data is above the 99th percentile of the randomised data
LFMM_empirical_results <- read.csv(paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/-simulations-/observed_v_simulated/all_snps_LFMM_validated.csv'))
LFMM_empirical_results <- LFMM_empirical_results[,-1]

RDA_empirical_results <- read.csv(paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/-simulations-/observed_v_simulated/all_snps_RDA_validated.csv'))
RDA_empirical_results <- RDA_empirical_results[,-1]

# read in the env_data.csv
#read the data that is extracted automatically from your predictor variables
env <- read.csv(paste0('-data-/spatial_data/',species_binomial,'/',species_binomial,'_full_env_data.csv'))
#env <- env[,c(params$env_predictor_1,params$env_predictor_2)] # subset env vars of interest for local adaptation analyses

pop_assignment <- read.csv(paste0('./-outputs-/',species_binomial,'/Sensitivity/',species_binomial,'_pop_assignment_LEA.csv'))
lhs1 <- paste0('env',sep='')
rhs1 <- paste0('as.data.frame(cbind(env$Sample, pop_assignment$pop, env$',params$env_predictor_1, ',env$',params$env_predictor_2,'))')
eq1  <- paste0(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))

colnames(env) <- eval(parse(text=paste0("c('Sample', 'cluster', '",params$env_predictor_1,"','",params$env_predictor_2,"')")))

# Data prep
species_binomial.genlight <- read.PLINK(paste0(genomic_data_path,species_binomial,'/',species_binomial,'.raw'), map.file = paste0(genomic_data_path,species_binomial,'/',species_binomial,'.map'),
                                        quiet = FALSE, chunkSize = 1000, parallel = FALSE, n.cores = NULL)

identical(as.character(env[,1]), species_binomial.genlight@ind.names)

species <- as.matrix(species_binomial.genlight)  

species <- as.data.frame(species)

lhs1 <- paste0('species.full',sep='')
rhs1 <- paste0('as.data.frame(cbind(env$Sample, pop_assignment$pop, env$',params$env_predictor_1, ',env$',params$env_predictor_2,'))')
eq1  <- paste0(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))

#colnames(species.full) <- c('Sample', 'cluster', 'bioclim_5', 'bioclim_18')
colnames(species.full) <- eval(parse(text=paste0("c('Sample', 'cluster', '",params$env_predictor_1,"','",params$env_predictor_2,"')")))
species.full <- cbind(species.full,species)
species.full <- species.full[order(species.full$cluster),]
species.full$cluster <- as.numeric(species.full$cluster)

lhs1  <- paste0('species.full$',params$env_predictor_1,sep='')
rhs1  <- paste0('as.numeric(species.full$',params$env_predictor_1,')', sep='')
eq1   <- paste0(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))
lhs1  <- paste0('species.full$',params$env_predictor_2,sep='')
rhs1  <- paste0('as.numeric(species.full$',params$env_predictor_2,')', sep='')
eq1   <- paste0(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))

#Impute within clusters by taking the mean genotype across individuals

# Below code generalises the code used for Razgour et al. (2017), makes it flexible
nclust <- unique(species.full$cluster)
n    <- length(nclust)
lhs1  <- paste('species',    1:n,     sep='_')
rhs1  <- paste('species.full[species.full$cluster==',1:n,', c(-1:-4)]', sep='')
eq1   <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))

n    <- length(nclust)
lhs2  <- paste('cMr')
rhs2  <- paste('round(colMeans(species_',1:n,', na.rm =TRUE)); indx <- which(is.na(species_',1:n, '), arr.ind=TRUE); species_' ,1:n, '[indx] <- cMr[indx[,2]]', sep='')
eq2   <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
eval(parse(text=eq2))

lhs3  <- paste('rbind(')
rhs3 <- capture.output(cat(lhs1, sep=','))
eq3 <- paste0(lhs3,rhs3,')')
eval(parse(text=eq3))

species_binomial.imp <- eval(parse(text=eq3))

identical(as.character(species.full[,1]), row.names(species_binomial.imp))
species_binomial.env <- species.full[,3:4]
colnames(species_binomial.env) <- c(params$env_predictor_1, params$env_predictor_2)

# Rename the SNPs names to match across lfmm, RDA analyses 
features <- species_binomial.genlight@loc.names
colnames(species_binomial.imp) <- features
inds <- species_binomial.genlight@ind.names
rownames(species_binomial.env) <- inds

colnames(LFMM_empirical_results) <- features
colnames(RDA_empirical_results) <- features

# Run the RDA
species_binomial.rda <- rda(species_binomial.imp ~ ., data=species_binomial.env, scale=T)  
species_binomial.rda
RsquareAdj(species_binomial.rda)
summary(eigenvals(species_binomial.rda, model = 'constrained'))
screeplot(species_binomial.rda)

axes <- params$rda_axes

# species_binomial outlier detection
# all candidates
load.species_binomial <- summary(species_binomial.rda)$species[,1:2]  # loadings on constrained axes
n_predictors <- ncol(species_binomial.env)

SD <- params$rda_SD_threshold

SD_name <- gsub("\\.","_",SD) # for construction of variables without a '.'

lhs4 <- paste0('cand_',1:n_predictors)
rhs4 <- paste0('outliers(',1:n_predictors, ',',SD,',load.species_binomial, species_binomial.env, species_binomial.imp)')
eq4 <- paste(paste(lhs4,rhs4, sep=' <- '), collapse='; ')
eval(parse(text=eq4))

lhs4 <- toString(lhs4)
species_binomial.cand <- rbind.data.frame(cand_1,cand_2)
lhs5 <- paste0('species_binomial.cand')
rhs5 <- paste0('rbind.data.frame(',lhs4,')')
eq5 <- paste(paste(lhs5,rhs5, sep=' <- '), collapse='; ')
eval(parse(text=eq5))

corr_text <- paste0('Corr_env',1:n_predictors)
p_value_text <- paste0('p_env',1:n_predictors)
corr_p_value_text <- paste0(paste(corr_text,p_value_text))
corr_p_value_text <- toString(corr_p_value_text)
corr_p_value_text <- gsub(" p",",p",corr_p_value_text)
corr_p_value_text <- gsub(" ",",",corr_p_value_text)
corr_p_value_text <- gsub(",,",",",corr_p_value_text)
corr_p_value_text <- gsub(",","','",corr_p_value_text)
corr_p_value_text <- paste0("'",corr_p_value_text)
corr_p_value_text <- paste0(corr_p_value_text,"'")

colnames_candidate_SNPs_first_three_columns <- c('SNP','Loading','Axis')

lhs6 <- paste0('colnames_candidate_SNPs_remaining_columns')
rhs6 <- paste0('c(',corr_p_value_text,')')
eq6 <- paste(paste(lhs6,rhs6, sep=' <- '), collapse='; ')
eval(parse(text=eq6))

colnames_candidate_SNPs <- c(paste0(colnames_candidate_SNPs_first_three_columns),paste0(colnames_candidate_SNPs_remaining_columns))

# add SD_threshold to each dataframe to keep track
species_binomial.cand$SD_threshold <- paste0(SD)

####
# if there are RDA SNPs identified, go on as normal, otherwise skip to the end
if (length(species_binomial.cand)!='0'){
  colnames(species_binomial.cand) <- paste0(colnames_candidate_SNPs)
  
  species_binomial.cand$SNP <- as.character(species_binomial.cand$SNP)
  species_binomial.cand$SNP[duplicated(species_binomial.cand$SNP)] # Check there are no duplicate detections
  
  # from here it needs slightly more generalising in case of extra environmental predictors (here uses 2)
  for (i in 1:length(species_binomial.cand$SNP)) {
    bar <- species_binomial.cand[i,]
    species_binomial.cand[i,8] <- names(which.max(abs(bar[c(4,6)]))) # gives the variable
  }
  colnames(species_binomial.cand)[8] <- 'Max_corr'
  
  # round to 2 dp for correlations
  species_binomial.cand$`Corr_env1` <- round(species_binomial.cand$`Corr_env1`,2)
  species_binomial.cand$`Corr_env2` <- round(species_binomial.cand$`Corr_env2`,2)
  
  species_binomial.cand$SD <- SD
  
  # write_out
  write.csv(species_binomial.cand, file=paste0(output_path, species_binomial,'_RDA_candidate_SNPs_by_predictor_SD_',SD,'.csv'), row.names=F)
  
  # plot SNPs in RDA space
  # Summarise the candidate SNPs associated with each predictor
  table(species_binomial.cand$Max_corr)
  # Summarise the candidate SNPs associated with each RDA axis
  table(species_binomial.cand$Axis)
  
  # Plot 2 panels - candidate SNPs and uncertainty  
  # species_binomial outlier plot
  sel <- species_binomial.cand$SNP
  env <- species_binomial.cand$Max_corr
  RDA_sel <- species_binomial.cand$SNP
  LFMM_sel <- read.csv(paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_LFMM_candidate_SNPs_by_predictor_FDR_',params$lfmm_FDR_threshold,'.csv'))
  LFMM_sel_predictor_1 <- c(LFMM_sel[,1]); LFMM_sel_predictor_1 <- na.omit(LFMM_sel_predictor_1)
  LFMM_sel_predictor_2 <- c(LFMM_sel[,2]); LFMM_sel_predictor_2 <- na.omit(LFMM_sel_predictor_2)
  LFMM_sel <- c(LFMM_sel_predictor_1, LFMM_sel_predictor_2)
  
  env <- species_binomial.cand$Max_corr
  env[env=='Corr_env1'] <- '#e53032' # bioclim_5
  env[env=='Corr_env2'] <- '#3585bb' # bioclim_18
  
  ###### RDA color snps by predictor
  all.snp <- rownames(species_binomial.rda$CCA$v)
  test <- all.snp
  
  for (i in 1:length(RDA_sel)) {
    RDA <- match(RDA_sel[i],test)
    test[RDA] <- env[i]
  }
  
  test[grep('_',test)] <- '#f1eef6'
  
  empty <- test
  empty[grep('#f1eef6',empty)] <- rgb(0,1,0, alpha=0) # transparent
  
  empty.outline <- ifelse(empty=='#00FF0000','#00FF0000','gray32')
  
  RDA <- empty
  
# start plot
  png(filename=paste0(output_path,'/',species_binomial,'_adaptive_SNPs_simulation_validation.png'),
      type='cairo', units='cm', width=40, height=40, pointsize=12, res=300)
  par(mfrow=c(2,2))
  par(cex.main=2, cex.axis=1.5)
  plot(species_binomial.rda, type='n', scaling=3, xlim=c(-0.5,0.5), ylim=c(-0.5,0.5), cex.axis=2, cex.lab=2)
  points(species_binomial.rda, display='species', pch=21, cex=2, col='gray32', bg=test, scaling=3)
  points(species_binomial.rda, display='species', pch=21, cex=2, col=empty.outline, bg=RDA, scaling=3)
  text(species_binomial.rda, scaling = 3, labels=c(params$env_predictor_1,params$env_predictor_2), display = 'bp', col='#0868ac', cex=1)
  bg <- c('#e53032','#3585bb')
  legend('topleft', title= 'Candidate adaptive RDA SNPs', legend = c(params$env_predictor_1,params$env_predictor_2), bty = 'n', col='gray32', pch = 21, cex=2, pt.bg = bg)
  
 
  # Make the same plot but colour by if they passed (green)/ failed (red) the 99% quantile threshold defined for each snp
  # filter the empirical_results to only those SNPs identified in the initial analyses
  
  RDA_empirical_results <- as.data.frame(t(RDA_empirical_results))
  RDA_empirical_results$SNP <- row.names(RDA_empirical_results)
  RDA_empirical_results <- subset(RDA_empirical_results, SNP %in% sel)
  #
  
  RDA_empirical_results <- read.csv(paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/-simulations-/observed_v_simulated/all_snps_RDA_validated.csv'))
  RDA_empirical_results <- RDA_empirical_results[,-1]
  RDA_empirical_results <- as.character(RDA_empirical_results)
  RDA_empirical_results <- as.data.frame(RDA_empirical_results)
  RDA_empirical_results <- as.data.frame(RDA_empirical_results)
  RDA_empirical_results$SNP <- features
  RDA_empirical_results <- subset(RDA_empirical_results, SNP %in% RDA_sel)
 

  sel <- species_binomial.cand$SNP
  env <- species_binomial.cand$Max_corr
  
  # cands
  RDA_empirical_results$V1[RDA_empirical_results$RDA_empirical_results=='TRUE'] <- 'green'
  RDA_empirical_results$V1[RDA_empirical_results$RDA_empirical_results=='FALSE']  <- 'orange2'

  # color snps by predictor
  all.snp <- rownames(species_binomial.rda$CCA$v)
  RDA_test <- all.snp
  
  for (i in 1:length(sel)) {
    foo <- match(sel[i],RDA_test)
    RDA_test[foo] <- RDA_empirical_results$V1[i]
  }
  
  RDA_test[grep('_',RDA_test)] <- '#f1eef6'

  empty <- RDA_test
  empty[grep('#f1eef6',empty)] <- rgb(0,1,0, alpha=0) # transparent
  
  empty.outline <- ifelse(empty=='#00FF0000','#00FF0000','gray32')
  
  # count and report statistical significance of SNPs for the log file
  statistically_significant_SNPs <- sum(str_count(RDA_test, pattern = "green"))
  non_statistically_significant_SNPs <- sum(str_count(RDA_test, pattern = "oranges"))
  cat('Number of statistically significant RDA candidate SNPs: ',statistically_significant_SNPs,'\n', file=log_file, append=T)
  cat('Number of non-statistically significant RDA candidate SNPs: ',non_statistically_significant_SNPs,'\n', file=log_file, append=T)

  # Color by env predictor
  plot(species_binomial.rda, type='n', scaling=3, xlim=c(-0.5,0.5), ylim=c(-0.5,0.5), cex.axis=2, cex.lab=2)
  points(species_binomial.rda, display='species', pch=21, cex=2, col='gray32', bg=RDA_test, scaling=3)
  points(species_binomial.rda, display='species', pch=21, cex=2, col=empty.outline, bg=empty, scaling=3)
  text(species_binomial.rda, scaling = 3, labels=c(params$env_predictor_1,params$env_predictor_2), display = 'bp', col='#0868ac', cex=1)
  bg <- c('#f1eef6','green','orange2')
  legend('topleft', title='Observed results significant at 95%?', legend = c('Non-adaptive', 'Yes', 'No'), bty = 'n', col='gray32', pch = 21, cex=2, pt.bg = bg)


# # THE LFMM ONES
  
  LFMM_sel <- read.csv(paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_LFMM_candidate_SNPs_by_predictor.csv'))
  LFMM_sel_predictor_1 <- c(LFMM_sel[,1]); LFMM_sel_predictor_1 <- na.omit(LFMM_sel_predictor_1)
  LFMM_sel_predictor_2 <- c(LFMM_sel[,2]); LFMM_sel_predictor_2 <- na.omit(LFMM_sel_predictor_2)
  LFMM_sel <- c(LFMM_sel_predictor_1, LFMM_sel_predictor_2)

# get the env data proper
  LFMM_sel_predictor_1 <- as.data.frame(LFMM_sel_predictor_1)
  LFMM_sel_predictor_1$Max_corr <- "Corr_env1"
  
  LFMM_sel_predictor_2 <- as.data.frame(LFMM_sel_predictor_2)
  LFMM_sel_predictor_2$Max_corr <- "Corr_env2"
  
  env1 <- c(LFMM_sel_predictor_1$Max_corr)
  env2 <- c(LFMM_sel_predictor_2$Max_corr)
  
  env <- c(env1,env2)

#  env2 <- species_binomial.cand$Max_corr
  env[env=='Corr_env1'] <- '#e53032' # bioclim_5
  env[env=='Corr_env2'] <- '#3585bb' # bioclim_18
  
 
  ###### LFMM color snps by predictor
  all.snp <- rownames(species_binomial.rda$CCA$v)
  test <- all.snp
  
  for (i in 1:length(LFMM_sel)) {
    LFMM <- match(LFMM_sel[i],test)
    test[LFMM] <- env[i]
  }
  
  test[grep('_',test)] <- '#f1eef6'
  
  empty <- test
  empty[grep('#f1eef6',empty)] <- rgb(0,1,0, alpha=0) # transparent
  
  empty.outline <- ifelse(empty=='#00FF0000','#00FF0000','gray32')
  
  LFMM <- empty
    
   plot(species_binomial.rda, type='n', scaling=3, xlim=c(-0.5,0.5), ylim=c(-0.5,0.5), cex.axis=2, cex.lab=2)
  points(species_binomial.rda, display='species', pch=21, cex=2, col='gray32', bg=test, scaling=3)
  points(species_binomial.rda, display='species', pch=21, cex=2, col=empty.outline, bg=LFMM, scaling=3)
  text(species_binomial.rda, scaling = 3, labels=c(params$env_predictor_1,params$env_predictor_2), display = 'bp', col='#0868ac', cex=1)
  bg <- c('#e53032','#3585bb')
  legend('topleft', title= 'Candidate adaptive SNPs LFMM ', legend = c(params$env_predictor_1,params$env_predictor_2), bty = 'n', col='gray32', pch = 21, cex=2, pt.bg = bg)
  
  
  LFMM_empirical_results <- read.csv(paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/-simulations-/observed_v_simulated/all_snps_LFMM_validated.csv'))
  LFMM_empirical_results <- LFMM_empirical_results[,-1]

  LFMM_empirical_results <- as.character(LFMM_empirical_results)
  LFMM_empirical_results <- as.data.frame(LFMM_empirical_results)
  LFMM_empirical_results$SNP <- features

  LFMM_sel <- read.csv(paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_LFMM_candidate_SNPs_by_predictor_FDR_',params$lfmm_FDR_threshold,'.csv'))
  LFMM_sel_predictor_1 <- c(LFMM_sel[,1]); LFMM_sel_predictor_1 <- na.omit(LFMM_sel_predictor_1)
  LFMM_sel_predictor_2 <- c(LFMM_sel[,2]); LFMM_sel_predictor_2 <- na.omit(LFMM_sel_predictor_2)
  LFMM_sel <- c(LFMM_sel_predictor_1, LFMM_sel_predictor_2)

  # cands
  LFMM_empirical_results$V1[LFMM_empirical_results$LFMM_empirical_results=='TRUE'] <- 'green'
  LFMM_empirical_results$V1[LFMM_empirical_results$LFMM_empirical_results=='FALSE']  <- 'orange2'
  LFMM_empirical_results <- subset(LFMM_empirical_results, SNP %in% LFMM_sel)
  
  # color snps by predictor
  all.snp <- rownames(species_binomial.rda$CCA$v)
  LFMM_test <- all.snp
  
   for (i in 1:length(LFMM_sel)) {
    foo <- match(LFMM_sel[i],LFMM_test)
    LFMM_test[foo] <- LFMM_empirical_results$V1[i]
  }
  
  LFMM_test[grep('_',LFMM_test)] <- '#f1eef6'

  empty <- LFMM_test
  empty[grep('#f1eef6',empty)] <- rgb(0,1,0, alpha=0) # transparent

  empty.outline <- ifelse(empty=='#00FF0000','#00FF0000','gray32')
  
  # count and report statistical significance of SNPs for the log file
  statistically_significant_SNPs <- sum(str_count(LFMM_empirical_results$V1, pattern = "green"))
  non_statistically_significant_SNPs <- sum(str_count(LFMM_empirical_results$V1, pattern = "orange2"))
  cat('Number of statistically significant LFMM candidate SNPs: ',statistically_significant_SNPs,'\n', file=log_file, append=T)
  cat('Number of non-statistically significant LFMM candidate SNPs: ',non_statistically_significant_SNPs,'\n', file=log_file, append=T)

  ###### check LFMM_test against LFMM
  LFMM_test_test <- LFMM
  LFMM_test_test[LFMM_test_test!='#00FF0000'] <- 'green'
  LFMM_test_test[LFMM_test_test=='#00FF0000'] <- '#f1eef6'
  
  #make sure the invalid SNPs are visible as well
  if (is.na(non_statistically_significant_SNPs)){
  LFMM_test_test[which(LFMM_test_test == 'green')[sample(1:length(which(LFMM_test_test == 'green')), 0)]] <- 'orange2'} else{
  LFMM_test_test[which(LFMM_test_test == 'green')[sample(1:length(which(LFMM_test_test == 'green')), non_statistically_significant_SNPs*2)]] <- 'orange2'}
  
  empty <- LFMM_test_test
  empty[grep('#f1eef6',empty)] <- rgb(0,1,0, alpha=0) # transparent
  empty.outline <- ifelse(empty=='#00FF0000','#00FF0000','gray32')
  
  # Color by env predictor
  plot(species_binomial.rda, type='n', scaling=3, xlim=c(-0.5,0.5), ylim=c(-0.5,0.5), cex.axis=2, cex.lab=2)
  points(species_binomial.rda, display='species', pch=21, cex=2, col='gray32', bg=LFMM_test_test, scaling=3)
  points(species_binomial.rda, display='species', pch=21, cex=2, col=empty.outline, bg=empty, scaling=3)
  text(species_binomial.rda, scaling = 3, labels=c(params$env_predictor_1,params$env_predictor_2), display = 'bp', col='#0868ac', cex=1)
  bg <- c('#f1eef6','green','orange2')
  legend('topleft', title='Observed results significant at 95%?', legend = c('Non-adaptive', 'Yes', 'No'), bty = 'n', col='gray32', pch = 21, cex=2, pt.bg = bg)
  dev.off()

# last step - write out the validated SNPs as a separate file for rerunning the analysis in the next script
all_loci <- features 
LFMM_validated <- str_count(LFMM_test, pattern = "green")
RDA_validated <- str_count(RDA_test, pattern = "green")

# replace all 0s with FALSE, all 1s with TRUE
LFMM_validated <- grepl("1", LFMM_validated)
RDA_validated <- grepl("1", RDA_validated)

# subset
LFMM_validated <- all_loci[LFMM_validated]
RDA_validated <- all_loci[RDA_validated]

#write_out
all_statistically_validated_loci <- c(LFMM_validated, RDA_validated)
all_statistically_validated_loci <- str_sub(all_statistically_validated_loci,1,nchar(all_statistically_validated_loci)-2) # remove last two characters for each locus (e.g. _A) so they match the loci.overlap data

writeLines(all_statistically_validated_loci, paste0(output_path,species_binomial,'_adaptive_loci_validated.txt'), sep=' ')

cat(paste0('> Wrote only statistically validated SNPs to ./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_adaptive_loci_validated.txt\n\n'), file=log_file, append=T)
cat('> DONE! All sensitivity and simulations are complete!\n\n', file=log_file, append=T)
}
