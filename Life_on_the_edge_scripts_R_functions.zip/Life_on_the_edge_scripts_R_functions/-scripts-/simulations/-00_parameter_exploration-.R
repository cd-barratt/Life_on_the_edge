# Simulations for candidate adaptive SNPs

##### 01 - parameter exploration
## Run lfmm to find adaptive SNPs

rm(list=ls(all=TRUE))

# Load packages, set some directories
library(lfmm)         #?lfmm_ridge  # we use the 'ridge penalty' for GEA
library(vegan)        # all things ordination (RDA, dbRDA, PCA, etc.) & more!
library(qvalue)       # false discovery rate calculation
library(psych)        # nice pair plots
library(usdm)         # calculates variance inflation factors
library(adegenet)     # for reading plink files
library(stringr)

root_dir <- ('$YOUR_WORK_DIR')


setwd(root_dir)

genomic_data_path <- './-data-/genomic_data/'
spatial_data_path <- './-data-/spatial_data/'

colours <- c('#ff7f00','#1f78b4','#ffff33','#a6cee3','#33a02c','#e31a1c')

# read args
args <- commandArgs()
print(args)
species_binomial <- args[8]

# set params file
params_all <- read.delim('./Params.tsv')

# Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
params <- params_all[which(params_all$species_binomial==species_binomial),]
species_binomial <- params$species_binomial
  
log_file <- paste0('./-outputs-/log_files/',species_binomial,'.log')
species_binomial_path <- paste0('./-outputs-/',species_binomial,'/')
dir.create(paste0(species_binomial_path))
sensitivity_path <- paste0('./-outputs-/',species_binomial,'/Sensitivity/')
dir.create(paste0(sensitivity_path))
output_path <- paste0(sensitivity_path,'Adaptive_sensitivity/')
dir.create(paste0(output_path))

# create the new dirs for simulations
simulations_dir <- paste0(output_path,'-simulations-')
dir.create(paste0(simulations_dir))
dir.create(paste0(simulations_dir,'/spatial_simulations/'))
dir.create(paste0(simulations_dir,'/simulated_spatial_data/'))

 cat('--------------------------------------------------------------\n', file=log_file, append=T)
 cat('Running sensitivity and simulation analyses for GEAs...', '\n', file=log_file, append=T)
 cat('--------------------------------------------------------------\n', file=log_file, append=T)


#read the data that is extracted automatically from your predictor variables
env <- read.csv(paste0(spatial_data_path,species_binomial,'/',species_binomial,'_full_env_data.csv'))
env <- env[,c(params$env_predictor_1,params$env_predictor_2)] # subset env vars of interest tfor local adaptation analyses

# Look at correlations in predictors before we go on 
png(filename=paste0(output_path,species_binomial,'_env_correlations.png'), 
    type='cairo', units='cm', width=30, height=30, pointsize=12, res=300)
par(cex.main=2, cex.axis=2)
pairs.panels(env, scale=T, cex.cor=2)  # see ?pairs.panels for a description of these biplots
dev.off()
# correlation coefficients are in the upper right diagonal, with their size scaled to the value of |r|
vif(env) # check variance inflation factors, which assess multicollinearity, VIFs > 10 may be problematic; VIFs < 5 mean multicollinearity shouldn't be a problem

# LFMM - detection of adaptive SNPs
# Read in genomic data
gen <- read.table(paste0(genomic_data_path,species_binomial,'/',species_binomial,'_imp.lfmm'), header = FALSE) # read in lfmm file that was imputed in snmf

# Rename the SNPs names to match across all GEA analyses (LFMM, RDA and PCAdapt)
species_binomial.genlight <- read.PLINK(paste0(genomic_data_path,species_binomial,'/',species_binomial,'.raw'), map.file = paste0(genomic_data_path,species_binomial,'/',species_binomial,'.map'),
                                        quiet = FALSE, chunkSize = 1000, parallel = FALSE, n.cores = NULL)
features <- species_binomial.genlight@loc.names
colnames(gen) <- features
gen[1:6,1:10]  # Have a quick look: these are diploids (coded 0 or 1 or 2)
dim(gen)       # Individuals in rows, SNPs in columns  
 
K <- params$k
# your decision(S) for K here, this should be informed by the population structure analyses (sNMF and PCA)
# If K is ambiguous then you could run multiple times for different K values and look for overlap
# But may be useful for data where IBD is prevalent rather than discrete pop structure

# LFMM identify candidate SNPs
species_binomial.lfmm <- lfmm_ridge(Y=gen, X=env, K=K) # k defined based on pop structure results

# Built in function to calculate test statistics for all predictors:
pv <- lfmm_test(Y=gen, X=env, lfmm=species_binomial.lfmm, calibrate='gif')

# The GIFs for the predictors 
# 1=well calibrated, >1=liberal (too many small p-values), <1=conservative (too few small p-values)
# If GIFs are above high (e.g. >2), you can try increasing K
pv$gif 
names(pv)                  # automatically applies the gif to the zscores and pvalues
head(pv$pvalue)            # unadjusted p-values for our predictors
head(pv$calibrated.pvalue) # adjusted p-values for our predictors


# Below needs to be done for each predictor
# So this has been looped based on the number of predictors in the env dataframe
n <- ncol(env) # n=number of predictprs

for (i in 1:(n)) {
predictor <- i
par(mfrow=c(2,1))
hist(pv$pvalue[,predictor], main='unadjusted p-values')        
hist(pv$calibrated.pvalue[,predictor], main='adjusted p-values')
par(mfrow=c(1,1))

# gif adjustment if required (default = 1 so no change)
head(pv$score) # the zscores (test statistic) are stored in pv$score
zscore <- pv$score[,predictor] # zscores 
(gif <- pv$gif[predictor])     # default GIF for this predictor

scale_gif <- params$scale_gif_lfmm
new.gif <- (gif*scale_gif)               # choose/change your modified GIF

# Manual adjustment:
adj.pv <- pchisq(zscore^2/new.gif, df=1, lower = FALSE)

png(filename=paste0(output_path,species_binomial,'_LFMM_p_value_distribution_',names(env[i]),'.png'), 
    type='cairo', units='cm', width=30, height=30, pointsize=12, res=300)
par(mar=c(5,3,3,3))
par(cex.main=2, cex.axis=1.5)
par(mfrow=c(3,1))
hist(pv$pvalue[,predictor], main='unadjusted p-values', cex.axis=2, cex.lab=2)        
hist(pv$calibrated.pvalue[,predictor], main='adjusted p-values', cex.axis=2, cex.lab=2)
hist(adj.pv, main='REadjusted p-values', cex.axis=2, cex.lab=2)
dev.off()

# Proceed if you're happy with the new distribution, or tweak some more...
par(mfrow=c(1,1))

# LOOP THIS OVER A SELECTION OF FDR CUTOFFS
FDR_range <- as.character(seq(from=0.001, to=0.1, by=0.001))

for (FDR in FDR_range){
# Choosing a FDR (False Discovery Rate) cutoff
# qvalues and FDR 0.1 cutoff for env predictors 1:n

FDR_name <- gsub("\\.","_",FDR) # for construction of variables without a '.'

lhs1 <- paste('lfmm.qval', names(env[i]), sep='')
rhs1 <- paste ('qvalue(adj.pv)$qvalues')
eq1  <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))
  
lhs2 <- paste0("(length(lFDR.",FDR_name)
rhs2 <- paste0('which(lfmm.qval',names(env[i]),'< ',FDR,')))')
eq2  <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
eval(parse(text=eq2))

lhs3 <- paste0('lfmm.FDR',FDR,'.env',names(env[i]),sep='')
rhs3 <- paste0('colnames(gen)[lFDR.',FDR_name,']')
eq3  <- paste(paste(lhs3, rhs3, sep=' <- '), collapse='; ')
eval(parse(text=eq3))

list <- list((eval(parse(text=lhs3))))
lhs4 <- paste0('all_candidates_predictor_', names(env[i]), '_',FDR_name,sep='')
rhs4 <- paste0("sapply(list, '[', 1:length(list[[1]]))")
eq4  <- paste(paste(lhs4, rhs4, sep=' <- '), collapse='; ')
eval(parse(text=eq4))

predictor_name <- paste0('params$env_predictor_',i)

FDR_number <- gsub("\\_",".",FDR) # for construction of variables without a '.'
{
  
# Count candidates at each FDR iteration
lhs4.2<- paste0('n_SNPs_',eval(parse(text=paste0(predictor_name))),'_',FDR)
rhs4.2 <- paste0('length(',paste0("sapply(list, '[', 1:length(list[[1]])))"))
eq4.2 <- paste(paste(lhs4.2, rhs4.2, sep=' <- '), collapse='; ')
eval(parse(text=eq4.2))
  
lhs5 <- paste0('final_all_candidates_predictor_',eval(parse(text=predictor_name)),'_',FDR_name) 
rhs5 <- paste0('as.data.frame(all_candidates_predictor_',eval(parse(text=predictor_name)),'_',FDR_name,');')
eq5  <- paste(paste(lhs5, rhs5, sep=' <- '), collapse='; ')
eval(parse(text=eq5))

lhs6 <- paste0('final_all_candidates_predictor_',eval(parse(text=predictor_name)),'_',FDR_name,'$predictor')
rhs6 <- paste0('eval(parse(text=predictor_name))')
eq6  <- paste(paste(lhs6, rhs6, sep=' <- '), collapse='; ')
eval(parse(text=eq6))

lhs7 <- paste0('final_all_candidates_predictor_',eval(parse(text=predictor_name)),'_',FDR_name,'$FDR')
rhs7 <- paste0(FDR_number)
eq7 <- paste(paste(lhs7, rhs7, sep=' <- '), collapse='; ')
eval(parse(text=eq7))

lhs8 <- paste0('list_final_all_cands_',eval(parse(text=predictor_name)))
rhs8 <- paste0("mget(ls(.GlobalEnv, pattern = paste0('final_all_candidates_predictor_',eval(parse(text=predictor_name)))))")
eq8 <- paste(paste(lhs8, rhs8, sep=' <- '), collapse='; ')
eval(parse(text=eq8))

lhs9 <- paste0('final_all_cands_',eval(parse(text=predictor_name)))
rhs9 <- paste0('names(list_final_all_cands_',eval(parse(text=predictor_name)),')')
eq9 <- paste(paste(lhs9, rhs9, sep=' <- '), collapse='; ')
eval(parse(text=eq9))

lhs10 <- paste0('final_all_cands_',eval(parse(text=predictor_name)))
rhs10 <- paste0('toString(',lhs10,')')
eq10 <- paste(paste(lhs10, rhs10, sep=' <- '), collapse='; ')
eval(parse(text=eq10))

# add rename of colums otherwise there are rbind problems later
lhs10.2 <- paste0('colnames(final_all_candidates_predictor_',eval(parse(text=predictor_name)),'_',FDR_name,')')
rhs10.2 <- paste0("c('SNP','predictor','FDR')")
eq10.2 <- paste(paste(lhs10.2, rhs10.2, sep=' <- '), collapse='; ')
eval(parse(text=eq10.2))

lhs11 <- paste0('cand_',eval(parse(text=predictor_name)))
rhs11 <- paste0('as.data.frame(rbind(',eval(parse(text=(lhs10))),'))')
eq11 <- paste(paste(lhs11, rhs11, sep=' <- '), collapse='; ')
eval(parse(text=eq11))

# Calculate the False Positive Rate
#FPR = FP/FP+TN
TN <- ncol(gen)-eval(parse(text=paste0('(nrow(final_all_candidates_predictor_',eval(parse(text=predictor_name)),'_0_001))'))) # = all loci - actual TPs
TP <- ncol(gen)-TN # = all identified loci at a specified FDR cutoff (assume 0.01)

lhs12 <- paste0('FPR_',eval(parse(text=paste0('params$env_predictor_',i))),'_',FDR_number)
rhs12 <- paste0('((nrow(final_all_candidates_predictor_',eval(parse(text=predictor_name)),'_',FDR_name,')) - TP) / (((nrow(final_all_candidates_predictor_',eval(parse(text=predictor_name)),'_',FDR_name,')) - TP) + TN)')
eq12 <- paste(paste(lhs12, rhs12, sep=' <- '), collapse='; ')
eval(parse(text=eq12))

}
}
}


# Env1
list_of_FPRs <- paste0('FPR_',params$env_predictor_1,'_',FDR_range)
list_of_FPRs <- toString(list_of_FPRs)

lhs12 <- paste0('FPR_',params$env_predictor_1)
rhs12 <- paste0('cbind(',list_of_FPRs,')')
eq12 <- paste(paste(lhs12, rhs12, sep=' <- '), collapse='; ')
eval(parse(text=eq12))

lhs13 <- paste0('FPR_',params$env_predictor_1)
rhs13 <- paste0('as.data.frame(',lhs13,')')
eq13 <- paste(paste(lhs13, rhs13, sep=' <- '), collapse='; ')
eval(parse(text=eq13))

lhs14 <- paste0('FPR_',params$env_predictor_1)
rhs14 <- paste0('as.data.frame(t(',lhs14,'))')
eq14 <- paste(paste(lhs14, rhs14, sep=' <- '), collapse='; ')
eval(parse(text=eq14))

list_of_FDRs <- toString(FDR_range)

lhs15 <- paste0('FPR_',params$env_predictor_1,'$FDR_threshold')
rhs15 <- paste0('c(',list_of_FDRs,')')
eq15 <- paste(paste(lhs15, rhs15, sep=' <- '), collapse='; ')
eval(parse(text=eq15))

# add in the numbers of candidate SNPs per iteration
list_of_all_candidates_predictors_env_predictor_1 <- mget(ls(.GlobalEnv, pattern = paste0("n_SNPs_",params$env_predictor_1)))
list_of_all_candidates_predictors_env_predictor_1 <- toString(list_of_all_candidates_predictors_env_predictor_1)
n_cand_env_predictor_1 <- paste0(eval(parse(text=paste0('cbind(',list_of_all_candidates_predictors_env_predictor_1,')'))))
n_cand_env_predictor_1 <- as.numeric(n_cand_env_predictor_1)
n_cand_env_predictor_1 <- as.data.frame(n_cand_env_predictor_1)

FPR_bioclim_5 <- cbind(FPR_bioclim_5,n_cand_env_predictor_1)

lhs17 <- paste0('colnames(',lhs14,')')
rhs17 <- paste0("c('False_positive_rate','FDR_threshold','n_cands')")
eq17 <- paste(paste(lhs17, rhs17, sep=' <- '), collapse='; ')
eval(parse(text=eq17))

FPR_bioclim_5 <- FPR_bioclim_5[,c(2,3,1)] # reorder columns

# Env2
list_of_FPRs <- paste0('FPR_',params$env_predictor_2,'_',FDR_range)
list_of_FPRs <- toString(list_of_FPRs)

lhs12 <- paste0('FPR_',params$env_predictor_2)
rhs12 <- paste0('cbind(',list_of_FPRs,')')
eq12 <- paste(paste(lhs12, rhs12, sep=' <- '), collapse='; ')
eval(parse(text=eq12))

lhs13 <- paste0('FPR_',params$env_predictor_2)
rhs13 <- paste0('as.data.frame(',lhs13,')')
eq13 <- paste(paste(lhs13, rhs13, sep=' <- '), collapse='; ')
eval(parse(text=eq13))

lhs14 <- paste0('FPR_',params$env_predictor_2)
rhs14 <- paste0('as.data.frame(t(',lhs14,'))')
eq14 <- paste(paste(lhs14, rhs14, sep=' <- '), collapse='; ')
eval(parse(text=eq14))

list_of_FDRs <- toString(FDR_range)

lhs15 <- paste0('FPR_',params$env_predictor_2,'$FDR_threshold')
rhs15 <- paste0('c(',list_of_FDRs,')')
eq15 <- paste(paste(lhs15, rhs15, sep=' <- '), collapse='; ')
eval(parse(text=eq15))

# add in the numbers of candidate SNPs per iteration
list_of_all_candidates_predictors_env_predictor_2 <- mget(ls(.GlobalEnv, pattern = paste0("n_SNPs_",params$env_predictor_2)))
list_of_all_candidates_predictors_env_predictor_2 <- toString(list_of_all_candidates_predictors_env_predictor_2)
n_cand_env_predictor_2 <- paste0(eval(parse(text=paste0('cbind(',list_of_all_candidates_predictors_env_predictor_2,')'))))
n_cand_env_predictor_2 <- as.numeric(n_cand_env_predictor_2)
n_cand_env_predictor_2 <- as.data.frame(n_cand_env_predictor_2)

FPR_bioclim_18 <- cbind(FPR_bioclim_18,n_cand_env_predictor_2)

lhs17 <- paste0('colnames(',lhs14,')')
rhs17 <- paste0("c('False_positive_rate','FDR_threshold','n_cands')")
eq17 <- paste(paste(lhs17, rhs17, sep=' <- '), collapse='; ')
eval(parse(text=eq17))

FPR_bioclim_18 <- FPR_bioclim_18[,c(2,3,1)] # reorder columns

# Plot both together to evaluate an appropriate FDR to select (to reduce FPR) on a given dataset

png(paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/-simulations-/LFMM_sensitivity.png'), units='cm', height=30, width=15, res=300)
par(mfrow=c(2,1))

# plot FDR vs n_candidates for both env variables
max_ylim <- cbind(max(FPR_bioclim_5$n_cands), max(FPR_bioclim_18$n_cands))
max_ylim <- as.data.frame(max_ylim)
max_ylim <- max(max_ylim)

plot(FPR_bioclim_5$FDR_threshold, FPR_bioclim_5$n_cands, type="l", main = "LFMM number of candidate SNPs", xlab="LFMM FDR threshold", ylab="Number of candidate SNPs", col="steelblue1", lwd=2, xlim=c(0,0.1), ylim=c(0,max_ylim))
lines(FPR_bioclim_18$FDR_threshold, FPR_bioclim_18$n_cands,col="tomato", lwd=2)
grid(nx = 50, ny = 50,
     lty = 1,      # Grid line type
     col = "gray", # Grid line color
     lwd = 0.5)      # Grid line width

# plot FDR vs FPR for both env variables
plot(FPR_bioclim_5$FDR_threshold, FPR_bioclim_5$False_positive_rate, type="l", main = "LFMM False positive rate", xlab="LFMM FDR threshold", ylab="False Positive Rate", col="steelblue1", lwd=2, xlim=c(0,0.1), ylim=c(0,1))
lines(FPR_bioclim_18$FDR_threshold, FPR_bioclim_18$False_positive_rate,col="tomato", lwd=2)
grid(nx = 50, ny = 50,
     lty = 1,      # Grid line type
     col = "gray", # Grid line color
     lwd = 0.5)      # Grid line width

# plot(FPR_bioclim_18$FDR_threshold, FPR_bioclim_18$False_positive_rate, type="l", main = "FDR vs. FPR (zoomed)", xlab="LFMM FDR threshold", ylab="False Positive Rate", col="steelblue1", lwd=2, xlim=c(0,0.01), ylim=c(0,1))
# grid(nx = 50, ny = 50,
#      lty = 1,      # Grid line type
#      col = "gray", # Grid line color
#      lwd = 0.5)      # Grid line width
# lines(FPR_bioclim_5$FDR_threshold, FPR_bioclim_5$False_positive_rate,col="tomato", lwd=2)
dev.off()

write.csv(FPR_bioclim_5, paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/-simulations-/LFMM_sensitivity_bioclim_5.csv'), row.names=FALSE)
write.csv(FPR_bioclim_18, paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/-simulations-/LFMM_sensitivity_bioclim_18.csv'), row.names=FALSE)

cat('> LFMM sensitivity analyses DONE!\n', file=log_file, append=T)

# Run RDA to find adaptive SNPs

rm(list=ls(all=TRUE))

# Load packages, set some directories
library(adegenet)   # for reading files
library(vegan)
library(psych)      # nice pair plots
library(usdm)       # calculates variance inflation factors
library(robust)     # for robust mahalanobis distance calculation
library(qvalue)     # false discovery rate calculation
library(qpcR)       # for binding columns of candidate SNPs with different lengths

root_dir <- ('$YOUR_WORK_DIR')

setwd(root_dir)

genomic_data_path <- './-data-/genomic_data/'
spatial_data_path <- './-data-/spatial_data/'

colours <- c('#ff7f00','#1f78b4','#ffff33','#a6cee3','#33a02c','#e31a1c')

# read args
args <- commandArgs()
print(args)
species_binomial <- args[8]

# set params file
params_all <- read.delim('./Params.tsv')

# Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
params <- params_all[which(params_all$species_binomial==species_binomial),]
species_binomial <- params$species_binomial

log_file <- paste0('./-outputs-/log_files/',species_binomial,'.log')
sensitivity_path <- paste0('./-outputs-/',species_binomial,'/Sensitivity/')
output_path <- paste0(sensitivity_path,'Adaptive_sensitivity/')
dir.create(output_path)

##########
# Detection of adaptive SNPs

# Function to detect outliers from RDA: (courtesy of Brenna Forester)
# -------------------------------------
# r <- 1               # which RDA axis to process
# z <- 3               # how many st.dev. from mean loading
# x <- load.species_binomial       # loadings from RDA
# e <- species_binomial.env        # env - HARD CODED FOR 2 ENV.
# s <- species_binomial.scale      # snps

outliers <- function(r,z,x,e,s) {
  dat <- x[,r]
  lims <- mean(dat) + c(-1, 1) * z * sd(dat)    
  out.load <- dat[dat < lims[1] | dat > lims[2]]   #load
  out.name <- names(out.load)                      #SNPs
  
  if (length(out.load) > 0) {
    axis <- rep(r, length(out.load))
    outdat <- t(rbind(out.name, as.numeric(out.load), axis))
    snpcors <- matrix(NA, nrow=length(out.load), ncol=2*ncol(e))
    
    for (k in 1:length(out.load)) {
      outsnp <- s[,out.name[k]]
      snpcors[k,1] <- as.numeric(cor.test(outsnp, e[,1])$estimate)
      snpcors[k,2] <- as.numeric(cor.test(outsnp, e[,1])$p.value)
      snpcors[k,3] <- as.numeric(cor.test(outsnp, e[,2])$estimate)
      snpcors[k,4] <- as.numeric(cor.test(outsnp, e[,2])$p.value )  }
    outdata <- cbind.data.frame(outdat, snpcors)
    return(outdata)
  }
}    

# read in the env_data.csv
env <- read.csv(paste0(spatial_data_path,species_binomial,'/',species_binomial,'_full_env_data.csv'))
pop_assignment <- read.csv(paste0('./-outputs-/',species_binomial,'/Sensitivity/',species_binomial,'_pop_assignment_LEA.csv'))
lhs1 <- paste0('env',sep='')
rhs1 <- paste0('as.data.frame(cbind(env$Sample, pop_assignment$pop, env$',params$env_predictor_1, ',env$',params$env_predictor_2,'))')
eq1  <- paste0(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))

colnames(env) <- eval(parse(text=paste0("c('Sample', 'cluster', '",params$env_predictor_1,"','",params$env_predictor_2,"')")))

# Data prep
species_binomial.genlight <- read.PLINK(paste0(genomic_data_path,species_binomial,'/',species_binomial,'.raw'), map.file = paste0(genomic_data_path,species_binomial,'/',species_binomial,'.map'),
                                        quiet = FALSE, chunkSize = 1000, parallel = FALSE, n.cores = NULL)

identical(as.character(env[,1]), species_binomial.genlight@ind.names)

species <- as.matrix(species_binomial.genlight)  

species <- as.data.frame(species)

lhs1 <- paste0('species.full',sep='')
rhs1 <- paste0('as.data.frame(cbind(env$Sample, pop_assignment$pop, env$',params$env_predictor_1, ',env$',params$env_predictor_2,'))')
eq1  <- paste0(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))

#colnames(species.full) <- c('Sample', 'cluster', 'bioclim_5', 'bioclim_18')
colnames(species.full) <- eval(parse(text=paste0("c('Sample', 'cluster', '",params$env_predictor_1,"','",params$env_predictor_2,"')")))
species.full <- cbind(species.full,species)
species.full <- species.full[order(species.full$cluster),]
species.full$cluster <- as.numeric(species.full$cluster)

lhs1  <- paste0('species.full$',params$env_predictor_1,sep='')
rhs1  <- paste0('as.numeric(species.full$',params$env_predictor_1,')', sep='')
eq1   <- paste0(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))
lhs1  <- paste0('species.full$',params$env_predictor_2,sep='')
rhs1  <- paste0('as.numeric(species.full$',params$env_predictor_2,')', sep='')
eq1   <- paste0(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))

#Impute within clusters by taking the mean genotype across individuals

# Below code generalises the code used for Razgour et al. (2017), makes it flexible
nclust <- unique(species.full$cluster)
n    <- length(nclust)
lhs1  <- paste('species',    1:n,     sep='_')
rhs1  <- paste('species.full[species.full$cluster==',1:n,', c(-1:-4)]', sep='')
eq1   <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))

n    <- length(nclust)
lhs2  <- paste('cMr')
rhs2  <- paste('round(colMeans(species_',1:n,', na.rm =TRUE)); indx <- which(is.na(species_',1:n, '), arr.ind=TRUE); species_' ,1:n, '[indx] <- cMr[indx[,2]]', sep='')
eq2   <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
eval(parse(text=eq2))

lhs3  <- paste('rbind(')
rhs3 <- capture.output(cat(lhs1, sep=','))
eq3 <- paste0(lhs3,rhs3,')')
eval(parse(text=eq3))

species_binomial.imp <- eval(parse(text=eq3))

identical(as.character(species.full[,1]), row.names(species_binomial.imp))
species_binomial.env <- species.full[,3:4]
colnames(species_binomial.env) <- c(params$env_predictor_1, params$env_predictor_2)

# Rename the SNPs names to match across lfmm, RDA and PCAdapt analyses 
features <- species_binomial.genlight@loc.names
colnames(species_binomial.imp) <- features
inds <- species_binomial.genlight@ind.names
rownames(species_binomial.env) <- inds

# Run the RDA
species_binomial.rda <- rda(species_binomial.imp ~ ., data=species_binomial.env, scale=T)  
species_binomial.rda
RsquareAdj(species_binomial.rda)
summary(eigenvals(species_binomial.rda, model = 'constrained'))
screeplot(species_binomial.rda)

axes <- params$rda_axes

# Check predictors are not too highly correlated

vif.cca(species_binomial.rda) 

# Plot the RDA
colorby <- species.full[,2]

clusters <- lhs1
clusters <- toString(clusters)
clusters <- gsub('species','Cluster',clusters)

legend_text <- gsub('Cluster',"'Cluster", clusters)
legend_text <- gsub(',',"',", legend_text)
legend_text <- paste0(legend_text,"'")
legend_text <- paste0('c(',legend_text,')')
legend_text <- toString(legend_text)                
levels(colorby) <- paste0('c(',clusters,')')

png(filename=paste0(output_path,species_binomial,'_RDA_plot.png'), 
    type='cairo', units='cm', width=40, height=20, pointsize=12, res=300)
par(cex.main=2, cex.axis=1.5)
par(mfrow=c(1,2))
par(mar=c(5,5,5,5))
plot(species_binomial.rda, type='n', scaling=3, cex.lab=2, main = paste0(species_binomial))
points(species_binomial.rda, display='species', pch=20, cex=0.7, col='gray32', scaling=3)
points(species_binomial.rda, display='sites', pch=21, cex=1.3, col='gray32',scaling=3, bg=colours[colorby])
text(species_binomial.rda, scaling = 3, labels=c(params$env_predictor_1,params$env_predictor_2), display = 'bp', col='#0868ac', cex=1.1)
legend('topleft', legend = eval(parse(text=legend_text)), bty = 'n', col='gray32', pch = 21, cex=1.3, pt.bg = colours)
screeplot(species_binomial.rda, main = 'Screeplot')
dev.off()

# species_binomial outlier detection
# all candidates
load.species_binomial <- summary(species_binomial.rda)$species[,1:2]  # loadings on constrained axes
n_predictors <- ncol(species_binomial.env)

# LOOP the code to do different SD thresholds

#SD_range <- as.character(seq(from=2, to=3.98, by=0.02))
SD_range <- as.character(seq(from=1, to=2.5, by=0.025))
#SD_range <- rev(SD_range) # invert the range so it goes from stringent -> relaxed SDs

for (SD in SD_range){
  # Choosing a SD (mean +- SD loading from the mean) cutoff

SD_name <- gsub("\\.","_",SD) # for construction of variables without a '.'

lhs4 <- paste0('cand_',1:n_predictors)
rhs4 <- paste0('outliers(',1:n_predictors, ',',SD,',load.species_binomial, species_binomial.env, species_binomial.imp)')
eq4 <- paste(paste(lhs4,rhs4, sep=' <- '), collapse='; ')
eval(parse(text=eq4))

lhs4 <- toString(lhs4)
species_binomial.cand <- rbind.data.frame(cand_1,cand_2)
lhs5 <- paste0('species_binomial.cand')
rhs5 <- paste0('rbind.data.frame(',lhs4,')')
eq5 <- paste(paste(lhs5,rhs5, sep=' <- '), collapse='; ')
eval(parse(text=eq5))

corr_text <- paste0('Corr-env',1:n_predictors)
p_value_text <- paste0('p-env',1:n_predictors)
corr_p_value_text <- paste0(paste(corr_text,p_value_text))
corr_p_value_text <- toString(corr_p_value_text)
corr_p_value_text <- gsub(" p",",p",corr_p_value_text)
corr_p_value_text <- gsub(" ",",",corr_p_value_text)
corr_p_value_text <- gsub(",,",",",corr_p_value_text)
corr_p_value_text <- gsub(",","','",corr_p_value_text)
corr_p_value_text <- paste0("'",corr_p_value_text)
corr_p_value_text <- paste0(corr_p_value_text,"'")

colnames_candidate_SNPs_first_three_columns <- c('SNP','Loading','Axis')

lhs6 <- paste0('colnames_candidate_SNPs_remaining_columns')
rhs6 <- paste0('c(',corr_p_value_text,')')
eq6 <- paste(paste(lhs6,rhs6, sep=' <- '), collapse='; ')
eval(parse(text=eq6))

colnames_candidate_SNPs <- c(paste0(colnames_candidate_SNPs_first_three_columns),paste0(colnames_candidate_SNPs_remaining_columns))

# add SD_threshold to each dataframe to keep track
species_binomial.cand$SD_threshold <- paste0(SD)

####
# if there are RDA SNPs identified, go on as normal, otherwise skip to the end
if (length(species_binomial.cand)!='0'){
  colnames(species_binomial.cand) <- paste0(colnames_candidate_SNPs)
  
  species_binomial.cand$SNP <- as.character(species_binomial.cand$SNP)
  species_binomial.cand$SNP[duplicated(species_binomial.cand$SNP)] # Check there are no duplicate detections
  
  # from here it needs slightly more generalising in case of extra environmental predictors (here uses 2)
  for (i in 1:length(species_binomial.cand$SNP)) {
    bar <- species_binomial.cand[i,]
    species_binomial.cand[i,8] <- names(which.max(abs(bar[c(4,6)]))) # gives the variable
  }
  colnames(species_binomial.cand)[8] <- 'Max_corr'
  
  # round to 2 dp for correlations
  species_binomial.cand$`Corr-env1` <- round(species_binomial.cand$`Corr-env1`,2)
  species_binomial.cand$`Corr-env2` <- round(species_binomial.cand$`Corr-env2`,2)
  
  species_binomial.cand$SD <- SD
  
  # instead of writing out, store it
  #  write.csv(species_binomial.cand, file=paste0(output_path, species_binomial,'_RDA_candidate_SNPs_by_predictor_SD_',SD,'.csv'), row.names=F)

  lhs7 <- paste0('species_binomial.cand_',SD)
  rhs7 <- 'species_binomial.cand'
  eq7 <- paste(paste(lhs7,rhs7, sep=' <- '), collapse='; ')
  eval(parse(text=eq7))
  
  # Count candidates at each SD iteration
  lhs8 <- paste0('n_SNPs_','SD_',SD,'_',eval(parse(text=paste0('params$env_predictor_1'))))
  rhs8 <- paste0('length(which(species_binomial.cand_',SD,'$Max_corr=="Corr-env1"))')
  eq8 <- paste(paste(lhs8,rhs8, sep=' <- '), collapse='; ')
  eval(parse(text=eq8))
  
  lhs9 <- paste0('n_SNPs_','SD_',SD,'_',eval(parse(text=paste0('params$env_predictor_2'))))
  rhs9 <- paste0('length(which(species_binomial.cand_',SD,'$Max_corr=="Corr-env2"))')
  eq9 <- paste(paste(lhs9,rhs9, sep=' <- '), collapse='; ')
  eval(parse(text=eq9))
  
} 
}

  # Calculate the False Positive Rate
  #FPR = FP/FP+TN
  
  # most stringent SD - assume these are the 'true positives'
  most_stringent <- max(SD_range)
 
  # TPs (true-positives) 
  lhs10 <- paste0('TP_env_predictor_1')
  rhs10 <- paste0('n_SNPs_SD_',most_stringent,'_',params$env_predictor_1)
  eq10 <- paste(paste(lhs10,rhs10, sep=' <- '), collapse='; ')
  eval(parse(text=eq10))
  
  lhs11 <- paste0('TP_env_predictor_2')
  rhs11 <- paste0('n_SNPs_SD_',most_stringent,'_',params$env_predictor_2)
  eq11 <- paste(paste(lhs11,rhs11, sep=' <- '), collapse='; ')
  eval(parse(text=eq11))
  
  # TNs (true-negatives)
  TN_env_predictor_1 <- length(features)-TP_env_predictor_1 # = all loci - actual TNs
  TN_env_predictor_2 <- length(features)-TP_env_predictor_2 # = all loci - actual TNs

  for (SD in SD_range){
    lhs11 <- paste0('FPR_SD_',SD,'_bioclim_5')
    rhs11 <- paste0('(n_SNPs_SD_',SD,'_bioclim_5 - TP_env_predictor_1)/((n_SNPs_SD_',SD,'_bioclim_5 - TP_env_predictor_1) + TN_env_predictor_1)')
    eq11 <- paste(paste(lhs11,rhs11, sep=' <- '), collapse='; ')
    eval(parse(text=eq11))
   
    lhs11 <- paste0('FPR_SD_',SD,'_bioclim_18')
    rhs11 <- paste0('(n_SNPs_SD_',SD,'_bioclim_18 - TP_env_predictor_2)/((n_SNPs_SD_',SD,'_bioclim_18 - TP_env_predictor_2) + TN_env_predictor_2)')
    eq11 <- paste(paste(lhs11,rhs11, sep=' <- '), collapse='; ')
    eval(parse(text=eq11))
  }

# Make dataframe and populate it with relevant info for plotting

  # grab relevant variables (n_SNPs and FPRs across all SD iterations)
  n_SNPs_dataframes <- mget(ls(.GlobalEnv,pattern="n_SNPs_SD"))
  n_SNPs_env_predictor_1 <- mget(ls(n_SNPs_dataframes,pattern="bioclim_5"))
  n_SNPs_env_predictor_2 <- mget(ls(n_SNPs_dataframes,pattern="bioclim_18"))
  
  FPR_dataframes <- mget(ls(.GlobalEnv,pattern="FPR_SD_"))
  FPR_env_predictor_1 <- mget(ls(FPR_dataframes,pattern="bioclim_5"))
  FPR_env_predictor_2 <- mget(ls(FPR_dataframes,pattern="bioclim_18"))

# now make dataframe
  n <- toString(n_SNPs_env_predictor_1)
  n_SNPs_env_predictor_1 <- cbind(n)
  n_SNPs_env_predictor_1 <- as.data.frame(n_SNPs_env_predictor_1)
  n <- toString(n_SNPs_env_predictor_2)
  n_SNPs_env_predictor_2 <- cbind(n)
  n_SNPs_env_predictor_2 <- as.data.frame(n_SNPs_env_predictor_2)

  n <- toString(FPR_env_predictor_1)
  FPR_env_predictor_1 <- cbind(n)
  FPR_env_predictor_1 <- as.data.frame(FPR_env_predictor_1)

  n <- toString(FPR_env_predictor_2)
  FPR_env_predictor_2 <- cbind(n)
  FPR_env_predictor_2 <- as.data.frame(FPR_env_predictor_2)
  
  # env_predictor_1
  df_env_predictor_1 <- c(SD_range) # add the SD ranges tested
  df_env_predictor_1 <- as.data.frame( df_env_predictor_1)
  colnames(df_env_predictor_1) <- 'SD'
  df_env_predictor_1$n_SNPs <- eval(parse(text=paste0('c(',n_SNPs_env_predictor_1,')'))) # add the n_SNPs at each SD tested
  df_env_predictor_1$FPR <- eval(parse(text=paste0('c(',FPR_env_predictor_1,')'))) # add the FPR at each SD tested
  
  df_env_predictor_1$n_SNPs <- eval(parse(text=paste0('c(',n_SNPs_env_predictor_1,')'))) # add the n_SNPs at each SD tested
  df_env_predictor_1$FPR <- eval(parse(text=paste0('c(',FPR_env_predictor_1,')'))) # add the FPR at each SD tested

  # env_predictor_2
  df_env_predictor_2 <- c(SD_range) # add the SD ranges tested
  df_env_predictor_2 <- as.data.frame( df_env_predictor_2)
  colnames(df_env_predictor_2) <- 'SD'
  df_env_predictor_2$n_SNPs <- eval(parse(text=paste0('c(',n_SNPs_env_predictor_2,')'))) # add the n_SNPs at each SD tested
  df_env_predictor_2$FPR <- eval(parse(text=paste0('c(',FPR_env_predictor_2,')'))) # add the FPR at each SD tested
  
  
  # Plot both together to evaluate an appropriate FDR to select (to reduce FPR) on a given dataset
  
  png(paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/-simulations-/RDA_sensitivity.png'), units='cm', height=30, width=15, res=300)
  par(mfrow=c(2,1))
  
  # plot FDR vs n_candidates for both env variables
  max_ylim <- cbind(max(df_env_predictor_1$n_SNPs), max(df_env_predictor_2$n_SNPs))
  max_ylim <- as.data.frame(max_ylim)
  max_ylim <- max(max_ylim)
  
  SD_min <- as.numeric(min(SD_range)) # for x axis limits
  SD_max <- as.numeric(max(SD_range)) # for x axis limits
  
  max_ylim_FPRs <- cbind(max(df_env_predictor_1$FPR), max(df_env_predictor_2$FPR))
  max_ylim_FPRs <- as.data.frame(max_ylim_FPRs)
  max_ylim_FPRs <- max(max_ylim_FPRs)
  
  plot(df_env_predictor_1$SD, df_env_predictor_1$n_SNPs, type="l", main = "RDA number of candidate SNPs", xlab="RDA SD threshold", ylab="Number of candidate SNPs", col="steelblue1", lwd=2, xlim=c(SD_max,SD_min), ylim=c(0,max_ylim))
  axis(1, at = c(0,0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.1))
  lines(df_env_predictor_2$SD, df_env_predictor_2$n_SNPs,col="tomato", lwd=2)
  grid(nx = 50, ny = 50,
       lty = 1,      # Grid line type
       col = "gray", # Grid line color
       lwd = 0.5)      # Grid line width
  
  # plot SD vs FPR for both env variables
  plot(df_env_predictor_1$SD, df_env_predictor_1$FPR, type="l", main = "RDA False positive rate", xlab="RDA SD threshold", ylab="False Positive Rate", col="steelblue1", lwd=2, xlim=c(SD_max,SD_min), ylim=c(0,1))
  axis(1, at = c(0,0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.1))
  lines(df_env_predictor_2$SD, df_env_predictor_2$FPR,col="tomato", lwd=2)
  grid(nx = 50, ny = 50,
       lty = 1,      # Grid line type
       col = "gray", # Grid line color
       lwd = 0.5)      # Grid line width
  
  dev.off()

write.csv(df_env_predictor_1, paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/-simulations-/RDA_sensitivity_bioclim_5.csv'), row.names=FALSE)
write.csv(df_env_predictor_2, paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/-simulations-/RDA_sensitivity_bioclim_18.csv'), row.names=FALSE)
  
  cat('> RDA sensitivity analyses DONE!\n', file=log_file, append=T)

