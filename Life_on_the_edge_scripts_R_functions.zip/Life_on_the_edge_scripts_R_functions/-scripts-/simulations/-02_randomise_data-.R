# Randomisation simulations for candidate adaptive SNPs

# 1a. Generate 100 random spatial datasets instead of the actual locations from the empirical data 
# 1b. Extract the environmental data for each of these 100 spatial simulations 

rm(list=ls(all=TRUE))

library(raster)

root_dir <- ('$YOUR_WORK_DIR')


setwd(root_dir)

genomic_data_path <- './-data-/genomic_data/'
spatial_data_path <- './-data-/spatial_data/'

# read args
args <- commandArgs()
print(args)
species_binomial <- args[8]

# set params file
params_all <- read.delim('./Params.tsv')

# Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
params <- params_all[which(params_all$species_binomial==species_binomial),]
species_binomial <- params$species_binomial

log_file <- paste0('./-outputs-/log_files/',species_binomial,'.log')
sensitivity_path <- paste0('./-outputs-/',species_binomial,'/Sensitivity/')
dir.create(paste0(sensitivity_path))

cat('Generating 100 simulated datasets...\n', file=log_file, append=T)

# 1a. Generate 100 random spatial datasets (instead of the actual locations from the empirical data)
#load actual samples 
output_path <- paste0(sensitivity_path,'Adaptive_sensitivity/-simulations-/simulated_spatial_data/')
dir.create(paste0(output_path))

empirical_georeferenced_individuals <- read.csv(paste0(spatial_data_path,'/',species_binomial,'/',species_binomial,'_samples.csv'))
n_individuals <- nrow(empirical_georeferenced_individuals)

#load a predictor raster (any will do)
raster <- raster(paste0(spatial_data_path,'/',species_binomial, '/current_climate/bioclim_1.tif'))

library(dismo)

# generate and save the random spatial data
for (i in (1:100)){
  lhs1 <- paste0('simulation_',i)
  rhs1 <- paste0('randomPoints(raster,n=n_individuals)')
  eq1 <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
  eval(parse(text=eq1))
  eval(parse(text=paste0('simulation_',i,'<- cbind(empirical_georeferenced_individuals$Sample, simulation_',i,')'))) # match sample names to empirical data
  eval(parse(text=paste0('simulation_',i,'<- as.data.frame(simulation_',i,')')))
  eval(parse(text=paste0('colnames(simulation_',i, ') <- c("Sample", "LONG", "LAT")')))
  eval(parse(text=(paste0('write.csv(simulation_',i,', "./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/-simulations-/simulated_spatial_data/simulation_',i,'.csv", row.names=FALSE)')))) #save
  }

# 1b. Extract the full environmental data as well for each of the random points
# Prepares all spatial data

library(raster)
library(stringr)

spatial_dir <- paste0('./-data-/spatial_data/',species_binomial,'/')

# Predictor data
current_climate_data_path <- paste0(spatial_data_path,'/',species_binomial, '/current_climate/')
future_climate_data_path <- paste0(spatial_data_path,'/',species_binomial, '/future_climate/')

#### Prepare the environmental data for sdms - worldclim2 current and future - clip to appropriate extent per species

climate_dir <- paste0(spatial_dir,'/current_climate/')                                 
dir.create(file.path(climate_dir))

climate <- list.files(eval(parse(text=paste0("'",current_climate_data_path,"'"))),pattern='tif$',full.names = T)
climate<- raster::stack(climate)

# Loop over all 100 datasets to extract environmental data

for (i in (1:100)){
# grab the extent from the simulated presence data
presence_data <- read.csv(paste0('-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/-simulations-/simulated_spatial_data/simulation_',i,'.csv'))
presence_data <- presence_data[,-1] # discard row names

env <- as.data.frame(extract(climate, presence_data, buffer=2500, fun=mean)) # mean of 2500m radius is reasonable, captures coastal edge pixels
env_no_buff <- as.data.frame(extract(climate, presence_data))

env <- eval(parse(text=(paste0('cbind(simulation_',i,',env)'))))
env$land_cover <- env_no_buff$land_cover # make sure land cover is not averaged, otherwise run into problems later for circuitscape etc

write.csv(env,paste0('-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/-simulations-/simulated_spatial_data/simulation_',i,'_full_env_data.csv'))
}

cat('> DONE!\n', file=log_file, append=T)

