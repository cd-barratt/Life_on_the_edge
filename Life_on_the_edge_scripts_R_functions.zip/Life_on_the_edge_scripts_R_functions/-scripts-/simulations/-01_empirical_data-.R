# Run on empirical data with optimised params
## Run lfmm to find adaptive SNPs

rm(list=ls(all=TRUE))

# Load packages, set some directories
library(lfmm)         #?lfmm_ridge  # we use the 'ridge penalty' for GEA
library(vegan)        # all things ordination (RDA, dbRDA, PCA, etc.) & more!
library(qvalue)       # false discovery rate calculation
library(psych)        # nice pair plots
library(usdm)         # calculates variance inflation factors
library(adegenet)     # for reading plink files
library(stringr)

root_dir <- ('$YOUR_WORK_DIR')


setwd(root_dir)

# read args
args <- commandArgs()
print(args)
species_binomial <- args[8]

genomic_data_path <- './-data-/genomic_data/'
spatial_data_path <- paste0('./-outputs-/',species_binomial,'Sensitivity/Adaptive_sensitivity/')

colours <- c('#ff7f00','#1f78b4','#ffff33','#a6cee3','#33a02c','#e31a1c')

# set params file
params_all <- read.delim('./Params.tsv')

# Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
params <- params_all[which(params_all$species_binomial==species_binomial),]
species_binomial <- params$species_binomial

log_file <- paste0('./-outputs-/log_files/',species_binomial,'.log')

cat('> Re-running empirical analyses...\n', file=log_file, append=T)

  output_path <- paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/')
  dir.create(paste0(output_path))
    
  #read the data that is extracted automatically from your predictor variables
  env <- read.csv(paste0('-data-/spatial_data/',species_binomial,'/',species_binomial,'_full_env_data.csv'))
  env <- env[,c(params$env_predictor_1,params$env_predictor_2)] # subset env vars of interest for local adaptation analyses
  
  # Look at correlations in predictors before we go on 
  png(filename=paste0(output_path,species_binomial,'_env_correlations.png'), 
      type='cairo', units='cm', width=30, height=30, pointsize=12, res=300)
  par(cex.main=2, cex.axis=2)
  pairs.panels(env, scale=T, cex.cor=2)  # see ?pairs.panels for a description of these biplots
  dev.off()
  # correlation coefficients are in the upper right diagonal, with their size scaled to the value of |r|
  vif(env) # check variance inflation factors, which assess multicollinearity, VIFs > 10 may be problematic; VIFs < 5 mean multicollinearity shouldn't be a problem
  
   # LFMM - detection of adaptive SNPs
  
  # Read in genomic data
  gen <- read.table(paste0(genomic_data_path,species_binomial,'/',species_binomial,'_imp.lfmm'), header = FALSE) # read in lfmm file that was imputed in snmf
  
  # Rename the SNPs names to match across all GEA analyses (LFMM, RDA and PCAdapt)
  species_binomial.genlight <- read.PLINK(paste0(genomic_data_path,species_binomial,'/',species_binomial,'.raw'), map.file = paste0(genomic_data_path,species_binomial,'/',species_binomial,'.map'),
                                          quiet = FALSE, chunkSize = 1000, parallel = FALSE, n.cores = NULL)
  features <- species_binomial.genlight@loc.names
  colnames(gen) <- features
  gen[1:6,1:10]  # Have a quick look: these are diploids (coded 0 or 1 or 2)
  dim(gen)       # Individuals in rows, SNPs in columns  
  
   K <- params$k
  # your decision(S) for K here, this should be informed by the population structure analyses (sNMF and PCA)
  # If K is ambiguous then you could run multiple times for different K values and look for overlap
  # But may be useful for data where IBD is prevalent rather than discrete pop structure
  
  # LFMM identify candidate SNPs
  species_binomial.lfmm <- lfmm_ridge(Y=gen, X=env, K=K) # k defined based on pop structure results
  
  # Built in function to calculate test statistics for all predictors:
  pv <- lfmm_test(Y=gen, X=env, lfmm=species_binomial.lfmm, calibrate='gif')
  
  # The GIFs for the predictors 
  # 1=well calibrated, >1=liberal (too many small p-values), <1=conservative (too few small p-values)
  # If GIFs are above high (e.g. >2), you can try increasing K
  pv$gif 
  names(pv)                  # automatically applies the gif to the zscores and pvalues
  head(pv$pvalue)            # unadjusted p-values for our predictors
  head(pv$calibrated.pvalue) # adjusted p-values for our predictors
  
  # write out p-values per SNP to file
  write.csv(pv$calibrated.pvalue, paste0(output_path,species_binomial,'_LFMM_p_values.csv'))

    # Below needs to be done for each predictor
  # So this has been looped based on the number of predictors in the env dataframe
  n <- ncol(env) # n=number of predictors
  
  for (j in 1:(n)) {
    predictor <- j
    par(mfrow=c(2,1))
    hist(pv$pvalue[,predictor], main='unadjusted p-values')        
    hist(pv$calibrated.pvalue[,predictor], main='adjusted p-values')
    par(mfrow=c(1,1))
    
    # The default adjustment looks too conservative (the distribution is too flat).
    # Let's change the GIF and readjust the p-values:
    head(pv$score) # the zscores (test statistic) are stored in pv$score
    zscore <- pv$score[,predictor] # zscores 
    (gif <- pv$gif[predictor])     # default GIF for this predictor
    
    
    scale_gif <- params$scale_gif_lfmm
    new.gif <- (gif*scale_gif)               # choose/change your modified GIF
    
    # Manual adjustment:
    adj.pv <- pchisq(zscore^2/new.gif, df=1, lower = FALSE)
    
    png(filename=paste0(output_path,species_binomial,'_LFMM_p_value_distribution_',names(env[j]),'.png'), 
        type='cairo', units='cm', width=30, height=30, pointsize=12, res=300)
    par(mar=c(5,3,3,3))
    par(cex.main=2, cex.axis=1.5)
    par(mfrow=c(3,1))
    hist(pv$pvalue[,predictor], main='unadjusted p-values', cex.axis=2, cex.lab=2)        
    hist(pv$calibrated.pvalue[,predictor], main='adjusted p-values', cex.axis=2, cex.lab=2)
    hist(adj.pv, main='REadjusted p-values', cex.axis=2, cex.lab=2)
    dev.off()
    
    # Proceed if you're happy with the new distribution, or tweak some more...
    par(mfrow=c(1,1))
    
    # Choosing a FDR (False Discovery Rate) cutoff
    FDR_threshold <- params$lfmm_FDR_threshold

    # qvalues and FDR cutoff for env predictors 1:n
    lhs1 <- paste('lfmm.qval', names(env[j]), sep='')
    rhs1 <- paste ('qvalue(adj.pv)$qvalues')
    eq1  <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
    eval(parse(text=eq1))
    
    lhs2 <- paste('(length(lFDR')
    rhs2 <- paste0('which(lfmm.qval',names(env[j]),'< ',FDR_threshold,')))')
    eq2  <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
    eval(parse(text=eq2))
    
    lhs3 <- paste0('lfmm.FDR.env',names(env[j]),sep='')
    rhs3 <- paste('colnames(gen)[lFDR]')
    eq3  <- paste(paste(lhs3, rhs3, sep=' <- '), collapse='; ')
    eval(parse(text=eq3))
    
    eval(parse(text=lhs3))
    
    list <- list((eval(parse(text=lhs3))))
    lhs10 <- paste0('all_candidates_predictor_', names(env[j]), sep='')
    rhs10 <- paste0("sapply(list, '[', 1:length(list[[1]]))")
    eq10  <- paste(paste(lhs10, rhs10, sep=' <- '), collapse='; ')
    eval(parse(text=eq10))
    
    # check the all_candidates_predictor file actually has data in it, otherwise make a dummy row
    length_predictor_candidates <- eval(parse(text=paste0('length(all_candidates_predictor_', names(env[j]),')')))
    if ((length_predictor_candidates)<1) # ie there are no SNPs identified for this variable
    {
      # add dummy row if required and rename the columns
      lhs10.1 <- lhs10
      rhs10.1 <- paste0('cbind(0)')
      eq10.1  <- paste(paste(lhs10.1, rhs10.1, sep=' <- '), collapse='; ')
      eval(parse(text=eq10.1))
      # Write out the candidate SNPs to file
      # all candidates by environmental predictor
      # we here generalise the code
      # grab all_candidates_predictor_* names (however many there may be for each species)
      lhs10.2 <- paste0('colnames(all_candidates_predictor_', names(env[j]), ')', sep='')
      rhs10.2 <- paste0('c(lfmm.FDR.env',names(env[j]),')')
      rhs10.2 <- gsub("lfmm","'lfmm",rhs10.2)
      rhs10.2 <- gsub(",","',",rhs10.2)
      rhs10.2 <- gsub(")","')",rhs10.2)
      eq10.2  <- paste(paste(lhs10.2, rhs10.2, sep=' <- '), collapse='; ')
      eval(parse(text=eq10.2))
}
}
  
  list_of_all_candidates_predictors <- mget(ls(.GlobalEnv, pattern = "all_candidates_predictor_"))
  lhs10.3 <- names(list_of_all_candidates_predictors)
  lhs10.3 <- toString(lhs10.3)
  
  # column bind the FDR results above (0.1, 0.05, 0.01) for each predictor into a single dataframe 
  # Finding maximum length
  pred_1 <- names(list_of_all_candidates_predictors[1])
  pred_2 <- names(list_of_all_candidates_predictors[2])
  max_ln <- max(c(length(eval(parse(text=pred_1))), length((eval(parse(text=pred_2))))))
  
  # filling and binding (base R)
  
  # if adaptive SNPs are not found, make dummy dataframe per predictor
  if (length(all_candidates_predictor_bioclim_5)<1) {
    all_candidates_predictor_bioclim_5 <- as.data.frame(cbind('NA','NA')) 
    all_candidates_predictor_bioclim_5 <- as.matrix(all_candidates_predictor_bioclim_5) 
    }
  if (length(all_candidates_predictor_bioclim_18)<1) {
    all_candidates_predictor_bioclim_18 <- as.data.frame(cbind('NA','NA')) 
    all_candidates_predictor_bioclim_18 <- as.matrix(all_candidates_predictor_bioclim_18) 
  }
  # if adaptive SNPs are not found, make dummy all candidates dataframe
  if ((length(all_candidates_predictor_bioclim_18)<1) && (length(all_candidates_predictor_bioclim_5)<1)) {
    all_candidates_by_all_predictors <- as.data.frame(cbind('NA','NA','NA','NA','NA','NA','NA','NA')) 
    colnames(all_candidates_by_all_predictors) <- c('SNP', 'Loading', 'Axis', 'Corr-env1', 'p-env1', 'Corr-env2', 'p-env2', 'Max_corr')
    write.csv(all_candidates_by_all_predictors, paste0(output_path,species_binomial,'_LFMM_candidate_SNPs_by_predictor',params$lfmm_FDR_threshold,'.csv'))
    }else{
  lhs10.5 <- paste0('all_candidates_by_all_predictors', sep='')
  rhs10.5 <- paste0("data.frame(col1 = c(",pred_1,",rep(NA, max_ln - length(",pred_1,"))),
                                               col2 = c(",pred_2,",rep(NA, max_ln - length(",pred_2,"))))")
  eq10.5  <- paste(paste(lhs10.5, rhs10.5, sep=' <- '), collapse='; ')
  eval(parse(text=eq10.5))
  
  # add the column names
  colnames(all_candidates_by_all_predictors) <- c(pred_1,pred_2)
  
  #finally write out the files
  write.csv(all_candidates_by_all_predictors, paste0(output_path,species_binomial,'_LFMM_candidate_SNPs_by_predictor_FDR_',params$lfmm_FDR_threshold,'.csv'), row.names=FALSE)
}

cat('> LFMM empirical analyses DONE!\n', file=log_file, append=T)

###########################################################################################################
############################################### RDA ######################################################
###########################################################################################################
# Run RDA to find adaptive SNPs

rm(list=ls(all=TRUE))

# Load packages, set some directories
library(adegenet)   # for reading files
library(vegan)
library(psych)      # nice pair plots
library(usdm)       # calculates variance inflation factors
library(robust)     # for robust mahalanobis distance calculation
library(qvalue)     # false discovery rate calculation
library(qpcR)       # for binding columns of candidate SNPs with different lengths

root_dir <- ('$YOUR_WORK_DIR')

setwd(root_dir)

genomic_data_path <- './-data-/genomic_data/'
spatial_data_path <- './-data-/spatial_data/'

colours <- c('#ff7f00','#1f78b4','#ffff33','#a6cee3','#33a02c','#e31a1c')

# read args
 args <- commandArgs()
 print(args)
 species_binomial <- args[8]  # This may vary between systems depending on your HPC setup, the list of arguments will be printed at the beginning of your SLURM job logfile so if the jobs fail, make sure that this number matches the number in args[] that matches your species name

# set params file
params_all <- read.delim('./Params.tsv')

# Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
params <- params_all[which(params_all$species_binomial==species_binomial),]
species_binomial <- params$species_binomial

log_file <- paste0('./-outputs-/log_files/',species_binomial,'.log')
sensitivity_path <- paste0('./-outputs-/',species_binomial,'/Sensitivity/')
output_path <- paste0(sensitivity_path,'Adaptive_sensitivity/')
dir.create(output_path)

##########
# Detection of adaptive SNPs

# Function to detect outliers from RDA: (courtesy of Brenna Forester)
# -------------------------------------
# r <- 1               # which RDA axis to process
# z <- 3               # how many st.dev. from mean loading
# x <- load.species_binomial       # loadings from RDA
# e <- species_binomial.env        # env - HARD CODED FOR 2 ENV.
# s <- species_binomial.scale      # snps

outliers <- function(r,z,x,e,s) {
  dat <- x[,r]
  lims <- mean(dat) + c(-1, 1) * z * sd(dat)    
  out.load <- dat[dat < lims[1] | dat > lims[2]]   #load
  out.name <- names(out.load)                      #SNPs
  
  if (length(out.load) > 0) {
    axis <- rep(r, length(out.load))
    outdat <- t(rbind(out.name, as.numeric(out.load), axis))
    snpcors <- matrix(NA, nrow=length(out.load), ncol=2*ncol(e))
    
    for (k in 1:length(out.load)) {
      outsnp <- s[,out.name[k]]
      snpcors[k,1] <- as.numeric(cor.test(outsnp, e[,1])$estimate)
      snpcors[k,2] <- as.numeric(cor.test(outsnp, e[,1])$p.value)
      snpcors[k,3] <- as.numeric(cor.test(outsnp, e[,2])$estimate)
      snpcors[k,4] <- as.numeric(cor.test(outsnp, e[,2])$p.value )  }
    outdata <- cbind.data.frame(outdat, snpcors)
    return(outdata)
  }
}    

output_path <- paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/')

# read in the env_data.csv
#read the data that is extracted automatically from your predictor variables
env <- read.csv(paste0('-data-/spatial_data/',species_binomial,'/',species_binomial,'_full_env_data.csv'))
#env <- env[,c(params$env_predictor_1,params$env_predictor_2)] # subset env vars of interest for local adaptation analyses

pop_assignment <- read.csv(paste0('./-outputs-/',species_binomial,'/Sensitivity/',species_binomial,'_pop_assignment_LEA.csv'))
lhs1 <- paste0('env',sep='')
rhs1 <- paste0('as.data.frame(cbind(env$Sample, pop_assignment$pop, env$',params$env_predictor_1, ',env$',params$env_predictor_2,'))')
eq1  <- paste0(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))

colnames(env) <- eval(parse(text=paste0("c('Sample', 'cluster', '",params$env_predictor_1,"','",params$env_predictor_2,"')")))

# Data prep
species_binomial.genlight <- read.PLINK(paste0(genomic_data_path,species_binomial,'/',species_binomial,'.raw'), map.file = paste0(genomic_data_path,species_binomial,'/',species_binomial,'.map'),
                                        quiet = FALSE, chunkSize = 1000, parallel = FALSE, n.cores = NULL)

identical(as.character(env[,1]), species_binomial.genlight@ind.names)

species <- as.matrix(species_binomial.genlight)  

species <- as.data.frame(species)

lhs1 <- paste0('species.full',sep='')
rhs1 <- paste0('as.data.frame(cbind(env$Sample, pop_assignment$pop, env$',params$env_predictor_1, ',env$',params$env_predictor_2,'))')
eq1  <- paste0(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))

#colnames(species.full) <- c('Sample', 'cluster', 'bioclim_5', 'bioclim_18')
colnames(species.full) <- eval(parse(text=paste0("c('Sample', 'cluster', '",params$env_predictor_1,"','",params$env_predictor_2,"')")))
species.full <- cbind(species.full,species)
species.full <- species.full[order(species.full$cluster),]
species.full$cluster <- as.numeric(species.full$cluster)

lhs1  <- paste0('species.full$',params$env_predictor_1,sep='')
rhs1  <- paste0('as.numeric(species.full$',params$env_predictor_1,')', sep='')
eq1   <- paste0(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))
lhs1  <- paste0('species.full$',params$env_predictor_2,sep='')
rhs1  <- paste0('as.numeric(species.full$',params$env_predictor_2,')', sep='')
eq1   <- paste0(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))

#Impute within clusters by taking the mean genotype across individuals

# Below code generalises the code used for Razgour et al. (2017), makes it flexible
nclust <- unique(species.full$cluster)
n    <- length(nclust)
lhs1  <- paste('species',    1:n,     sep='_')
rhs1  <- paste('species.full[species.full$cluster==',1:n,', c(-1:-4)]', sep='')
eq1   <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))

n    <- length(nclust)
lhs2  <- paste('cMr')
rhs2  <- paste('round(colMeans(species_',1:n,', na.rm =TRUE)); indx <- which(is.na(species_',1:n, '), arr.ind=TRUE); species_' ,1:n, '[indx] <- cMr[indx[,2]]', sep='')
eq2   <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
eval(parse(text=eq2))

lhs3  <- paste('rbind(')
rhs3 <- capture.output(cat(lhs1, sep=','))
eq3 <- paste0(lhs3,rhs3,')')
eval(parse(text=eq3))

species_binomial.imp <- eval(parse(text=eq3))

identical(as.character(species.full[,1]), row.names(species_binomial.imp))
species_binomial.env <- species.full[,3:4]
colnames(species_binomial.env) <- c(params$env_predictor_1, params$env_predictor_2)

# Rename the SNPs names to match across lfmm, RDA and PCAdapt analyses 
features <- species_binomial.genlight@loc.names
colnames(species_binomial.imp) <- features
inds <- species_binomial.genlight@ind.names
rownames(species_binomial.env) <- inds

# Run the RDA
species_binomial.rda <- rda(species_binomial.imp ~ ., data=species_binomial.env, scale=T)  
species_binomial.rda
RsquareAdj(species_binomial.rda)
summary(eigenvals(species_binomial.rda, model = 'constrained'))
screeplot(species_binomial.rda)

axes <- params$rda_axes

####
# Check predictors are not too highly correlated

vif.cca(species_binomial.rda) 

# Plot the RDA
colorby <- species.full[,2]

clusters <- lhs1
clusters <- toString(clusters)
clusters <- gsub('species','Cluster',clusters)

legend_text <- gsub('Cluster',"'Cluster", clusters)
legend_text <- gsub(',',"',", legend_text)
legend_text <- paste0(legend_text,"'")
legend_text <- paste0('c(',legend_text,')')
legend_text <- toString(legend_text)                
levels(colorby) <- paste0('c(',clusters,')')

png(filename=paste0(output_path,species_binomial,'_RDA_plot.png'), 
    type='cairo', units='cm', width=40, height=20, pointsize=12, res=300)
par(cex.main=2, cex.axis=1.5)
par(mfrow=c(1,2))
par(mar=c(5,5,5,5))
plot(species_binomial.rda, type='n', scaling=3, cex.lab=2, main = paste0(species_binomial))
points(species_binomial.rda, display='species', pch=20, cex=0.7, col='gray32', scaling=3)
points(species_binomial.rda, display='sites', pch=21, cex=1.3, col='gray32',scaling=3, bg=colours[colorby])
text(species_binomial.rda, scaling = 3, labels=c(params$env_predictor_1,params$env_predictor_2), display = 'bp', col='#0868ac', cex=1.1)
legend('topleft', legend = eval(parse(text=legend_text)), bty = 'n', col='gray32', pch = 21, cex=1.3, pt.bg = colours)
screeplot(species_binomial.rda, main = 'Screeplot')
dev.off()

# species_binomial outlier detection
# all candidates
load.species_binomial <- summary(species_binomial.rda)$species[,1:2]  # loadings on constrained axes
n_predictors <- ncol(species_binomial.env)

SD <- params$rda_SD_threshold
  
  SD_name <- gsub("\\.","_",SD) # for construction of variables without a '.'
  
  lhs4 <- paste0('cand_',1:n_predictors)
  rhs4 <- paste0('outliers(',1:n_predictors, ',',0,',load.species_binomial, species_binomial.env, species_binomial.imp)')
  eq4 <- paste(paste(lhs4,rhs4, sep=' <- '), collapse='; ')
  eval(parse(text=eq4))
  
  lhs4 <- toString(lhs4)
  species_binomial.cand <- rbind.data.frame(cand_1,cand_2)
  lhs5 <- paste0('species_binomial.cand')
  rhs5 <- paste0('rbind.data.frame(',lhs4,')')
  eq5 <- paste(paste(lhs5,rhs5, sep=' <- '), collapse='; ')
  eval(parse(text=eq5))
  
  corr_text <- paste0('Corr_env',1:n_predictors)
  p_value_text <- paste0('p_env',1:n_predictors)
  corr_p_value_text <- paste0(paste(corr_text,p_value_text))
  corr_p_value_text <- toString(corr_p_value_text)
  corr_p_value_text <- gsub(" p",",p",corr_p_value_text)
  corr_p_value_text <- gsub(" ",",",corr_p_value_text)
  corr_p_value_text <- gsub(",,",",",corr_p_value_text)
  corr_p_value_text <- gsub(",","','",corr_p_value_text)
  corr_p_value_text <- paste0("'",corr_p_value_text)
  corr_p_value_text <- paste0(corr_p_value_text,"'")
  
  colnames_candidate_SNPs_first_three_columns <- c('SNP','Loading','Axis')
  
  lhs6 <- paste0('colnames_candidate_SNPs_remaining_columns')
  rhs6 <- paste0('c(',corr_p_value_text,')')
  eq6 <- paste(paste(lhs6,rhs6, sep=' <- '), collapse='; ')
  eval(parse(text=eq6))
  
  colnames_candidate_SNPs <- c(paste0(colnames_candidate_SNPs_first_three_columns),paste0(colnames_candidate_SNPs_remaining_columns))
  
  # add SD_threshold to each dataframe to keep track
  species_binomial.cand$SD_threshold <- paste0(SD)
  species_binomial.cand <- na.omit(species_binomial.cand)

  ####
  # if there are RDA SNPs identified, go on as normal, otherwise skip to the end
  if (length(species_binomial.cand)!='0'){
    colnames(species_binomial.cand) <- paste0(colnames_candidate_SNPs)
    
    species_binomial.cand$SNP <- as.character(species_binomial.cand$SNP)
    species_binomial.cand$SNP[duplicated(species_binomial.cand$SNP)] # Check there are no duplicate detections
    
    # from here it needs slightly more generalising in case of extra environmental predictors (here uses 2)
    for (i in 1:length(species_binomial.cand$SNP)) {
      bar <- species_binomial.cand[i,]
	  bar[is.na(bar)] <- 0
      species_binomial.cand[i,8] <- names(which.max(abs(bar[c(4,6)]))) # gives the variable
    }
    colnames(species_binomial.cand)[8] <- 'Max_corr'
    
    # round to 2 dp for correlations
    species_binomial.cand$`Corr_env1` <- round(species_binomial.cand$`Corr_env1`,2)
    species_binomial.cand$`Corr_env2` <- round(species_binomial.cand$`Corr_env2`,2)
    
    species_binomial.cand$SD <- SD
    
    # write_out
    write.csv(species_binomial.cand, file=paste0(output_path, species_binomial,'_RDA_candidate_SNPs_by_predictor_SD_',SD,'.csv'), row.names=F)
   
    # repeat the above code but with a SD of zero (0) so that all SNPs are assigned a p-value
    lhs4 <- paste0('all_snps_predictor_',1:n_predictors)
    rhs4 <- paste0('outliers(',1:n_predictors, ',',0,',load.species_binomial, species_binomial.env, species_binomial.imp)')
    eq4 <- paste(paste(lhs4,rhs4, sep=' <- '), collapse='; ')
    eval(parse(text=eq4))
    
    lhs4 <- toString(lhs4)
    species_binomial.cand <- rbind.data.frame(all_snps_predictor_1,all_snps_predictor_2)
    lhs5 <- paste0('all_snps')
    rhs5 <- paste0('rbind.data.frame(',lhs4,')')
    eq5 <- paste(paste(lhs5,rhs5, sep=' <- '), collapse='; ')
    eval(parse(text=eq5))
    
    corr_text <- paste0('Corr_env',1:n_predictors)
    p_value_text <- paste0('p_env',1:n_predictors)
    corr_p_value_text <- paste0(paste(corr_text,p_value_text))
    corr_p_value_text <- toString(corr_p_value_text)
    corr_p_value_text <- gsub(" p",",p",corr_p_value_text)
    corr_p_value_text <- gsub(" ",",",corr_p_value_text)
    corr_p_value_text <- gsub(",,",",",corr_p_value_text)
    corr_p_value_text <- gsub(",","','",corr_p_value_text)
    corr_p_value_text <- paste0("'",corr_p_value_text)
    corr_p_value_text <- paste0(corr_p_value_text,"'")
    
    colnames_candidate_SNPs_first_three_columns <- c('SNP','Loading','Axis')
    
    lhs6 <- paste0('colnames_candidate_SNPs_remaining_columns')
    rhs6 <- paste0('c(',corr_p_value_text,')')
    eq6 <- paste(paste(lhs6,rhs6, sep=' <- '), collapse='; ')
    eval(parse(text=eq6))
    
    colnames_candidate_SNPs <- c(paste0(colnames_candidate_SNPs_first_three_columns),paste0(colnames_candidate_SNPs_remaining_columns))
    
    # add SD_threshold to each dataframe to keep track
    all_snps$SD_threshold <- paste0(SD)
    
    ####
    # if there are RDA SNPs identified, go on as normal, otherwise skip to the end
    if (length(all_snps)!='0'){
      colnames(all_snps) <- paste0(colnames_candidate_SNPs)
      
      all_snps$SNP <- as.character(all_snps$SNP)
      all_snps$SNP[duplicated(all_snps$SNP)] # Check there are no duplicate detections
      all_snps[is.na(all_snps)] <- 0

      # from here it needs slightly more generalising in case of extra environmental predictors (here uses 2)
      for (i in 1:length(all_snps$SNP)) {
        bar <- all_snps[i,]
        all_snps[i,8] <- names(which.max(abs(bar[c(4,6)]))) # gives the variable
      }
      colnames(all_snps)[8] <- 'Max_corr'
      
      # round to 2 dp for correlations
      all_snps$`Corr_env1` <- round(all_snps$`Corr_env1`,2)
      all_snps$`Corr_env2` <- round(all_snps$`Corr_env2`,2)
      
      all_snps$SD <- 0

      # write_out
      write.csv(all_snps, file=paste0(output_path, species_binomial,'_RDA_all_SNPs_by_predictor_SD_0.csv'), row.names=F)
      
    }
      # and now carry on...
     
    # plot SNPs in RDA space
    # Summarise the candidate SNPs associated with each predictor
    table(species_binomial.cand$Max_corr)
    # Summarise the candidate SNPs associated with each RDA axis
    table(species_binomial.cand$Axis)
    
    # species_binomial outlier plot
    sel <- species_binomial.cand$SNP
    env <- species_binomial.cand$Max_corr
    env[env=='Corr_env1'] <- '#3585bb'
    env[env=='Corr_env2'] <- '#e53032'
    
    # color snps by predictor
    all.snp <- rownames(species_binomial.rda$CCA$v)
    test <- all.snp
    
    for (i in 1:length(sel)) {
      foo <- match(sel[i],test)
      test[foo] <- env[i]
    }
    
    test[grep('_',test)] <- '#f1eef6'
    
    empty <- test
    empty[grep('#f1eef6',empty)] <- rgb(0,1,0, alpha=0) # transparent
    
    empty.outline <- ifelse(empty=='#00FF0000','#00FF0000','gray32')
    
    # Color by env predictor
    png(filename=paste0(output_path,species_binomial,'_RDA_SNPs.png'), 
        type='cairo', units='cm', width=35, height=35, pointsize=12, res=300)
    par(cex.main=2, cex.axis=1.5)
    par(mar=c(5,5,5,5))
    plot(species_binomial.rda, type='n', scaling=3, xlim=c(-1.5,1), ylim=c(-1,1), cex.axis=2, cex.lab=2)
    points(species_binomial.rda, display='species', pch=21, cex=1.3, col='gray32', bg=test, scaling=3)
    points(species_binomial.rda, display='species', pch=21, cex=1.3, col=empty.outline, bg=empty, scaling=3)
    text(species_binomial.rda, scaling = 3, labels=c(params$env_predictor_1,params$env_predictor_2), display = 'bp', col='#0868ac', cex=2)
    bg <- c('#e53032','#3585bb')
    legend('topleft', legend = c(params$env_predictor_1,params$env_predictor_2), bty = 'n', col='gray32', pch = 21, cex=2, pt.bg = bg)
    dev.off()
    
    # plot the histograms of loadings per predictor
    # RDA outliers 
    load.rda <- scores(species_binomial.rda, choices=c(1:axes), display='species') # RDA loadings ('species') for axes 1:axes (defined above)
    
    # plot the histograms of loadings per predictor
    png(filename=paste0(output_path,species_binomial,'_RDA_histogram_loadings_SD_',params$rda_SD_threshold,'.png'), 
        type='cairo', units='cm', width=30, height=30, pointsize=12, res=300)
    par(cex.main=2, cex.axis=1.5, cex.lab=2)
    par(mar=c(5,5,5,5))
    par(mfrow=c(2,1))
    hist(load.rda[,1]) # histogram of loadings on RDA axis 1
    hist(load.rda[,2]) # histogram of loadings on RDA axis 2
    dev.off()
}

cat('> RDA empirical analyses DONE!\n', file=log_file, append=T)
