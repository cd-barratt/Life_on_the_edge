setwd('$YOUR_WORK_DIR')

# source functions
source('./R_functions/life_on_the_edge_functions.R')

landscape_barriers(species_binomial)
