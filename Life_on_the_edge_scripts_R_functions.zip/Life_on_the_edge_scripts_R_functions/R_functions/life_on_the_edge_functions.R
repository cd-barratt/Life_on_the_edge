# Functions for the Life on the edge toolbox
# Below functions wrap around scripts to perform each task
# simply specify the species name (Genus_species) and make sure parameters are set in Params.tsv file
# Each function always begins by setting working directories, reading in the species name for the analysis 
# and then reading the parameters for analyses from the relevant line of the Params.tsv file

# in parts of the code we use variables such as 'lhs' (left hand side) and 'rhs' (right hand side) which are then pasted together and parsed in R 
# we do this to avoid hard coding variables and keep the code flexible to a wide variation of user inputs and data

#############################################################################################################################################################################################
prepare_spatial_data <- function(species_binomial) {
#############################################################################################################################################################################################
# Prepares all spatial data
  
rm(list=ls(all=TRUE))

root_dir <- ('$YOUR_WORK_DIR')
setwd(root_dir)

# set params file
params_all <- read.delim('./Params.tsv')

  # read args
  args <- commandArgs()
  print(args)
  species_binomial <- args[8]  
  # This may vary between systems depending on your HPC setup, the list of arguments will be printed at the beginning of your SLURM job logfile so if the jobs fail, make sure that this number matches the number in args[] that matches your species name

# Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
params <- params_all[which(params_all$species_binomial==species_binomial),]
species_binomial <- params$species_binomial

library(rgbif)
library(dplyr)
library(raster)
library(rgdal)
library(sp)
library(maps)

# set/create dirs
setwd('$YOUR_WORK_DIR')
dir.create('./-outputs-/log_files', showWarnings = FALSE) 
dir.create(paste0('./-outputs-/',species_binomial))
dir.create(paste0('./-outputs-/',species_binomial,'/Exposure'))
dir.create(paste0('./-outputs-/',species_binomial,'/Exposure/SDMs'))

log_file <- paste0('./-outputs-/log_files/',species_binomial,'.log')
spatial_dir <- paste0('./-data-/spatial_data/',species_binomial,'/')
sdm_dir <- paste0('./-outputs-/',species_binomial,'/Exposure/SDMs/')
dir.create(file.path(spatial_dir))

  
cat('BEGIN...\n', file=log_file, append=T)
cat('Life on the edge pipeline started for',species_binomial,' at',format(Sys.time(),usetz = TRUE),'\n\n', file=log_file, append=T)
cat('--------------------------------------------------------------\n', file=log_file, append=T)
cat('Preparing spatial data...\n', file=log_file, append=T)
cat('--------------------------------------------------------------\n', file=log_file, append=T)
cat('> Preparing spatial presence data...\n', file=log_file, append=T)

# Spatial data - read presence data associated with genomic data and bind with GBIF records for the same species
# Read presence data (with genomic data)

library(CoordinateCleaner)
library(countrycode)
library(dplyr)
library(ggplot2)
library(rgbif)
library(sp)
library(rnaturalearthdata)

presences <- read.csv(paste0('./-data-/spatial_data/',species_binomial,'/',species_binomial,'_samples.csv'))
presences <- presences[,2:3] # just the longs/lats
presences$data_source <- 'genomic_data' # add column to denote genomic data origin

# if statement to bring in user specified presence data if requested
if ((params$user_specified_presences!='no')) {
 user_specified_presences <- read.csv(paste0(params$user_specified_presences))
 user_specified_presences$data_source <- 'user_specified'
 cat('Reading supplied presence data from file:', params$user_specified_presences, '\n', file=log_file, append=T)
 cat('Number of presences:', nrow(user_specified_presences), '\n', file=log_file, append=T)
 cat('Skipping downloading data from GBIF...', '\n', file=log_file, append=T)

presence_data <- rbind(presences,user_specified_presences) # now bind the datasets
} else {

# Obtain additional species presence data from GBIF 
species_name_for_GBIF <- gsub('_', ' ', species_binomial)
date_range <- paste0(params$gbif_date_limit_lower,",",params$gbif_date_limit_upper) # read in date range if specified

# if date range supplied in params then subset the records based on this, otherwise have no date restrictions
if (date_range != "NA,NA") {
dat <- occ_search(scientificName = species_name_for_GBIF, hasCoordinate = T, limit = params$gbif_limit, year=paste0(date_range))}else{
dat <- occ_search(scientificName = species_name_for_GBIF, hasCoordinate = T, limit = params$gbif_limit)}

dat_ne_lapply <- lapply(dat, 'as.data.frame')
dat_ne <- bind_rows(dat_ne_lapply)

# convert country code from ISO2c to ISO3c
dat_ne$countryCode <-  countrycode(dat_ne$countryCode, origin =  'iso2c', destination = 'iso3c')

# flag problems using Coordinate Cleaner package
dat_ne <- data.frame(dat_ne)

# remove records without coordinates
dat_ne <- dat_ne%>%
  filter(!is.na(decimalLongitude))%>%
  filter(!is.na(decimalLatitude))

flags <- clean_coordinates(x = dat_ne,
                           lon = "decimalLongitude",
                           lat = "decimalLatitude",
                           countries = "countryCode",
                           species = "species",
                           tests = c("capitals", "centroids", "equal","gbif", "institutions",
                                     "zeros", "countries")) # most test are on by default

#summary(flags)

# now remove geographic outliers (>1000km from nearest presence)
outliers_removed <- cc_outl(
  flags,
  lon = "decimalLongitude",
  lat = "decimalLatitude",
  species = "species",
  method = "distance",
  mltpl = 5,
  tdi = 1000,
  value = "clean",
  sampling_thresh = 0,
  verbose = TRUE,
  min_occs = 7,
  thinning = FALSE,
  thinning_res = 0.5
)

# update dat_ne with the cleaned version
dat_ne <- outliers_removed
dat_ne$count <- nrow(dat_ne)

if (dat_ne$count=='0'){
  presence_data <- rbind(presences) } else {
    gbif_data <- dat_ne[,c('decimalLongitude','decimalLatitude')]
    gbif_data$data_source <- 'GBIF' # add column to denote GBIF origin
    colnames(gbif_data) <- c('LONG', 'LAT', 'data_source')
  }

gbif_data_corrected <- gbif_data[, c(1, 2, 3)]
gbif_count <- gbif_data_corrected
gbif_count <- na.omit(gbif_count)
presence_data <- rbind(presences,gbif_data_corrected) # now bind the datasets

if (dat_ne$count=='0'){
  cat('> ** WARNING: 0 GBIF presences mean that analyses will be only based on the georeferenced genomic data\n', file=log_file, append=T) }
}

presence_data$species <- 1 # add column to denote 'presence'
colnames(presence_data) <- c('LONG','LAT','data_source','species')

presence_data[presence_data==0] <- NA # make sure no coordinates are 0 by assigining to NA then do na.omit
presence_data <- na.omit(presence_data)

write.csv(presence_data, paste0(spatial_dir,species_binomial,'_presence_data.csv'))

cat('> Spatial presence data downloaded and prepared successfully...\n', file=log_file, append=T)
cat('> Number of georeferenced genomic samples: ',nrow(presences), '\n', file=log_file, append=T)
if (exists('user_specified_presences')){
cat('> Number of user specified presences: ',nrow(user_specified_presences), '\n', file=log_file, append=T)
}
if (exists('gbif_count')){
cat('> Number of GBIF records downloaded: ',(nrow(gbif_count)), '\n', file=log_file, append=T)
}
cat('> Output presence data saved \n \n', file=log_file, append=T)
cat('> Preparing environmental predictor data...\n', file=log_file, append=T)

}

#############################################################################################################################################################################################
prepare_environmental_data <- function(species_binomial) {
#############################################################################################################################################################################################
# Prepares all spatial data
  
rm(list=ls(all=TRUE))
  
root_dir <- ('$YOUR_WORK_DIR')
setwd(root_dir)
  
# set params file
params_all <- read.delim('./Params.tsv')
  
# read args
args <- commandArgs()
print(args)
species_binomial <- args[8]  # This may vary between systems depending on your HPC setup, the list of arguments will be printed at the beginning of your SLURM job logfile so if the jobs fail, make sure that this number matches the number in args[] that matches your species name
  
# Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
params <- params_all[which(params_all$species_binomial==species_binomial),]
species_binomial <- params$species_binomial
spatial_dir <- paste0('./-data-/spatial_data/',species_binomial,'/')
sdm_dir <- paste0('./-outputs-/',species_binomial,'/Exposure/SDMs/')
log_file <- paste0('./-outputs-/log_files/',species_binomial,'.log')

library(raster)
library(stringr)
  
# Predictor data

# if statement to download worldclim data if requested
if ((params$env_data_download=='yes')) {
	climate_res <- params$climate_res
	ssp_scenario_download <- params$ssp_scenario_download
	gcm_download <- params$gcm_download
	time_proj_download <- params$time_proj_download

	# Set timeout for longer if needed (recommended)
	options(timeout=1000)

	# set the directories 
	current_climate_data_path <- ('./-data-/environmental_data/downloaded_current/')
	future_climate_data_path <- ('./-data-/environmental_data/downloaded_future/')

	dir.create(current_climate_data_path)
	dir.create(future_climate_data_path)

	# download current
	climate <- geodata::worldclim_global(var='bio', res=climate_res, version="2.1", path=current_climate_data_path)
	resolution <- res(climate)
	resolution <- resolution[1]

	# download future
	future_climate <- geodata::cmip6_world(model=gcm_download, ssp=ssp_scenario_download, time=time_proj_download, var='bio', res=climate_res, path=future_climate_path)
	future_resolution <- res(future_climate)
	future_resolution <- future_resolution[1]

	cat('Current and future climate data automatically downloaded from Worldclim\n', file=log_file, append=T)


	for(i in 1:nlayers(climate))
	{ writeRaster(climate[[i]], paste0(current_climate_data_path,"/bioclim_", i), "GTiff", overwrite = T)
	cat('Writing bioclim',i,'... \n') }

	for(i in 1:nlayers(future_climate))
	{ writeRaster(future_climate[[i]], paste0(future_climate_data_path,"/bioclim_", i), "GTiff", overwrite = T)
	cat('Writing bioclim',i,'... \n') }

} else {
 current_climate_data_path <- params$current_climate_data_path
 future_climate_data_path <- params$future_climate_data_path }

#### Prepare the environmental data for sdms - worldclim2 current and future - clip to appropriate extent per species

climate_dir <- paste0(spatial_dir,'/current_climate/')                                 
dir.create(file.path(climate_dir))

climate <- list.files(eval(parse(text=paste0("'",current_climate_data_path,"'"))),pattern='tif$',full.names = T)
climate<- raster::stack(climate)
resolution <- res(climate)
resolution <- resolution[1]

# grab the extent from the presence data itself
presence_data <- read.csv(paste0(spatial_dir,species_binomial,'_presence_data.csv'))
presence_data <- presence_data[,-1] # discard row names

min_lat <- min(presence_data$LAT)
max_lat <- max(presence_data$LAT)
min_long <- min(presence_data$LONG)
max_long <- max(presence_data$LONG)

# add a couple of degrees buffer around points
# (if lat/longs are negative the buffer needs to be subtracted here instead)

min_lat <- min_lat-2
max_lat <- max_lat+2
min_long <- min_long-2
max_long <- max_long+2

# if loop to take in defined coordinates if supplied in params file, otherwise take the bounding box around presence points
if(params$geographic_extent=='no'){
#extent <- c(min_lat,max_lat,min_long,max_long)
extent <- paste0(min_long,',',max_long,',',min_lat,',',max_lat)
template <- eval(parse(text=paste0('extent(',extent,')')))
} else {
  extent <- params$geographic_extent
  template <- eval(parse(text=paste0('extent(',extent,')')))
}

climate.crop <- crop(climate, template, snap='out')
for(i in 1:nlayers(climate.crop)){
  writeRaster(climate.crop[[i]], paste0(climate_dir, 'bioclim_', i), 'GTiff', overwrite = T)
  cat('Writing layer',i, 
      '... \n')
}

# the below lines do not run if the user downloads the env data
if ((params$env_data_download=='yes')) {
} else{
file.rename(paste0(climate_dir,'/bioclim_20.tif'), paste0(climate_dir,'/land_cover.tif'))
file.rename(paste0(climate_dir,'/bioclim_21.tif'), paste0(climate_dir,'/slope.tif'))
}

lst <- list.files((path=climate_dir),pattern='tif$',full.names = T)
climate <- stack(lst)

cat('> Environmental predictor data downloaded and prepared successfully...\n', file=log_file, append=T)
cat('> Current environmental data prepared at',resolution, 'km^2 resolution \n', file=log_file, append=T)

#Future climate data ###
future_climate_dir <- paste0(spatial_dir,'/future_climate/')                                 
dir.create(file.path(future_climate_dir))

future_climate <- list.files(eval(parse(text=paste0("'",future_climate_data_path,"'"))),pattern='tif$',full.names = T)
future_climate<- raster::stack(future_climate)

future_resolution <- res(future_climate)
future_resolution <- future_resolution[1]
future_climate.crop <- crop(future_climate, template, snap='out')
for(i in 1:nlayers(future_climate.crop)){
  writeRaster(future_climate.crop[[i]], paste0(future_climate_dir,'bioclim_', i), 'GTiff', overwrite = T)
  cat('Writing layer',i, 
      '... \n')
}

# the below lines do not run if the user downloads the env data
if ((params$env_data_download=='yes')) {
} else{
file.rename(paste0(future_climate_dir,'/bioclim_20.tif'), paste0(future_climate_dir,'/land_cover.tif'))
file.rename(paste0(future_climate_dir,'/bioclim_21.tif'), paste0(future_climate_dir,'/slope.tif'))
}

lst <- list.files(path=future_climate_dir,pattern='tif$',full.names = T) 
future_climate <- stack(lst)

cat('> Future environmental data prepared at ',resolution, ' km^2 resolution \n', file=log_file, append=T)
cat('> Output raster data saved \n\n', file=log_file, append=T)

# Now extract the current values for the predictors
cat('> Extracting predictor data for each sample (for later environmental dissimilarity and GEA analyses)... \n', file=log_file, append=T)

# extract the values from current climate rasters,
samples <- read.csv(paste0('-data-/spatial_data/',species_binomial,'/',species_binomial,'_samples.csv'), header=TRUE)
presences <- as.data.frame(cbind(samples$LONG,samples$LAT))
colnames(presences) <- c('LONG', 'LAT')

env <- as.data.frame(extract(climate, presences, buffer=2500, fun=mean)) # mean of 2500m radius is reasonable, captures coastal edge pixels
env_no_buff <- as.data.frame(extract(climate, presences))

env <- cbind(samples,env)
env$land_cover <- env_no_buff$land_cover # make sure land cover is not averaged, otherwise run into problems later for circuitscape etc

# extract names so that predictor variables can be properly named in the final env_data output file
lst
lst2 <- gsub(paste0(spatial_dir,'/future_climate/'),'',lst)
lst2 <- gsub('/','',lst2)
lst2 <- gsub('.tif','',lst2) # trailing \s can be problematic
colnames(env) <- c('Sample','LONG','LAT',lst2)
  
write.csv(env,paste0('-data-/spatial_data/',species_binomial,'/',species_binomial,'_full_env_data.csv'))


# extract the values from future climate rasters,
samples <- read.csv(paste0('-data-/spatial_data/',species_binomial,'/',species_binomial,'_samples.csv'), header=TRUE)
presences <- as.data.frame(cbind(samples$LONG,samples$LAT))
colnames(presences) <- c('LONG', 'LAT')

env_future <- as.data.frame(extract(future_climate, presences, buffer=2500, fun=mean)) # mean of 2500m radius is reasonable, captures coastal edge pixels
env_future_no_buff <- as.data.frame(extract(future_climate, presences))

env_future <- cbind(samples,env_future)
env_future$land_cover <- env_future_no_buff$land_cover # make sure land cover is not averaged, otherwise run into problems later for circuitscape etc

# extract names so that predictor variables can be properly named in the final env_data output file
lst
lst2 <- gsub(paste0(spatial_dir,'/future_climate/'),'',lst)
lst2 <- gsub('.tif','',lst2)
colnames(env_future) <- c('Sample','LONG','LAT',lst2)
  
write.csv(env_future,paste0('-data-/spatial_data/',species_binomial,'/',species_binomial,'_full_future_env_data.csv'))
cat('> DONE... \n', file=log_file, append=T)

}

#############################################################################################################################################################################################
spatially_rarefy_presences_and_create_background_data <- function(species_binomial) {
#############################################################################################################################################################################################
  rm(list=ls(all=TRUE))
  
  root_dir <- ('$YOUR_WORK_DIR')
  setwd(root_dir)
  
  # set params file
  params_all <- read.delim('./Params.tsv')
  
  # read args
  args <- commandArgs()
  print(args)
  species_binomial <- args[8]  # This may vary between systems depending on your HPC setup, the list of arguments will be printed at the beginning of your SLURM job logfile so if the jobs fail, make sure that this number matches the number in args[] that matches your species name
  
  # Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
  params <- params_all[which(params_all$species_binomial==species_binomial),]
  species_binomial <- params$species_binomial
  spatial_dir <- paste0('./-data-/spatial_data/',species_binomial,'/')
  sdm_dir <- paste0('./-outputs-/',species_binomial,'/Exposure/SDMs/')
  log_file <- paste0('./-outputs-/log_files/',species_binomial,'.log')
  climate_dir <- paste0(spatial_dir,'/current_climate/')                                 
  
cat('> Spatially rarefying presence data... \n', file=log_file, append=T)
  
##################
# Spatially rarefy the presence data to within a specified distance
library(spThin)
library(raster)
library(rgdal)
library(geodata)

sp_to_thin <- read.csv(paste0(spatial_dir,species_binomial,'_presence_data.csv'))
thinned_out_dir <- paste0(spatial_dir,species_binomial)

thin_parameter <- params$sp_rare_dist_km # in km- - any sample closer than this to another will be discarded

thinned_dataset <- thin( loc.data = sp_to_thin, 
                         lat.col = 'LAT', long.col = 'LONG', 
                         spec.col = 'species', 
                         thin.par = thin_parameter, reps = 1, 
                         locs.thinned.list.return = TRUE, 
                         write.files = TRUE, 
                         max.files = 5, 
                         out.dir = thinned_out_dir, 
                         out.base = species_binomial, 
                         write.log.file = TRUE,
                         log.file = paste0(thinned_out_dir,'_thinned.log'))

file.rename(paste0(spatial_dir,species_binomial,'/',species_binomial,'_thin1.csv'), paste0(spatial_dir,species_binomial,'_thinned.csv') )
unlink(thinned_out_dir, recursive = TRUE)

# Plot unthinned vs thinned presence records (just over the first predictor layer for easy visualisation)
presence_data <- read.csv(paste0(spatial_dir,species_binomial,'_presence_data.csv'))
coordinates(presence_data) <- ~ LONG + LAT
presences_thinned <- read.csv(paste0(spatial_dir,species_binomial,'_thinned.csv'))
coordinates(presences_thinned) <- ~ LONG + LAT

world_shapefile <- readOGR('./-data-/map_data/ne_50m_admin_0_countries.shp')
lst <- list.files((path=climate_dir),pattern='tif$',full.names = T)
climate <- stack(lst)
xmin <- climate@extent@xmin
xmax <- climate@extent@xmax
ymin <- climate@extent@ymin
ymax <- climate@extent@ymax
lhs <- paste0('cropped_shapefile')
rhs <- paste0('crop(world_shapefile, extent(',xmin,',',xmax,',',ymin,',',ymax,'))')
eq <- paste(paste(lhs, rhs, sep=' <- '), collapse='; ')
eval(parse(text=eq))

png(paste0(sdm_dir,species_binomial,'_presence_records.png'), units='cm', height=30, width=30, res=300)
par(mfrow=c(1,1))
par(cex.main=2, cex.axis=1.5)
g <- terra::graticule(5, 5, crs="+proj=latlon") # every 5 degreees
plot(climate[[1]], col = 'grey95', main = paste(species_binomial,'presences'), legend=FALSE)
plot(cropped_shapefile,  add=T, lwd=0.75)
plot(g, background=NULL, col="grey65", lty=2, retro=TRUE, add=TRUE)
terra::north()
plot(presence_data, pch=19, cex=1, col= 'goldenrod1', add=T)
plot(presences_thinned, pch=19, cex=0.75, col= 'steelblue1', add=T)
legend("bottomright", legend=c("raw_data", "retained after spatial rarefaction"),
col=c("goldenrod1", "steelblue1"), pch=c(19,19), cex=1.5)
dev.off()

cat('> Spatial rarefication of presence data completed sucessfully...\n', file=log_file, append=T)
cat('> Rarefied the presence data to retain only presences a minimum distance of',thin_parameter,'km from nearest sample\n', file=log_file, append=T)
cat('> Total number of presences before spatial rarefication:', nrow(presence_data),'\n',file=log_file, append=T)
cat('> Total number of presences after spatial rarefication:', nrow(presences_thinned),'\n',file=log_file, append=T)
cat('> Output spatially rarefied presence data saved and plotted \n\n', file=log_file, append=T)

cat('> Generating and plotting random background (pseudoabsence) points for species distribution modelling...\n', file=log_file, append=T)

# Generate and plot random background points (pseudoabsence) data for SDMs within a specified buffer around presence points
library(dismo)
library(maptools)
library(sp)

# Determine geographic extent of our data
max.lon <- ceiling(max(presences_thinned$LONG))
min.lon <- floor(min(presences_thinned$LONG))
max.lat <- ceiling(max(presences_thinned$LAT))
min.lat <- floor(min(presences_thinned$LAT))
geographic.extent <- extent(x = c(min.lon, max.lon, min.lat, max.lat))

CRS <- CRS('+proj=longlat +datum=WGS84') 

sp.crop <- crop(presences_thinned, geographic.extent, snap='out')
sp.crop@proj4string <- CRS

buffer_distance_degrees = params$bg_buff_dist_degrees

buffer <- rgeos::gBuffer(sp.crop, width=buffer_distance_degrees)
buffer <- raster::aggregate(buffer) #dissolve
buffer@proj4string <- CRS

# grab the extent from the presence data itself
presence_data <- read.csv(paste0(spatial_dir,species_binomial,'_presence_data.csv'))
presence_data <- presence_data[,-1] # discard row names
min_lat <- min(presence_data$LAT)
max_lat <- max(presence_data$LAT)
min_long <- min(presence_data$LONG)
max_long <- max(presence_data$LONG)
# add a couple of degrees buffer around points
# if lat/longs are negative the buffer needs to be subtracted..
min_lat <- min_lat-2
max_lat <- max_lat+2
min_long <- min_long-2
max_long <- max_long+2

extent <- c(min_lat,max_lat,min_long,max_long)
extent <- paste0(min_long,',',max_long,',',min_lat,',',max_lat)
template <- eval(parse(text=paste0('extent(',extent,')')))

mask <- raster(paste0(spatial_dir,'current_climate/bioclim_1.tif'))
# resample this down to simplify background point selection
#climate_template <- raster::getData('worldclim', var='tmin', res=params$climate_res)
climate_template <- geodata::worldclim_global('worldclim', var='tmin', res=params$climate_res)
climate_template <- raster(climate_template) #transform back to raster not spatial raster
climate_template.crop <- crop(climate_template, template, snap='out')
mask <- resample(mask, climate_template.crop, method='bilinear')

template <- buffer
mask.crop <- crop(mask, template, snap='in') 
crop <- setValues(mask.crop, NA) 
template.r <- rasterize(template, crop) 
mask.masked <- mask(x=mask.crop, mask=template.r) 

# Randomly sample points (same number as our observed points)
# remove nodata from buffer raster and then count number of cells with env data, this will be the number of random background points chosen unless otherwise specified by user

ncell_modelling_area <- ncell(mask.masked)
ncell_background_buffer <- cellStats(mask.masked, function(i, ...) sum(!is.na(i)))

cat('> Number of cells in modelling area: ',ncell_modelling_area,'\n', file=file.path(log_file), append=T)
cat('> Number of cells in background buffer','(',buffer_distance_degrees,' degrees): ',ncell_background_buffer,'\n', file=file.path(log_file), append=T)
cat('> Generating background points from this region (n=',params$n_background_points,')\n', file=file.path(log_file), append=T)

number_of_bg_points <- params$n_background_points  # Choose how many background points to generate
number_of_bg_points <- as.integer(number_of_bg_points)

background <- dismo::randomPoints(mask = mask.masked,     # Provides resolution of sampling points
                           n = number_of_bg_points,      # Number of random points, n = nrow(presences_thinned) to match the background to occurrences
                           ext = template)             # Expands sampling a little bit
head(background)

write.csv(background,(paste0(sdm_dir,species_binomial,'_background_points.csv')))

# We can also visualize them on a map, like we did for the observed points:
# Plot the base map
png(paste0(sdm_dir,species_binomial,'_background_points.png'), units='cm', height=30, width=30, res=300)
par(mfrow=c(1,1))
par(cex.main=2, cex.axis=1.5)
g <- terra::graticule(5, 5, crs="+proj=latlon") # every 5 degreees
plot(climate[[1]], col = 'grey95', main = paste(species_binomial,'background points'), legend=FALSE)
plot(cropped_shapefile,  add=T, lwd=0.75)
plot(g, background=NULL, col="grey65", lty=2, retro=TRUE, add=TRUE)
points(background, col = 'grey30', pch = 19, cex = 0.25)
terra::north()
dev.off()
cat('> Background (pseudoabsence) data prepared successfully...\n', file=file.path(log_file), append=T)
cat('> ',number_of_bg_points,' background points generated in a buffer radius of', buffer_distance_degrees, 'degrees around presence points\n', file=file.path(log_file), append=T)
cat('> Output background points saved and plotted \n\n', file=log_file, append=T)

# if params$env_data is set to 'yes', resample the predictors down to match the template above (e.g. 2.5 min resolution)
if ((params$resample_env_data)=='yes') {
cat('> But wait... you chose to resample the environmental data down to ',params$climate_res,'degrees... \n', file=log_file, append=T)
mask <- raster(paste0(spatial_dir,'current_climate/bioclim_1.tif'))
# resample this down to simplify background point selection
#climate_template <- raster::getData('worldclim', var='tmin', res=params$climate_res)
climate_template <- geodata::worldclim_global('worldclim', var='tmin', res=params$climate_res)
climate_template <- raster(climate_template) #transform back to raster not spatial raster
climate_template.crop <- crop(climate_template, climate, snap='out')
mask <- resample(mask, climate_template.crop, method='bilinear')

# current - resample and replace existing environmental data
resampled_current <- resample(climate, mask, method='bilinear')
for(i in 1:nlayers(resampled_current)){
  writeRaster(resampled_current[[i]], paste0(climate_dir, eval(parse(text=paste0("names(resampled_current[[", i,"]])"))),".tif"),'GTiff', overwrite = TRUE)
  cat('Writing resampled current layer',i, 
      '... \n')
}

# future resample and replace existing environmental data
future_climate <- list.files(path=paste0(spatial_dir,'/future_climate/'),pattern='.tif$',full.names = T)
future_climate <- raster::stack(future_climate)

resampled_future <- resample(future_climate, mask, method='bilinear')
future_climate_dir <- paste0('./-data-/spatial_data/',species_binomial,'/future_climate/')
for(i in 1:nlayers(resampled_future)){
  writeRaster(resampled_future[[i]], paste0(future_climate_dir, eval(parse(text=paste0("names(resampled_future[[", i,"]])"))),".tif"),'GTiff', overwrite = TRUE)
  cat('Writing resampled future layer',i, 
      '... \n')
}

# overwrite existing env data with new resampled data
cat('> Environmental data resampled to new resolution for current and future conditions as requested... \n', file=log_file, append=T)
cat('> DONE... \n', file=log_file, append=T)
}


}

#############################################################################################################################################################################################
sdms_biomod2 <- function(species_binomial) {
#############################################################################################################################################################################################

# Builds sdms using biomod2
  
rm(list=ls(all=TRUE))

library(biomod2)
library(terra)
library(raster)
library(rgdal)
library(sp)

root_dir <- ('$YOUR_WORK_DIR')
setwd(root_dir)

# set params file
params_all <- read.delim('./Params.tsv')

  # read args
  args <- commandArgs()
  print(args)
  species_binomial <- args[8]  # This may vary between systems depending on your HPC setup, the list of arguments will be printed at the beginning of your SLURM job logfile so if the jobs fail, make sure that this number matches the number in args[] that matches your species name

# Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
params <- params_all[which(params_all$species_binomial==species_binomial),]
species_binomial <- params$species_binomial

spatial_dir <- paste0(root_dir,'-data-/spatial_data/',species_binomial,'/')
log_file <- paste0(root_dir,'./-outputs-/log_files/',species_binomial,'.log')
sdm_dir <- paste0(root_dir,'-outputs-/',species_binomial,'/Exposure/SDMs/')

# copy maxent.jar file to directory
file.copy(paste0(root_dir,'-data-/maxent.jar'), paste0(params$maxent_path,'/maxent.jar'))
setwd(sdm_dir)

############################
# Build species distribution models

cat('--------------------------------------------------------------\n', file=log_file, append=T)
cat('Species Distribution Modelling using biomod2 package...\n', file=log_file, append=T)
cat('--------------------------------------------------------------\n', file=log_file, append=T)

# read presences (thinned)
presences <- read.csv(paste0(spatial_dir,species_binomial,'_thinned.csv'))
presences <- presences[,c('LONG','LAT')] # keep only the coordinates
presences <- na.omit(presences)
presences$presence <- TRUE # add presences column, biomod needs this
pres_abs <- presences$presence
#presences <- presences[,1:2]

# read absences (already generated)
bg <- read.csv(paste0('./',species_binomial,'_background_points.csv'))
bg <- bg[,2:3]
bg$presence <- FALSE
colnames(bg) <- c('LONG', 'LAT', 'presence')

presence_absences <- rbind(presences,bg) # bind presences and absences to create PA table (all presences = 'TRUE', absences = 'FALSE)
#presence_absences <- presence_absences[,c(2,1,3)] # reorder columns so lat then long

# read predictors and rename them properly
 current_climate_lst <- list.files(path=paste0(spatial_dir,'/current_climate/'),pattern='.tif$',full.names = T)
 current_climate <- raster::stack(current_climate_lst)
 names_lst <- gsub(paste0(spatial_dir,'/current_climate/'),'',current_climate_lst)
 names_lst <- gsub('.tif','',names_lst)
 names(current_climate) <- names_lst
 
 future_climate_lst <- list.files(path=paste0(spatial_dir,'/future_climate/'),pattern='.tif$',full.names = T)
 future_climate <- raster::stack(future_climate_lst)
 names_lst <- gsub(paste0(spatial_dir,'/future_climate/'),'',future_climate_lst)
 names_lst <- gsub('.tif','',names_lst)
 names(future_climate) <- names_lst

# Reducing highly correlated variables (usng VIF) based on raster data extracted at presence points - only if yes in params file
if (params$perform_vif == 'yes') {
  library(usdm)
  # re-read presences (thinned) just for this step
  presences <- read.csv(paste0(spatial_dir,species_binomial,'_thinned.csv'))
  presences <- presences[,c('LONG','LAT')] # keep only the coordinates
  presences <- na.omit(presences)
  uncorrelated_vars <- raster::extract(current_climate, presences)
  uncorrelated_vars <- data.frame(uncorrelated_vars)
  
  vif <- vifstep(uncorrelated_vars)
  vif
  
  current_climate <- exclude(current_climate, vif)
  current_climate_spat_rast <- rast(current_climate)
  
  future_climate <- exclude(future_climate, vif)
  future_climate_spat_rast <- rast(future_climate)
} else {

# Using subset of current predictors from the full set - only if defined in params$subset_predictors
  if (params$subset_predictors != '') {
  lst_predictors <- params$subset_predictors
  lst_predictors <- paste0(params$subset_predictors,',') # add a comma to last element so it is captured in below code for adding file extensions
  lst_predictors <- gsub(",",".tif,",lst_predictors) # add file extensions
  lst_predictors <- unlist(strsplit(lst_predictors,",")) # split them in to list

# current
# append full path before it for current predictors
  for (i in 1:length(lst_predictors)){
    lhs <- paste0('lst_predictors[',i,']')
    rhs <- paste0("paste0('",spatial_dir,"/current_climate/',lst_predictors[",i,"])")
    eq <- paste(paste(lhs, rhs, sep=' <- '), collapse='; ')
    eval(parse(text=eq))
  }

current_climate <- raster::stack(lst_predictors)
# rename them to their proper names
lst_predictors <- params$subset_predictors
lst_predictors <- paste0(params$subset_predictors,',') # add a comma to last element so it is captured in below code for adding file extensions
lst_predictors <- unlist(strsplit(lst_predictors,",")) # split them in to list
names(current_climate) <- lst_predictors

    # subset the list based on params$subset_predictors
    current_lst_predictors <- params$subset_predictors
    current_lst_predictors <- paste0(params$subset_predictors,',') # add a comma to last element so it is captured in below code for adding file extensions
    current_lst_predictors <- gsub(",",".tif,",current_lst_predictors) # add file extensions
    current_lst_predictors <- unlist(strsplit(current_lst_predictors,",")) # split them in to list
    current_lst_predictors <- paste0(spatial_dir,'/current_climate/',current_lst_predictors) # add a comma to first element so it is captured in below code for adding file extensions
    
    current_climate_spat_rast <- rast(current_lst_predictors)
    
    # rename them to their proper names
    current_lst_predictors <- params$subset_predictors
    current_lst_predictors <- paste0(params$subset_predictors,',') # add a comma to last element so it is captured in below code for adding file extensions
    current_lst_predictors <- unlist(strsplit(current_lst_predictors,",")) # split them in to list
    names(current_climate_spat_rast) <- current_lst_predictors
    

# #future
# append full path before it for future predictors
lst_predictors <- params$subset_predictors
lst_predictors <- paste0(params$subset_predictors,',') # add a comma to last element so it is captured in below code for adding file extensions
lst_predictors <- gsub(",",".tif,",lst_predictors) # add file extensions
lst_predictors <- unlist(strsplit(lst_predictors,",")) # split them in to list

for (i in 1:length(lst_predictors)){
  lhs <- paste0('lst_predictors[',i,']')
  rhs <- paste0("paste0('",spatial_dir,"/future_climate/',lst_predictors[",i,"])")
  eq <- paste(paste(lhs, rhs, sep=' <- '), collapse='; ')
  eval(parse(text=eq))
}
future_climate <- raster::stack(lst_predictors)
# rename them to their proper names
lst_predictors <- params$subset_predictors
lst_predictors <- paste0(params$subset_predictors,',') # add a comma to last element so it is captured in below code for adding file extensions
lst_predictors <- unlist(strsplit(lst_predictors,",")) # split them in to list
names(future_climate) <- lst_predictors

    future_lst_predictors <- params$subset_predictors
    future_lst_predictors <- paste0(params$subset_predictors,',') # add a comma to last element so it is captured in below code for adding file extensions
    future_lst_predictors <- gsub(",",".tif,",future_lst_predictors) # add file extensions
    future_lst_predictors <- unlist(strsplit(future_lst_predictors,",")) # split them in to list
    future_lst_predictors <- paste0(spatial_dir,'/future_climate/',future_lst_predictors) # add a comma to first element so it is captured in below code for adding file extensions
    
    future_climate_spat_rast <- rast(future_lst_predictors)
    
    # rename them to their proper names
    future_lst_predictors <- params$subset_predictors
    future_lst_predictors <- paste0(params$subset_predictors,',') # add a comma to last element so it is captured in below code for adding file extensions
    future_lst_predictors <- unlist(strsplit(future_lst_predictors,",")) # split them in to list
    names(future_climate_spat_rast) <- future_lst_predictors   
	}
}

cat('> Predictor variables checked for autocorrelation using sample locations and Variance Inflation Factors...\n', file=log_file, append=T)
cat('> Predictors remaining:\n', file=log_file, append=T)
cat(paste0(capture.output(current_climate)), '\n', file=log_file, append=T)

# plot predictors
world_shapefile <- readOGR(paste0(root_dir,'./-data-/map_data/ne_50m_admin_0_countries.shp'))
xmin <- current_climate[[1]]@extent@xmin
xmax <- current_climate[[1]]@extent@xmax
ymin <- current_climate[[1]]@extent@ymin
ymax <- current_climate[[1]]@extent@ymax
lhs <- paste0('cropped_shapefile')
rhs <- paste0('crop(world_shapefile, extent(',xmin,',',xmax,',',ymin,',',ymax,'))')
eq <- paste(paste(lhs, rhs, sep=' <- '), collapse='; ')
eval(parse(text=eq))

# Plot predictors
# Flexible code to plot any number of layers (defined by the number of layers defined in the current_climate rasterstack)
png(paste0(species_binomial,'_SDM_predictors.png'), units='cm', height=30, width=30, res=300)
par(mar=c(3,3,3,10))
par(cex.main=2, cex.axis=1.5)
# calculate size of plot items required for your layers
 number_of_panels_required <- length(names(current_climate))
 sqrt_panels <- sqrt(number_of_panels_required)
 sqrt_panels <- ceiling(sqrt_panels) # round up
 par(mfrow=c(sqrt_panels,sqrt_panels))

g <- terra::graticule(5, 5, crs="+proj=latlon") # every 5 degreees
for (i in 1:length(names(current_climate))) {  
   eval(parse(text=(paste0("plot(current_climate[[",i,"]], main = '",eval(parse(text=(paste0("names(current_climate[[",i,"]])")))),"')"      ))))
plot(g, background=NULL, col="grey65", lty=2, retro=TRUE, add=TRUE)

}
dev.off()


# Format Data with true absences
presence_absences$presence[presence_absences$presence == 'TRUE'] <- 1
presence_absences$presence[presence_absences$presence == 'FALSE'] <- 0
presence_absences$presence <- as.numeric(presence_absences$presence)
presence_absences_xy <- presence_absences[,1:2]
presence_absences.PA <- ifelse(presence_absences$presence == 1, 1, NA)
colnames(presence_absences_xy) <- c('X_WGS84', 'Y_WGS84')

myPAtable <- data.frame(PA1 = ifelse(presence_absences$presence == 1, TRUE, FALSE),
                             PA2 = ifelse(presence_absences$presence == 1, TRUE, FALSE))
for (i in 1:ncol(myPAtable)) myPAtable[sample(which(myPAtable[, i] == FALSE), 100), i] = TRUE 

crs(current_climate_spat_rast) <- "+proj=longlat +datum=WGS84 +no_defs"
current_climate_spat_rast <- stack(current_climate_spat_rast)

myBiomodData <- BIOMOD_FormatingData(resp.var = presence_absences.PA,
                                       expl.var = current_climate_spat_rast, 
                                       resp.xy = presence_absences_xy,
                                       resp.name = species_binomial,
                                       PA.strategy = 'user.defined',
                                       PA.user.table = myPAtable)


bm_DefaultModelingOptions()

cat('> Building SDMs for SDM algorithms - ',params$biomod_algorithms, ', using', params$sdm_reps_per_algorithm,'replicates per algorithm\n', file=log_file, append=T)
cat('> Number of background points: ', nrow(bg), file=log_file, append=T)

# Create default modeling options
myBiomodOptions <- BIOMOD_ModelingOptions()
myBiomodOptions

#edit the maxent path (Doesn't like my dropbox path...)
myBiomodOptions <- BIOMOD_ModelingOptions(MAXENT = list(path_to_maxent.jar = params$maxent_path))
myBiomodCV <- BIOMOD_CrossValidation(bm.format = myBiomodData, nb.rep=10)
head(myBiomodCV)


models <- params$biomod_algorithms
models <- paste0("'",models)
models <- paste('c(',models,')')
models <- eval(parse(text=models))

# RUN MODELS
# Single models
myBiomodModelOut <- BIOMOD_Modeling(bm.format = myBiomodData,
                                    bm.options = myBiomodOptions,
                                    models = (models),
                                    nb.rep = params$sdm_reps_per_algorithm,
                                    #data.split.perc = params$data_split_percentage,
                                    data.split.table = myBiomodCV,
                                    var.import = 3,
                                    metric.eval = c('TSS','ROC'),
                                    do.full.models = FALSE)

myBiomodModelOut

# Get evaluation scores & variables importance
get_evaluations(myBiomodModelOut)
get_variables_importance(myBiomodModelOut)

# Several of these options can be uncommented to plot the relevant outputs, the default here is to print out the variable importance 

# Represent evaluation scores & variables importance
#png(paste0(species_binomial,'_biomod_model_algorithm_performance_general.png'), units='cm', height=30, width=30, res=300)
#bm_PlotEvalMean(bm.out = myBiomodModelOut)
#dev.off()
#png(paste0(species_binomial,'_biomod_model_algorithm_performance_boxplots.png'), units='cm', height=30, width=30, res=300)
#bm_PlotEvalBoxplot(bm.out = myBiomodModelOut, group.by = c('algo', 'algo'))
#dev.off()
#png(paste0(species_binomial,'_biomod_model_algorithm_performance_scatterplots.png'), units='cm', height=30, width=30, res=300)
#bm_PlotEvalBoxplot(bm.out = myBiomodModelOut, group.by = c('algo', 'run'))
#dev.off()
png(paste0(species_binomial,'_biomod_variable_importance_general.png'), units='cm', height=30, width=50, res=300)
par(cex.main=2, cex.axis=1.5)
bm_PlotVarImpBoxplot(bm.out = myBiomodModelOut, group.by = c('expl.var', 'algo', 'algo'))
dev.off()
#png(paste0(species_binomial,'_biomod_variable_importance_by_algorithm.png'), units='cm', height=30, width=30, res=300)
#bm_PlotVarImpBoxplot(bm.out = myBiomodModelOut, group.by = c('expl.var', 'algo', 'full.name'))
#dev.off()
#png(paste0(species_binomial,'_biomod_variable_importance_by_predictor.png'), units='cm', height=30, width=30, res=300)
#bm_PlotVarImpBoxplot(bm.out = myBiomodModelOut, group.by = c('algo', 'expl.var', 'full.name'))
#dev.off()
# Represent response curves
#png(paste0(species_binomial,'_biomod_response_curves_by_predictor_min.png'), units='cm', height=30, width=30, res=300)
#bm_PlotResponseCurves(bm.out = myBiomodModelOut, 
#                      models.chosen = get_built_models(myBiomodModelOut)[c(1:3, 12:14)],
#                      fixed.var = 'median')
#dev.off()
#png(paste0(species_binomial,'_biomod_response_curves_by_predictor_median.png'), units='cm', height=30, width=30, res=300)
#bm_PlotResponseCurves(bm.out = myBiomodModelOut, 
#                      models.chosen = get_built_models(myBiomodModelOut)[c(1:3, 12:14)],
 #                     fixed.var = 'min')
#dev.off()
#png(paste0(species_binomial,'_biomod_response_curves_by_predictor_median_probabilities.png'), units='cm', height=30, width=30, res=300)
#bm_PlotResponseCurves(bm.out = myBiomodModelOut, 
#                      models.chosen = get_built_models(myBiomodModelOut)[3],
#                      fixed.var = 'median',
#                      do.bivariate = TRUE)
#dev.off()


####Ensemble models
# Model ensemble models
myBiomodEM <- BIOMOD_EnsembleModeling(bm.mod = myBiomodModelOut,
                                      models.chosen = 'all',
                                      em.by = 'all',
                                      metric.select = c('ROC'),
                                      metric.select.thresh = c(params$ROC_min),
                                      var.import = 3,
                                      metric.eval = c('TSS', 'ROC'),
                                      prob.mean = TRUE,
                                      prob.median = TRUE,
                                      prob.cv = TRUE,
                                      prob.ci = TRUE,
                                      prob.ci.alpha = 0.05,
                                      committee.averaging = TRUE,
                                      prob.mean.weight = TRUE,
                                      prob.mean.weight.decay = 'proportional')
myBiomodEM

# Get evaluation scores & variable importances
get_evaluations(myBiomodEM)
get_variables_importance(myBiomodEM)

# Represent evaluation scores & variables importance
#png(paste0(species_binomial,'_biomod_ensemble_model_algorithm_performance_general.png'), units='cm', height=30, width=30, res=300)
#bm_PlotEvalMean(bm.out = myBiomodEM, group.by = 'full.name')
#dev.off()
#png(paste0(species_binomial,'_biomod_ensemble_model_algorithm_performance_boxplots.png'), units='cm', height=30, width=30, res=300)
#bm_PlotEvalBoxplot(bm.out = myBiomodEM, group.by = c('full.name', 'full.name'))
#dev.off()
png(paste0(species_binomial,'_biomod_ensemble_variable_importance_by_predictors_general.png'), units='cm', height=30, width=30, res=300)
bm_PlotVarImpBoxplot(bm.out = myBiomodEM, group.by = c('expl.var', 'full.name', 'full.name'))
dev.off()
#png(paste0(species_binomial,'_biomod_ensemble_variable_importance_by_predictors_boxplots.png'), units='cm', height=30, width=30, res=300)
#bm_PlotVarImpBoxplot(bm.out = myBiomodEM, group.by = c('expl.var', 'full.name', 'algo'))
#dev.off()
#png(paste0(species_binomial,'_biomod_ensemble_variable_importance_by_models_boxplots.png'), units='cm', height=30, width=30, res=300)
#bm_PlotVarImpBoxplot(bm.out = myBiomodEM, group.by = c('full.name', 'expl.var', 'algo'))
#dev.off()

# Represent response curves
#png(paste0(species_binomial,'_biomod_ensemble_response_curves_by_predictor_median.png'), units='cm', height=30, width=30, res=300)
#bm_PlotResponseCurves(bm.out = myBiomodEM, 
#                      models.chosen = get_built_models(myBiomodEM)[c(1, 6, 7)],
#                      fixed.var = 'median')
#dev.off()
#png(paste0(species_binomial,'_biomod_ensemble_response_curves_by_predictor_min.png'), units='cm', height=30, width=30, res=300)
#bm_PlotResponseCurves(bm.out = myBiomodEM, 
#                      models.chosen = get_built_models(myBiomodEM)[c(1, 6, 7)],
#                      fixed.var = 'min')
#dev.off()
#png(paste0(species_binomial,'_biomod_ensemble_response_curves_by_predictor_median_probabilities.png'), units='cm', height=30, width=30, res=300)
#bm_PlotResponseCurves(bm.out = myBiomodEM, 
#                      models.chosen = get_built_models(myBiomodEM)[7],
#                      fixed.var = 'median',
#                      do.bivariate = TRUE)
#dev.off()

# Ensemble with these "good models"
cat('> Building final ensemble model with passed thresholds ROC>', params$ROC_min,'...\n', file=log_file, append=T)

# ensure predictors are a rasterstack
current_climate_spat_rast <- stack(current_climate_spat_rast)
# Project ensemble models (building single projections) # i.e. the ensemble for current
myBiomodEM_current_Proj <- BIOMOD_EnsembleForecasting(bm.em = myBiomodEM,
                                                      proj.name = 'Current_EM',
                                                      new.env = current_climate_spat_rast, # current_climate_spat_rast
                                                      models.chosen = 'all',
                                                      metric.binary = 'all',
                                                      metric.filter = 'all',
                                                      build.clamping.mask = TRUE)

# ensure predictors are a rasterstack
future_climate_spat_rast <- stack(future_climate_spat_rast)
# Project ensemble models (building single projections) # i.e. the ensemble for the future
myBiomodEM_future_Proj <- BIOMOD_EnsembleForecasting(bm.em = myBiomodEM,
                                                     proj.name = 'Future_EM',
                                                     new.env = future_climate_spat_rast, # future_climate_spat_rast
                                                     models.chosen = 'all',
                                                     metric.binary = 'all',
                                                     metric.filter = 'all',
                                                     build.clamping.mask = TRUE)
myBiomodEM_current_Proj
#plot(myBiomodEM_current_Proj)

myBiomodEM_future_Proj
#plot(myBiomodEM_future_Proj)

current_ROC <- raster(paste0(getwd(),"/", myBiomodData@sp.name,"/proj_Current_EM/", "proj_Current_EM_", myBiomodData@sp.name, "_ensemble_ROCfilt.tif",sep=""))
current_ROC <- current_ROC/1000

future_ROC <- raster(paste0(getwd(),"/", myBiomodData@sp.name,"/proj_Future_EM/", "proj_Future_EM_", myBiomodData@sp.name, "_ensemble_ROCfilt.tif",sep=""))
future_ROC <- future_ROC/1000

sdm_colours <- colorRampPalette(c('midnightblue','seagreen','chartreuse3','chartreuse2','yellow','orange','indianred'))(100)
world_shapefile <- readOGR(paste0(root_dir,'/-data-/map_data/ne_50m_admin_0_countries.shp'))
xmin <- current_climate@extent@xmin
xmax <- current_climate@extent@xmax
ymin <- current_climate@extent@ymin
ymax <- current_climate@extent@ymax
lhs <- paste0('cropped_shapefile')
rhs <- paste0('crop(world_shapefile, extent(',xmin,',',xmax,',',ymin,',',ymax,'))')
eq <- paste(paste(lhs, rhs, sep=' <- '), collapse='; ')
eval(parse(text=eq))

# write out ensembles as rasters
writeRaster(current_ROC, filename=paste0(sdm_dir,species_binomial,'_ensemble_SDM_current.asc'), overwrite=TRUE)
writeRaster(future_ROC, filename=paste0(sdm_dir,species_binomial,'_ensemble_SDM_future.asc'), overwrite=TRUE)
cat('> Output SDMs (present and future) saved and plotted \n', file=log_file, append=T)

# plot with gridlines and north arrow
current_ROC <- raster(paste0(sdm_dir,species_binomial,'_ensemble_SDM_current.asc'))
future_ROC <- raster(paste0(sdm_dir,species_binomial,'_ensemble_SDM_future.asc'))

sdm_colours <- colorRampPalette(c('midnightblue','seagreen','chartreuse3','chartreuse2','yellow','orange','indianred'))(100)
world_shapefile <- readOGR(paste0(root_dir,'/-data-/map_data/ne_50m_admin_0_countries.shp'))
xmin <- current_climate@extent@xmin
xmax <- current_climate@extent@xmax
ymin <- current_climate@extent@ymin
ymax <- current_climate@extent@ymax
lhs <- paste0('cropped_shapefile')
rhs <- paste0('crop(world_shapefile, extent(',xmin,',',xmax,',',ymin,',',ymax,'))')
eq <- paste(paste(lhs, rhs, sep=' <- '), collapse='; ')
eval(parse(text=eq))

png(filename=paste0(sdm_dir,species_binomial,'_SDMs_current_and_future.png'),type='cairo', units='cm', width=50, height=30, pointsize=12, res=300) 
par(cex.main=2, cex.axis=1.5)
par(mfrow=c(1,2))
par(mar=c(5,5,5,10))
g <- terra::graticule(5, 5, crs="+proj=latlon") # every 5 degreees
plot(current_ROC, col=sdm_colours, zlim=c(0,1), main = "Current SDM")
plot(cropped_shapefile,  add=T, lwd=1.4)
points(presences, pch=21, cex=0.75, bg='darkorange3',col='black')
plot(g, background=NULL, col="grey65", lty=2, retro=TRUE, add=TRUE)
terra::north()
plot(future_ROC, col=sdm_colours, zlim=c(0,1), main = "Future SDM")
plot(cropped_shapefile,  add=T, lwd=1.4)
points(presences, pch=21, cex=0.75, bg='darkorange3',col='black')
plot(g, background=NULL, col="grey65", lty=2, retro=TRUE, add=TRUE)
terra::north()
dev.off()

cat('> SDMs completed...\n\n', file=log_file, append=T)

}
 
#############################################################################################################################################################################################
exposure <- function(species_binomial) {
#############################################################################################################################################################################################
  # Calculates environmental dissimilarity (current-future) and uses sdm results to quantify 'Exposure'
  
  rm(list=ls(all=TRUE))
  
  library(raster)
  library(rgdal)

  root_dir <- ('$YOUR_WORK_DIR')
  setwd(root_dir)
  
  # read args
  args <- commandArgs()
  print(args)
  species_binomial <- args[8]  # This may vary between systems depending on your HPC setup, the list of arguments will be printed at the beginning of your SLURM job logfile so if the jobs fail, make sure that this number matches the number in args[] that matches your species name
  
  # set params file
  params_all <- read.delim('./Params.tsv')
  
  # Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
  params <- params_all[which(params_all$species_binomial==species_binomial),]
  species_binomial <- params$species_binomial
  
  log_file <- paste0('./-outputs-/log_files/',species_binomial,'.log')
  spatial_dir <- paste0('./-data-/spatial_data/',species_binomial,'/')
  sdm_dir <- paste0('./-outputs-/',species_binomial,'/Exposure/SDMs/')
  exposure_dir <- paste0('./-outputs-/',species_binomial,'/Exposure/')
  
  cat('--------------------------------------------------------------\n', file=log_file, append=T)
  cat('Calculating environmental dissimilarity and quantifying exposure...\n', file=log_file, append=T)
  cat('--------------------------------------------------------------\n', file=log_file, append=T)
  cat('> Reading SDMs and predictor variables for present and future (2070)...\n', file=log_file, append=T)
  
  # read rasters
  env_1_current <- raster(paste0('-data-/spatial_data/',species_binomial,'/current_climate/',params$env_predictor_1,'.tif'))
  env_1_future <- raster(paste0('-data-/spatial_data/',species_binomial,'/future_climate/',params$env_predictor_1,'.tif'))
  env_2_current <- raster(paste0('-data-/spatial_data/',species_binomial,'/current_climate/',params$env_predictor_2,'.tif'))
  env_2_future <- raster(paste0('-data-/spatial_data/',species_binomial,'/future_climate/',params$env_predictor_2,'.tif'))
  sdm_current <- raster(paste0(sdm_dir,species_binomial,'_ensemble_SDM_current.asc'))
  sdm_future <- raster(paste0(sdm_dir,species_binomial,'_ensemble_SDM_future.asc'))
  
  # double check that rasters match (nrows and extent) using resample and extent
  env_1_future = resample(env_1_future, env_1_current, "bilinear"); extent(env_1_future) <- extent(env_1_current)
  env_2_current = resample(env_2_current, env_1_current, "bilinear"); extent(env_2_current) <- extent(env_1_current)
  env_2_future = resample(env_2_future, env_1_current, "bilinear"); extent(env_2_future) <- extent(env_1_current)
  sdm_current = resample(sdm_current, env_1_current, "bilinear"); extent(sdm_current) <- extent(env_1_current)
  sdm_future = resample(sdm_future, env_1_current, "bilinear"); extent(sdm_future) <- extent(env_1_current)
  
  # change in sdms 
  sdm_dissimilarity <- overlay(sdm_current, sdm_future,fun = function(r1, r2) { return( r2 - r1) })
  # change in annual mean temperature 
  env_1_dissimilarity <- overlay(env_1_current, env_1_future,fun = function(r1, r2) { return( r2 - r1) })
  # change in annual precipitation 
  env_2_dissimilarity <- overlay(env_2_current, env_2_future,fun = function(r1, r2) { return( r2 - r1) })
  
  # plot current vs. future SDM dissimilarity
  sdm_colours <- colorRampPalette(c('red','orange', 'goldenrod1', 'white','lightgreen','green','forestgreen'))(100)
  temp_colours <- colorRampPalette(c('red','orange','lightyellow','white'))(100)
  precipitation_colours <- colorRampPalette(c('white','lightblue','blue','navy'))(100)
  world_shapefile <- readOGR('./-data-/map_data/ne_50m_admin_0_countries.shp')
  xmin <- sdm_current@extent@xmin
  xmax <- sdm_current@extent@xmax
  ymin <- sdm_current@extent@ymin
  ymax <- sdm_current@extent@ymax
  lhs <- paste0('cropped_shapefile')
  rhs <- paste0('crop(world_shapefile, extent(',xmin,',',xmax,',',ymin,',',ymax,'))')
  eq <- paste(paste(lhs, rhs, sep=' <- '), collapse='; ')
  eval(parse(text=eq))
  presences <- read.csv(paste0('-data-/spatial_data/',species_binomial,'/',species_binomial,'_samples.csv'), header=TRUE)
  presences <- presences[,c('LONG','LAT')] # keep only the coordinates
  presences <- na.omit(presences)
  
  png(filename=paste0(exposure_dir,species_binomial,'_environmental_dissimilarity_current_and_future.png'),type='cairo', units='cm', width=70, height=30, pointsize=12, res=300) 
  par(mfrow=c(1,3))
  par(cex.main=3, cex.axis=2.5)
  par(mar=c(3,3,3,10))
  g <- terra::graticule(5, 5, crs="+proj=latlon") # every 5 degreees
  plot(sdm_dissimilarity, zlim=c(-1,1), col=(sdm_colours), main = paste0('Current - future SDM dissimilarity'))
  plot(cropped_shapefile,  add=T, lwd=1.4)
  points(presences, pch=21, cex=1.6, bg='darkorange3',col='black')
  plot(g, background=NULL, col="grey65", lty=2, retro=TRUE, add=TRUE)
  terra::north()

  plot(env_1_dissimilarity, col=rev(temp_colours), main = paste0('Current - future ', params$env_predictor_1,' dissimilarity'))
  plot(cropped_shapefile,  add=T, lwd=1.4)
  points(presences, pch=21, cex=1.6, bg='darkorange3',col='black')
  plot(g, background=NULL, col="grey65", lty=2, retro=TRUE, add=TRUE)
  terra::north()

  plot(env_2_dissimilarity, col=rev(precipitation_colours), main = paste0('Current - future ', params$env_predictor_2,' dissimilarity'))
  plot(cropped_shapefile,  add=T, lwd=1.4)
  points(presences, pch=21, cex=1.6, bg='darkorange3',col='black')
  plot(g, background=NULL, col="grey65", lty=2, retro=TRUE, add=TRUE)
  terra::north()
  dev.off()
  
  cat('> Environmental dissimilarity of SDMs, env predictors, plots and rasters saved for present-future...\n', file=log_file, append=T)
  cat('> Environmental dissimilarity  completed ...\n\n', file=log_file, append=T)
  
  writeRaster(sdm_dissimilarity,paste0(exposure_dir,species_binomial,'_SDM_dissimilarity.asc'), overwrite=TRUE)
  writeRaster(env_1_dissimilarity,paste0(exposure_dir,species_binomial,'_environmental_dissimilarity_',params$env_predictor_1,'.asc'), overwrite=TRUE)
  writeRaster(env_2_dissimilarity,paste0(exposure_dir,species_binomial,'_environmental_dissimilarity_',params$env_predictor_2,'.asc'), overwrite=TRUE)
  
  cat('> Now calculating Exposure based on magnitude of change predicted at each location... \n', file=log_file, append=T)
  
  # extract data for each point, store in dataframe
  # # read in csv with full data and plot to check
  samples <- read.csv(paste0('-data-/spatial_data/',species_binomial,'/',species_binomial,'_samples.csv'), header=TRUE)
  samples <- unique(samples[,2:3])
  
  presences <- as.data.frame(cbind(samples$LONG,samples$LAT))
  colnames(presences) <- c('LONG', 'LAT')
  coordinates(presences) <- ~ LONG + LAT
  #sdm_dissimilarity <- sdm_future-sdm_current
  
  # extract the values from each raster and cbind to a dataframe
  env_1_current_extracted <- as.data.frame(raster::extract(env_1_current, presences))
  env_2_current_extracted <- as.data.frame(raster::extract(env_2_current, presences))
  env_1_future_extracted <- as.data.frame(raster::extract(env_1_future, presences))
  env_2_future_extracted <- as.data.frame(raster::extract(env_2_future, presences))
  sdm_current_extracted <- as.data.frame(raster::extract(sdm_current, presences))
  sdm_future_extracted <- as.data.frame(raster::extract(sdm_future, presences))
  sdm_dissimilarity_extracted <- as.data.frame(raster::extract(sdm_dissimilarity, presences))
  
  # Now calculate Exposure
  Exposure <- cbind (samples,env_1_current_extracted, env_1_future_extracted, env_2_current_extracted,env_2_future_extracted, sdm_current_extracted, sdm_future_extracted, sdm_dissimilarity_extracted)
  colnames(Exposure) <- c('LONG', 'LAT','env_1_current', 'env_1_future', 'env_2_current', 'env_2_future', 'sdm_current', 'sdm_future', 'sdm_dissimilarity')  
  # quantify change per sample/population, then make rules based on these to make an 'Exposure' score
  # 1. % change in relative occurrence probability
  Exposure$i_sdm_change <- (Exposure$sdm_dissimilarity/Exposure$sdm_current*100)
  Exposure <- replace(Exposure, is.na(Exposure),0)
  
  # get the quantiles of the data - sdm_change
  q1 <- as.numeric(quantile(Exposure$i_sdm_change, probs=0.1))
  q2 <- as.numeric(quantile(Exposure$i_sdm_change, probs=0.2))
  q3 <- as.numeric(quantile(Exposure$i_sdm_change, probs=0.3))
  q4 <- as.numeric(quantile(Exposure$i_sdm_change, probs=0.4))
  q5 <- as.numeric(quantile(Exposure$i_sdm_change, probs=0.5))
  q6 <- as.numeric(quantile(Exposure$i_sdm_change, probs=0.6))
  q7 <- as.numeric(quantile(Exposure$i_sdm_change, probs=0.7))
  q8 <- as.numeric(quantile(Exposure$i_sdm_change, probs=0.8))
  q9 <- as.numeric(quantile(Exposure$i_sdm_change, probs=0.9))
   
  # get the intervals based on the range of the data
  min <- min(Exposure$i_sdm_change)
  max <- max(Exposure$i_sdm_change)
  range <- max-min
  increments <- range/10
  i10 <- min
  i9 <- min+increments
  i8 <- i9+increments
  i7 <- i8+increments
  i6 <- i7+increments
  i5 <- i6+increments
  i4 <- i5+increments
  i3 <- i4+increments
  i2 <- i3+increments
  i1 <- i2+increments

  # use defined thresholds from params file
  thresholds <- params$exposure_sdm_thresholds
  thresholds <- as.data.frame(unlist(strsplit(thresholds,",")))
  thresholds$number <- c(10:1)
  colnames(thresholds) <- c('value','number')

 # generate the scores based on the option selected - 'defined', 'interval', or 'quantile'
if (params$exposure_quantification=='defined'){
#defined
  Exposure$i_final_sdm_change <- findInterval(Exposure$i_sdm_change, c(as.numeric(thresholds$value)))
  Exposure$i_final_sdm_change  <- 10-Exposure$i_final_sdm_change }else{
 if (params$exposure_quantification=='interval'){ 
# interval
  Exposure$i_final_sdm_change <- findInterval(Exposure$i_sdm_change, c(i10,i9,i8,i7,i6,i5,i4,i3,i2,i1))
  Exposure$i_final_sdm_change  <- 10-Exposure$i_final_sdm_change }else{
if (params$exposure_quantification=='quantile'){ 
# quantile
  Exposure$i_final_sdm_change <- findInterval(Exposure$i_sdm_change, c(q1,q2,q3,q4,q5,q6,q7,q8,q9))
  Exposure$i_final_sdm_change  <- 10-Exposure$i_final_sdm_change }
}
}
          
 # 2. relative change in env1

  lhs1 <- paste0('Exposure$',params$env_predictor_1,'_diff', sep='')
  rhs1 <- paste0('(Exposure$env_1_future)-(Exposure$env_1_current)')
  eq1  <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
  eval(parse(text=eq1))
  
  # get the quantiles of the data - env_1_diff
  lhs3.1 <- paste0('q1', sep='')
  rhs3.1 <- paste0('as.numeric(quantile(Exposure$',params$env_predictor_1,'_diff,probs=0.1))')
  eq3.1  <- paste(paste(lhs3.1, rhs3.1, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.1))
  lhs3.2 <- paste0('q2', sep='')
  rhs3.2 <- paste0('as.numeric(quantile(Exposure$',params$env_predictor_1,'_diff,probs=0.2))')
  eq3.2  <- paste(paste(lhs3.2, rhs3.2, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.2))
  lhs3.3 <- paste0('q3', sep='')
  rhs3.3 <- paste0('as.numeric(quantile(Exposure$',params$env_predictor_1,'_diff,probs=0.3))')
  eq3.3  <- paste(paste(lhs3.3, rhs3.3, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.3))
  lhs3.4 <- paste0('q4', sep='')
  rhs3.4 <- paste0('as.numeric(quantile(Exposure$',params$env_predictor_1,'_diff,probs=0.4))')
  eq3.4  <- paste(paste(lhs3.4, rhs3.4, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.4))
  lhs3.5 <- paste0('q5', sep='')
  rhs3.5 <- paste0('as.numeric(quantile(Exposure$',params$env_predictor_1,'_diff,probs=0.5))')
  eq3.5  <- paste(paste(lhs3.5, rhs3.5, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.5))
  lhs3.6 <- paste0('q6', sep='')
  rhs3.6 <- paste0('as.numeric(quantile(Exposure$',params$env_predictor_1,'_diff,probs=0.6))')
  eq3.6  <- paste(paste(lhs3.6, rhs3.6, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.6))
  lhs3.7 <- paste0('q7', sep='')
  rhs3.7 <- paste0('as.numeric(quantile(Exposure$',params$env_predictor_1,'_diff,probs=0.7))')
  eq3.7  <- paste(paste(lhs3.7, rhs3.7, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.7))
  lhs3.8 <- paste0('q8', sep='')
  rhs3.8 <- paste0('as.numeric(quantile(Exposure$',params$env_predictor_1,'_diff,probs=0.8))')
  eq3.8  <- paste(paste(lhs3.8, rhs3.8, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.8))
  lhs3.9 <- paste0('q9', sep='')
  rhs3.9 <- paste0('as.numeric(quantile(Exposure$',params$env_predictor_1,'_diff,probs=0.9))')
  eq3.9  <- paste(paste(lhs3.9, rhs3.9, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.9))
  
   # get the intervals based on the range of the data
  lhs3.9.1 <- paste0('min', sep='')
  rhs3.9.1 <- paste0('min(Exposure$',params$env_predictor_1,'_diff)')
  eq3.9.1  <- paste(paste(lhs3.9.1, rhs3.9.1, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.9.1))
  lhs3.9.1 <- paste0('max', sep='')
  rhs3.9.1 <- paste0('max(Exposure$',params$env_predictor_1,'_diff)')
  eq3.9.1  <- paste(paste(lhs3.9.1, rhs3.9.1, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.9.1))
  range <- max-min
  increments <- range/10
  i10 <- min
  i9 <- min+increments
  i8 <- i9+increments
  i7 <- i8+increments
  i6 <- i7+increments
  i5 <- i6+increments
  i4 <- i5+increments
  i3 <- i4+increments
  i2 <- i3+increments
  i1 <- i2+increments

  # use defined thresholds from params file
  thresholds <- params$exposure_env_1_thresholds
  thresholds <- as.data.frame(unlist(strsplit(thresholds,",")))
  thresholds$number <- c(1:10)
  colnames(thresholds) <- c('value','number')

 # generate the scores based on the option selected - 'defined', 'interval', or 'quantile'
if (params$exposure_quantification=='defined'){
#defined
  lhs4 <- paste0('Exposure$final_',params$env_predictor_1,'_diff', sep='')
  rhs4 <- paste0('findInterval(Exposure$',params$env_predictor_1,'_diff', ',c(as.numeric(thresholds$value)))')
  eq4  <- paste(paste(lhs4, rhs4, sep=' <- '), collapse='; ')
  eval(parse(text=eq4)) }else{ 
 if (params$exposure_quantification=='interval'){ 
# interval
  lhs4 <- paste0('Exposure$final_',params$env_predictor_1,'_diff', sep='')
  rhs4 <- paste0('findInterval(Exposure$',params$env_predictor_1,'_diff', ',c(i10,i9,i8,i7,i6,i5,i4,i3,i2,i1))')
  eq4  <- paste(paste(lhs4, rhs4, sep=' <- '), collapse='; ')
  eval(parse(text=eq4))  }else{
if (params$exposure_quantification=='quantile'){ 
# quantile
  lhs4 <- paste0('Exposure$final_',params$env_predictor_1,'_diff', sep='')
  rhs4 <- paste0('findInterval(Exposure$',params$env_predictor_1,'_diff', ',c(q1,q2,q3,q4,q5,q6,q7,q8,q9))')
  eq4  <- paste(paste(lhs4, rhs4, sep=' <- '), collapse='; ')
  eval(parse(text=eq4))  
  lhs5 <- paste0('Exposure$final_',params$env_predictor_1,'_diff', sep='')
  rhs5 <- paste0('10 - Exposure$final_',params$env_predictor_1,'_diff')
  eq5  <- paste(paste(lhs5, rhs5, sep=' <- '), collapse='; ')
  eval(parse(text=eq5))
  lhs6 <- paste0('Exposure$final_',params$env_predictor_1,'_diff', sep='') # convert back to correct exposure score, more exposure = higher score
  rhs6 <- paste0('11 - Exposure$final_',params$env_predictor_1,'_diff')
  eq6  <- paste(paste(lhs6, rhs6, sep=' <- '), collapse='; ')
  eval(parse(text=eq6))}
}
}

    
 # 3. relative change in env2

  lhs1 <- paste0('Exposure$',params$env_predictor_2,'_diff', sep='')
  rhs1 <- paste0('(Exposure$env_2_future)-(Exposure$env_2_current)')
  eq1  <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
  eval(parse(text=eq1))
    
  # get the quantiles of the data - env_2_diff
  lhs3.1 <- paste0('q1', sep='')
  rhs3.1 <- paste0('as.numeric(quantile(Exposure$',params$env_predictor_2,'_diff,probs=0.1))')
  eq3.1  <- paste(paste(lhs3.1, rhs3.1, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.1))
  lhs3.2 <- paste0('q2', sep='')
  rhs3.2 <- paste0('as.numeric(quantile(Exposure$',params$env_predictor_2,'_diff,probs=0.2))')
  eq3.2  <- paste(paste(lhs3.2, rhs3.2, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.2))
  lhs3.3 <- paste0('q3', sep='')
  rhs3.3 <- paste0('as.numeric(quantile(Exposure$',params$env_predictor_2,'_diff,probs=0.3))')
  eq3.3  <- paste(paste(lhs3.3, rhs3.3, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.3))
  lhs3.4 <- paste0('q4', sep='')
  rhs3.4 <- paste0('as.numeric(quantile(Exposure$',params$env_predictor_2,'_diff,probs=0.4))')
  eq3.4  <- paste(paste(lhs3.4, rhs3.4, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.4))
  lhs3.5 <- paste0('q5', sep='')
  rhs3.5 <- paste0('as.numeric(quantile(Exposure$',params$env_predictor_2,'_diff,probs=0.5))')
  eq3.5  <- paste(paste(lhs3.5, rhs3.5, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.5))
  lhs3.6 <- paste0('q6', sep='')
  rhs3.6 <- paste0('as.numeric(quantile(Exposure$',params$env_predictor_2,'_diff,probs=0.6))')
  eq3.6  <- paste(paste(lhs3.6, rhs3.6, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.6))
  lhs3.7 <- paste0('q7', sep='')
  rhs3.7 <- paste0('as.numeric(quantile(Exposure$',params$env_predictor_2,'_diff,probs=0.7))')
  eq3.7  <- paste(paste(lhs3.7, rhs3.7, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.7))
  lhs3.8 <- paste0('q8', sep='')
  rhs3.8 <- paste0('as.numeric(quantile(Exposure$',params$env_predictor_2,'_diff,probs=0.8))')
  eq3.8  <- paste(paste(lhs3.8, rhs3.8, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.8))
  lhs3.9 <- paste0('q9', sep='')
  rhs3.9 <- paste0('as.numeric(quantile(Exposure$',params$env_predictor_2,'_diff,probs=0.9))')
  eq3.9  <- paste(paste(lhs3.9, rhs3.9, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.9))
  
   # get the intervals based on the range of the data
  lhs3.9.1 <- paste0('min', sep='')
  rhs3.9.1 <- paste0('min(Exposure$',params$env_predictor_2,'_diff)')
  eq3.9.1  <- paste(paste(lhs3.9.1, rhs3.9.1, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.9.1))
  lhs3.9.1 <- paste0('max', sep='')
  rhs3.9.1 <- paste0('max(Exposure$',params$env_predictor_2,'_diff)')
  eq3.9.1  <- paste(paste(lhs3.9.1, rhs3.9.1, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.9.1))
  range <- max-min
  increments <- range/10
  i10 <- min
  i9 <- min+increments
  i8 <- i9+increments
  i7 <- i8+increments
  i6 <- i7+increments
  i5 <- i6+increments
  i4 <- i5+increments
  i3 <- i4+increments
  i2 <- i3+increments
  i1 <- i2+increments

  # use defined thresholds from params file
  thresholds <- params$exposure_env_2_thresholds
  thresholds <- as.data.frame(unlist(strsplit(thresholds,",")))
  thresholds$number <- c(1:10)
  colnames(thresholds) <- c('value','number')

 # generate the scores based on the option selected - 'defined', 'interval', or 'quantile'
if (params$exposure_quantification=='defined'){
#defined
  lhs4 <- paste0('Exposure$final_',params$env_predictor_2,'_diff', sep='')
  rhs4 <- paste0('findInterval(Exposure$',params$env_predictor_2,'_diff', ',c(as.numeric(thresholds$value)))')
  eq4  <- paste(paste(lhs4, rhs4, sep=' <- '), collapse='; ')
  eval(parse(text=eq4)) }else{ 
 if (params$exposure_quantification=='interval'){ 
# interval
  lhs4 <- paste0('Exposure$final_',params$env_predictor_2,'_diff', sep='')
  rhs4 <- paste0('findInterval(Exposure$',params$env_predictor_2,'_diff', ',c(i10,i9,i8,i7,i6,i5,i4,i3,i2,i1))')
  eq4  <- paste(paste(lhs4, rhs4, sep=' <- '), collapse='; ')
  eval(parse(text=eq4))  }else{
if (params$exposure_quantification=='quantile'){ 
# quantile
  lhs4 <- paste0('Exposure$final_',params$env_predictor_2,'_diff', sep='')
  rhs4 <- paste0('findInterval(Exposure$',params$env_predictor_2,'_diff', ',c(q1,q2,q3,q4,q5,q6,q7,q8,q9))')
  eq4  <- paste(paste(lhs4, rhs4, sep=' <- '), collapse='; ')
  eval(parse(text=eq4))  
  lhs5 <- paste0('Exposure$final_',params$env_predictor_2,'_diff', sep='')
  rhs5 <- paste0('10 - Exposure$final_',params$env_predictor_2,'_diff')
  eq5  <- paste(paste(lhs5, rhs5, sep=' <- '), collapse='; ')
  eval(parse(text=eq5))
  lhs6 <- paste0('Exposure$final_',params$env_predictor_2,'_diff', sep='') # convert back to correct exposure score, more exposure = higher score
  rhs6 <- paste0('11 - Exposure$final_',params$env_predictor_2,'_diff')
  eq6  <- paste(paste(lhs6, rhs6, sep=' <- '), collapse='; ')
  eval(parse(text=eq6))}
}
}

  # can tweak rules in the params file to decide how to calculate vulnerability
  
  # Rules: calculating Exposure 
  # 0: Exposure = based on sdm dissimilarity
  # 1: Exposure = based on mean of sdm and environmental predictors
  # 2: Exposure = 25% SDM, 75% environmental predictors
  # 3: Exposure = 50% SDM, 50% environmental predictors
  # 4: Exposure = 75% SDM, 25% environmental predictors
  
  if (params$exposure_rule==0){
    Exposure$exposure <- (Exposure$i_final_sdm_change)
    cat('> Exposure calculated based on the SDM...\n', file=log_file, append=T)
  }else{
  if (params$exposure_rule==1){
    Exposure$exposure <- (Exposure$i_final_sdm_change+eval(parse(text=paste0('Exposure$final_',params$env_predictor_1,'_diff')))+eval(parse(text=(paste0('Exposure$final_',params$env_predictor_2,'_diff')))))/3
    cat('> Exposure calculated based on the mean score for SDM,',params$env_predictor_1,', and',params$env_predictor_2, '...\n', file=log_file, append=T)
  }else{
    if (params$exposure_rule==2){
      sdm_weighted <- (Exposure$i_final_sdm_change/100)*25 # = 25%
      env_predictor_1_weighted <- eval(parse(text=(paste0('(Exposure$final_',params$env_predictor_1,'_diff/100)*37.5')))) 
      env_predictor_2_weighted <- eval(parse(text=(paste0('(Exposure$final_',params$env_predictor_2,'_diff/100)*37.5')))) # together = 75%
      Exposure$exposure <- (env_predictor_1_weighted + env_predictor_1_weighted + sdm_weighted)
      cat('> Exposure calculated based on weighted score for SDM (25%),',params$env_predictor_1,',',params$env_predictor_2, '(75%)...\n', file=log_file, append=T)
    }else{
      if (params$exposure_rule==3){
        sdm_weighted <- (Exposure$i_final_sdm_change/100)*50 # = 50%
        env_predictor_1_weighted <- eval(parse(text=(paste0('(Exposure$final_',params$env_predictor_1,'_diff/100)*25')))) 
        env_predictor_2_weighted <- eval(parse(text=(paste0('(Exposure$final_',params$env_predictor_2,'_diff/100)*25')))) # together = 50%
        Exposure$exposure <- (env_predictor_1_weighted + env_predictor_1_weighted + sdm_weighted)
        cat('> Exposure calculated based on weighted score for SDM (50%),',params$env_predictor_1,',',params$env_predictor_2, '(50%)...\n', file=log_file, append=T)
      }else{
        if (params$exposure_rule==4){
          sdm_weighted <- (Exposure$i_final_sdm_change/100)*75 # = 75%
          env_predictor_1_weighted <- eval(parse(text=(paste0('(Exposure$final_',params$env_predictor_1,'_diff/100)*12.5')))) 
          env_predictor_2_weighted <- eval(parse(text=(paste0('(Exposure$final_',params$env_predictor_2,'_diff/100)*12.5')))) # together = 25%
          Exposure$exposure <- (env_predictor_1_weighted + env_predictor_1_weighted + sdm_weighted)
          cat('> Exposure calculated based on weighted score for SDM (75%),',params$env_predictor_1,',',params$env_predictor_2, '(25%)...\n', file=log_file, append=T)
        }}}}} 

# trim off to 2 decimal places (except for LONG/LAT)  
library(dplyr)
Exposure <- Exposure %>% mutate_at(vars(-LONG,-LAT), funs(round(., 2)))
  write.csv(Exposure,paste0(exposure_dir,species_binomial,"_Exposure.csv"), row.names=FALSE)
  
  cat('> Exposure calculations completed successfully ...\n\n', file=log_file, append=T)
  
}

#############################################################################################################################################################################################
impute_missing_data <- function(species_binomial) {
#############################################################################################################################################################################################
  
  # Impute data sets using i) snmf, ii) by imputing average genotypes within pop clusters
  # runs snmf first to look at pop structure, which is saved as a barplot and cross-entropy scores for each given value of K
  
  rm(list=ls(all=TRUE))
  
  # Load packages, set some directories
  library(LEA) # using v 2.0.0
  library(adegenet)
  library(dplyr)
  
  root_dir <- ('$YOUR_WORK_DIR')
  setwd(root_dir)
  genomic_data_path <- './-data-/genomic_data/'
  colours <- c('#ff7f00','#1f78b4','#ffff33','#a6cee3','#33a02c','#e31a1c')
  
  # read args
  args <- commandArgs()
  print(args)
  species_binomial <- args[8]  # This may vary between systems depending on your HPC setup, the list of arguments will be printed at the beginning of your SLURM job logfile so if the jobs fail, make sure that this number matches the number in args[] that matches your species name
  
  # set params file
  params_all <- read.delim('./Params.tsv')
  
  # Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
  params <- params_all[which(params_all$species_binomial==species_binomial),]
  species_binomial <- params$species_binomial
  
  log_file <- paste0('./-outputs-/log_files/',species_binomial,'.log')
  output_path <- paste0('./-outputs-/',species_binomial,'/Sensitivity/')
  dir.create(paste0(output_path))
  
    cat('--------------------------------------------------------------\n', file=log_file, append=T)
  cat('Assessing population structure and imputing missing data...\n', file=log_file, append=T)
  cat('--------------------------------------------------------------\n', file=log_file, append=T)
  
  cat('> Running sNMF population structure analysis...\n', file=file.path(log_file), append=T)
  ###########
  # sNMF population structure analysis
  # Read in ped files, convert to lfmm and geno
  data = read.table(paste0(genomic_data_path,species_binomial,'/',species_binomial,'.ped'))
  output = ped2lfmm(paste0(genomic_data_path,species_binomial,'/',species_binomial,'.ped'))
  output = ped2geno(paste0(genomic_data_path,species_binomial,'/',species_binomial,'.ped'))
  species <- read.geno(paste0(genomic_data_path,species_binomial,'/',species_binomial,'.geno')) 
  
  # Run snmf to look at structure 
  
  k_range <- paste0(params$k_min,':',params$k_max)
  k_range <- eval(parse(text=k_range))
  
  species.snmf <- snmf(paste0(genomic_data_path,species_binomial,'/',species_binomial,'.geno'), K = k_range, entropy = T, ploidy = params$ploidy, rep=params$snmf_reps, project = 'new')  
  # Plot cross-entropy criterion of all runs of the project
  sumpr <- summary(species.snmf)$crossEntropy
  sumpr
  plot(species.snmf, lwd = 1.5, col = 'black', pch=19)
  # Choose K with lowest mean cross entropy
  K <- c(k_range)[which.min(sumpr[2,])]         
  # Get the cross-entropy of each run for K
  ce <- cross.entropy(species.snmf, K=K)
  # Select the run with the lowest cross-entropy
  best <- which.min(ce)
  best
  
  # Population assignment based on Q values. Simply assigns ind to pop with highest Q
  Q_vals <- Q(species.snmf, K = K, run = best)
  sample_names <- data[,2]
  pop_assignment <- as.data.frame(cbind(sample_names,Q_vals))
  names(pop_assignment) <- gsub(x = names(pop_assignment), pattern = 'V', replacement = '')  
  pop_assignment$pop <- max.col(pop_assignment[,2:ncol(pop_assignment)])
  # reorder columns so starts with sample name and then pop, followed by Q vals
  ordered_columns_leftside=c('sample_names','pop')
  pop_assignment=pop_assignment[c(ordered_columns_leftside, setdiff(names(pop_assignment),ordered_columns_leftside))]
  write.csv(pop_assignment, paste0(output_path,species_binomial,'_pop_assignment_LEA.csv'))
  
  # Plot barplot of pop structure and cross entropy scores for each k
  ind_labels <- read.csv(paste0(output_path,species_binomial,'_pop_assignment_LEA.csv'))
  ind_labels <- (ind_labels[,2])
  
  png(filename=paste0(output_path,species_binomial,'_pop_structure_snmf_barplot.png'), 
      type='cairo', units='cm', width=(length(ind_labels)/2)+10, height=15, pointsize=12, res=300)
  par(cex.main=2, cex.axis=2)
  par(mfrow=c(1,1))
  plot <- barplot(t(Q(species.snmf, K = K, run = best)), col = colours, ylab = 'Ancestry coefficients', xlab = '', main='sNMF Population structure barplot')
  axis(1, at = plot, labels = ind_labels, las = 3, cex.axis = 1)
  dev.off()
  
  png(filename=paste0(output_path,species_binomial,'_pop_structure_snmf_cross_entropy.png'), 
      type='cairo', units='cm', width=30, height=30, pointsize=12, res=300)
  par(cex.main=2, cex.axis=2)
  par(mar=c(8,5,5,5))
  par(mfrow=c(1,1))
  plot(species.snmf, lwd = 0.25, col = 'black', pch=19, cex=1.5, cex.lab=2, main='sNMF cross-entropy across tested K values')
  dev.off()
  
  cat('> Range of K tested:',min(k_range), ':', max(k_range),'\n', file=log_file, append=T)
  cat('> K with lowest cross-entropy:',K, '\n', file=log_file, append=T)
  cat('> Output sNMF population assignment data saved and plotted','\n',file=log_file, append=T)
  cat('> sNMF population structure analysis completed successfully...\n\n', file=file.path(log_file), append=T)
  
  cat('> Imputing missing data. using LEA..\n', file=log_file, append=T)
  ###########
  # Impute missing data
  
  # Impute missing data no.1 (LEA)
  species.imp <- species
  X.snmf <- Q(species.snmf, K=K, run=best) %*% t(G(species.snmf, K=K, run=best)) # matrix completion
  
  for (i in 1:nrow(species)){
    mat <- matrix(X.snmf[i,], nrow = 3 , byrow = F)  # fill matrix by columns
    wm <- (apply(mat, 2, which.max))-1               # get max of each column
    species.imp[i, species[i,] == 9] <- wm[species[i,] == 9]
  }
  
  write.geno(species.imp,paste0(genomic_data_path,species_binomial,'/',species_binomial,'_imp.geno'))
  output_imp = geno2lfmm(paste0(genomic_data_path,species_binomial,'/',species_binomial,'_imp.geno'), force = TRUE)
  
  cat('> Imputed data saved, LEA completed successfully... \n\n', file=file.path(log_file), append=T)
  
  cat('> Imputing missing data using mean genotypes..\n', file=log_file, append=T)
  # Impute missing data no.2 (mean genotype across inds per cluster)
  data.env <- read.csv(paste0('./-data-/spatial_data/',species_binomial,'/',species_binomial,'_full_env_data.csv'))
  
  # first install plink locally
  # on mac you should download plink
  # copy the binary to somewher elocal (e.g. /usr/local/bin/) and then add that to your path (export PATH=$PATH:/usr/local/bin/)
  plink_executable <- paste0("'",params$plink_executable,"'") # then call that binary
  plink_input <- paste0('./-data-/genomic_data/',species_binomial,'/',species_binomial)
  plink_output <-  paste0('./-data-/genomic_data/',species_binomial,'/',species_binomial)
  system(paste0(plink_executable,' --recodeA --file ', plink_input, ' --out ', plink_output,' --allow-extra-chr'))

  species.genlight <- read.PLINK(paste0(genomic_data_path,species_binomial,'/',species_binomial,'.raw'), map.file = paste0(genomic_data_path,species_binomial,'/',species_binomial,'.map'),
                                 quiet = FALSE, chunkSize = 1000, parallel = FALSE, n.cores = NULL)
  
  identical(as.character(data.env[,2]), species.genlight@ind.names)
  species <- as.matrix(species.genlight)  
  #species.full <- cbind(data.env[,c(1,2,5,6)], species) # so just sample, cluster, env1, env2, and species dataframe
  
  species <- as.data.frame(species)
  #species.full <- as.data.frame(cbind(data.env$Sample, pop_assignment$pop, data.env$bioclim_5, data.env$bioclim_18))
  
  lhs1 <- paste0('species.full',sep='')
  rhs1 <- paste0('as.data.frame(cbind(data.env$Sample, pop_assignment$pop, data.env$',params$env_predictor_1, ',data.env$',params$env_predictor_2,'))')
  eq1  <- paste0(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
  eval(parse(text=eq1))
    
  colnames(species.full) <- eval(parse(text=paste0("c('Sample', 'cluster', '",params$env_predictor_1,"','",params$env_predictor_2,"')")))
  
  
  species.full <- cbind(species.full,species)
  species.full <- species.full[order(species.full$cluster),]
  
  # Below code generalises the code used for Razgour et al. (2017), makes it flexible
  nclust <- unique(species.full$cluster)
  n    <- length(nclust)
  lhs1  <- paste('species',    1:n,     sep='_')
  rhs1  <- paste('species.full[species.full$cluster==',1:n,', c(-1:-4)]', sep='')
  eq1   <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
  eval(parse(text=eq1))
  
  n    <- length(nclust)
  lhs2  <- paste('cMr')
  rhs2  <- paste('round(colMeans(species_',1:n,', na.rm =TRUE)); indx <- which(is.na(species_',1:n, '), arr.ind=TRUE); species_' ,1:n, '[indx] <- cMr[indx[,2]]', sep='')
  eq2   <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
  eval(parse(text=eq2))
  
  lhs3  <- paste('rbind(')
  rhs3 <- capture.output(cat(lhs1, sep=','))
  eq3 <- paste0(lhs3,rhs3,')')
  eval(parse(text=eq3))
  
  identical(as.character(species.full[,1]), row.names(species.imp))
  species.env <- species.full[,3:4]
  colnames(species.imp) <- species.genlight@loc.names
  write.csv(species.imp,paste0(genomic_data_path,species_binomial,'/',species_binomial,'_imp.csv'))
  
  cat('> Imputed data saved, mean genotype imputation completed successfully... \n\n', file=file.path(log_file), append=T)
  
  cat('> Running PCA population structure analysis...\n', file=log_file, append=T)
 
  #############
  # PCA population structure analysis
  # Read in genomic data
  
  library(vegan)
  gen <- read.table(paste0(genomic_data_path,species_binomial,'/',species_binomial,'_imp.lfmm'), header = FALSE) # read in lfmm file that was imputed in snmf
  
  # Rename the loci names to match across lfmm, RDA and PCAdapt analyses 
  
  species_binomial.genlight <- read.PLINK(paste0(genomic_data_path,species_binomial,'/',species_binomial,'.raw'), map.file = paste0(genomic_data_path,species_binomial,'/',species_binomial,'.map'),
                                          quiet = FALSE, chunkSize = 1000, parallel = FALSE, n.cores = NULL)
  features <- species_binomial.genlight@loc.names
  colnames(gen) <- features
  gen[1:3,1:3]  # Have a quick look: these are diploids (coded 0 or 1 or 2)
  dim(gen)       # Individuals in rows, SNPs in columns  
  species_binomial.pca <- rda(gen, scale=T)  # vegan uses 'rda' with no constraining matrix to compute a pca
  screeplot(species_binomial.pca)            # find the 'drop off' - this may not always be straightforward...
  
  # Set colours
  #species_binomial_pops <- read.csv(paste0(env_data_path,species_binomial,'/',species_binomial,'_env_data.csv'))
  species_binomial_pops <- read.csv(paste0('./-data-/spatial_data/',species_binomial,'/',species_binomial,'_full_env_data.csv'))
  
  pops <- pop_assignment$pop ##
  bg <- c('#ff7f00','#1f78b4','#ffff33','#a6cee3','#33a02c','#e31a1c') 
  
  png(filename=paste0(output_path,species_binomial,'_pop_structure_PCA.png'), 
      type='cairo', units='cm', width=40, height=30, pointsize=12, res=300)
  par(mar=c(5,5,5,5))
  par(mfrow=c(1,2))
  par(cex.main=2, cex.axis=2, cex.lab=2)
  plot(species_binomial.pca, main=paste0(species_binomial,' PCA'), type='n', scaling=3)
  points(species_binomial.pca, display='sites', pch=21, cex=1.3, col='gray32', scaling=3, bg=bg[pops]) # the individuals
  #legend('topright', legend=levels(pops), bty='n', col='gray32', pch=21, cex=1, pt.bg=bg)
  screeplot(species_binomial.pca, main='Screeplot', cex.lab=2)
  dev.off()
  
  # # grab pop clusters and order
  # n <- unique(species_binomial_pops$cluster)
  # n <- n[order(n)]  
  # levels(species_binomial_pops$cluster) <- n
  
  cat('> Output PCA population assignment data saved and plotted','\n\n',file=log_file, append=T)
  cat('** WARNING: check this plot to identify number of population clusters before going further\n',file=log_file, append=T)
  cat('> PCA  population structure analysis completed successfully...\n\n', file=file.path(log_file), append=T)
  
}

#############################################################################################################################################################################################
gea_lfmm <- function(species_binomial) {
#############################################################################################################################################################################################
## Run lfmm to find adaptive SNPs

rm(list=ls(all=TRUE))

# Load packages, set some directories
library(lfmm)         #?lfmm_ridge  # we use the 'ridge penalty' for GEA
library(vegan)        # all things ordination (RDA, dbRDA, PCA, etc.) & more!
library(qvalue)       # false discovery rate calculation
library(psych)        # nice pair plots
library(usdm)         # calculates variance inflation factors
library(adegenet)     # for reading plink files
library(stringr)

root_dir <- ('$YOUR_WORK_DIR')
setwd(root_dir)

genomic_data_path <- './-data-/genomic_data/'
spatial_data_path <- './-data-/spatial_data/'

colours <- c('#ff7f00','#1f78b4','#ffff33','#a6cee3','#33a02c','#e31a1c')

# read args
args <- commandArgs()
print(args)
species_binomial <- args[8]  # This may vary between systems depending on your HPC setup, the list of arguments will be printed at the beginning of your SLURM job logfile so if the jobs fail, make sure that this number matches the number in args[] that matches your species name

# set params file
params_all <- read.delim('./Params.tsv')

# Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
params <- params_all[which(params_all$species_binomial==species_binomial),]
species_binomial <- params$species_binomial
  
log_file <- paste0('./-outputs-/log_files/',species_binomial,'.log')
sensitivity_path <- paste0('./-outputs-/',species_binomial,'/Sensitivity/')
dir.create(paste0(sensitivity_path))
output_path <- paste0(sensitivity_path,'Adaptive_sensitivity/')
dir.create(paste0(output_path))


cat('--------------------------------------------------------------\n', file=log_file, append=T)
cat('Running LFMM (Latent Factor Mixed Models)...\n', file=log_file, append=T)
cat('--------------------------------------------------------------\n', file=log_file, append=T)
##########
# Document correlations of predictor variables (for all Genotype-Environment Association analyses)
cat('> Assessing correlations of predictor variables...\n', file=file.path(log_file), append=T)

#read the data that is extracted automatically from your predictor variables
env <- read.csv(paste0(spatial_data_path,species_binomial,'/',species_binomial,'_full_env_data.csv'))
env <- env[,c(params$env_predictor_1,params$env_predictor_2)] # subset env vars of interest tfor local adaptation analyses

# Look at correlations in predictors before we go on 
png(filename=paste0(output_path,species_binomial,'_env_correlations.png'), 
    type='cairo', units='cm', width=30, height=30, pointsize=12, res=300)
par(cex.main=2, cex.axis=2)
pairs.panels(env, scale=T, cex.cor=2)  # see ?pairs.panels for a description of these biplots
dev.off()
# correlation coefficients are in the upper right diagonal, with their size scaled to the value of |r|
vif(env) # check variance inflation factors, which assess multicollinearity, VIFs > 10 may be problematic; VIFs < 5 mean multicollinearity shouldn't be a problem


# Decide which predictor to cut if needed (change 'X' to the column of the predictor to remove)
# env <- env[ ,c(-4)] 
cat('> Correlations of predictor variables checked and completed...\n', file=file.path(log_file), append=T)
cat('> Variance Inflation Factors for variables are: ', vif(env)$VIF,'\n', file=log_file, append=T)
cat('> Output correlation data saved and plotted \n\n', file=log_file, append=T)

#######
cat('> Running LFMM (Latent Factor Mixed Models)...\n', file=log_file, append=T)
##########

# LFMM - detection of adaptive SNPs

# Read in genomic data
gen <- read.table(paste0(genomic_data_path,species_binomial,'/',species_binomial,'_imp.lfmm'), header = FALSE) # read in lfmm file that was imputed in snmf

# Rename the SNPs names to match across all GEA analyses (LFMM, RDA and PCAdapt)
species_binomial.genlight <- read.PLINK(paste0(genomic_data_path,species_binomial,'/',species_binomial,'.raw'), map.file = paste0(genomic_data_path,species_binomial,'/',species_binomial,'.map'),
                                        quiet = FALSE, chunkSize = 1000, parallel = FALSE, n.cores = NULL)
features <- species_binomial.genlight@loc.names
colnames(gen) <- features
gen[1:6,1:10]  # Have a quick look: these are diploids (coded 0 or 1 or 2)
dim(gen)       # Individuals in rows, SNPs in columns  
 
cat('** WARNING: Decision needed for number of populations...\n\n', file=file.path(log_file), append=T)
cat('> Evaluate sNMF and PCA population structure outputs to define K\n', file=file.path(log_file), append=T)

K <- params$k
# your decision(S) for K here, this should be informed by the population structure analyses (sNMF and PCA)
# If K is ambiguous then you could run multiple times for different K values and look for overlap
# But may be useful for data where IBD is prevalent rather than discrete pop structure

# LFMM identify candidate SNPs
species_binomial.lfmm <- lfmm_ridge(Y=gen, X=env, K=K) # k defined based on pop structure results

# Built in function to calculate test statistics for all predictors:
pv <- lfmm_test(Y=gen, X=env, lfmm=species_binomial.lfmm, calibrate='gif')

# The GIFs for the predictors 
# 1=well calibrated, >1=liberal (too many small p-values), <1=conservative (too few small p-values)
# If GIFs are above high (e.g. >2), you can try increasing K
pv$gif 
names(pv)                  # automatically applies the gif to the zscores and pvalues
head(pv$pvalue)            # unadjusted p-values for our predictors
head(pv$calibrated.pvalue) # adjusted p-values for our predictors


# Below needs to be done for each predictor
# So this has been looped based on the number of predictors in the env dataframe
n <- ncol(env) # n=number of predictprs

for (i in 1:(n)) {
predictor <- i
par(mfrow=c(2,1))
hist(pv$pvalue[,predictor], main='unadjusted p-values')        
hist(pv$calibrated.pvalue[,predictor], main='adjusted p-values')
par(mfrow=c(1,1))

# The default adjustment looks too conservative (the distribution is too flat).
# Let's change the GIF and readjust the p-values:
head(pv$score) # the zscores (test statistic) are stored in pv$score
zscore <- pv$score[,predictor] # zscores 
(gif <- pv$gif[predictor])     # default GIF for this predictor

cat('> Predictor variable', names(env[i]), '...\n', file=file.path(log_file), append=T)
cat('> Calculated GIF for predictor variable',names(env[i]),' is: ',gif,'\n', file=file.path(log_file), append=T)
cat('** WARNING: Examine the unadjusted vs. adjusted p-values, if adjustment is too conservative (distribution is too flat, increase the GIF...)\n', file=file.path(log_file), append=T)

scale_gif <- params$scale_gif_lfmm
new.gif <- (gif*scale_gif)               # choose/change your modified GIF
cat('> Updated GIF is: ',new.gif,' (original GIF*',scale_gif,')\n', file=file.path(log_file), append=T)

# Manual adjustment:
adj.pv <- pchisq(zscore^2/new.gif, df=1, lower = FALSE)

png(filename=paste0(output_path,species_binomial,'_LFMM_p_value_distribution_',names(env[i]),'.png'), 
    type='cairo', units='cm', width=30, height=30, pointsize=12, res=300)
par(mar=c(5,3,3,3))
par(cex.main=2, cex.axis=1.5)
par(mfrow=c(3,1))
hist(pv$pvalue[,predictor], main='unadjusted p-values', cex.axis=2, cex.lab=2)        
hist(pv$calibrated.pvalue[,predictor], main='adjusted p-values', cex.axis=2, cex.lab=2)
hist(adj.pv, main='REadjusted p-values', cex.axis=2, cex.lab=2)
dev.off()
cat('>>> Output summary of adjusted vs. unadjusted p-values plotted \n', file=file.path(log_file), append=T)


png(filename=paste0(output_path,species_binomial,'_LFMM_Manhattan_plot.png'), 
    type='cairo', units='cm', width=30, height=20, pointsize=12, res=300)
#par(mar=c(10,3,10,3))
par(mfrow=c(1,1))
plot(-log10(adj.pv), pch=19, cex=0.5, xlab='SNP',ylab='-log10(p-values)',col='navy', cex.lab=1, cex.axis=1)
#abline(h=3.5, lty=2, lwd=1.2, col='red')
dev.off()
cat('>>> Output Manhattan plot of adjusted p-values saved...\n', file=file.path(log_file), append=T)

# Proceed if you're happy with the new distribution, or tweak some more...
par(mfrow=c(1,1))

# Choosing a FDR (False Discovery Rate) cutoff
# qvalues and FDR 0.1 cutoff for env predictors 1:n
lhs1 <- paste('lfmm.qval', names(env[i]), sep='')
rhs1 <- paste ('qvalue(adj.pv)$qvalues')
eq1  <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))
  
lhs2 <- paste('(length(lFDR.1')
rhs2 <- paste0('which(lfmm.qval',names(env[i]),'< 0.1)))')
eq2  <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
eval(parse(text=eq2))

lhs3 <- paste0('lfmm.FDR.1.env',names(env[i]),sep='')
rhs3 <- paste('colnames(gen)[lFDR.1]')
eq3  <- paste(paste(lhs3, rhs3, sep=' <- '), collapse='; ')
eval(parse(text=eq3))

eval(parse(text=lhs3))

# qvalues and FDR 0.05 cutoff for env predictors 1:n
lhs4 <- paste('lfmm.qval', names(env[i]), sep='')
rhs4 <- paste ('qvalue(adj.pv)$qvalues')
eq4  <- paste(paste(lhs4, rhs4, sep=' <- '), collapse='; ')
eval(parse(text=eq4))

lhs5 <- paste('(length(lFDR.05')
rhs5 <- paste0('which(lfmm.qval',names(env[i]),'< 0.05)))')
eq5  <- paste(paste(lhs5, rhs5, sep=' <- '), collapse='; ')
eval(parse(text=eq5))

lhs6 <- paste0('lfmm.FDR.05.env',names(env[i]),sep='')
rhs6 <- paste('colnames(gen)[lFDR.05]')
eq6  <- paste(paste(lhs6, rhs6, sep=' <- '), collapse='; ')
eval(parse(text=eq6))

eval(parse(text=lhs3))

# qvalues and FDR 0.01 cutoff for env predictors 1:n
lhs7 <- paste('lfmm.qval', names(env[i]), sep='')
rhs7 <- paste ('qvalue(adj.pv)$qvalues')
eq7  <- paste(paste(lhs7, rhs7, sep=' <- '), collapse='; ')
eval(parse(text=eq7))

lhs8 <- paste('(length(lFDR.01')
rhs8 <- paste0('which(lfmm.qval',names(env[i]),'< 0.01)))')
eq8  <- paste(paste(lhs8, rhs8, sep=' <- '), collapse='; ')
eval(parse(text=eq8))

lhs9 <- paste0('lfmm.FDR.01.env',names(env[i]),sep='')
rhs9 <- paste('colnames(gen)[lFDR.01]')
eq9  <- paste(paste(lhs9, rhs9, sep=' <- '), collapse='; ')
eval(parse(text=eq9))
eval(parse(text=lhs9))

list <- list((eval(parse(text=lhs3))),(eval(parse(text=lhs6))),(eval(parse(text=lhs9))))
lhs10 <- paste0('all_candidates_predictor_', names(env[i]), sep='')
rhs10 <- paste0("sapply(list, '[', 1:length(list[[1]]))")
eq10  <- paste(paste(lhs10, rhs10, sep=' <- '), collapse='; ')
eval(parse(text=eq10))

# Write out the candidate SNPs to file
# all candidates by environmental predictor
# grab all_candidates_predictor_* names (however many there may be for each species)
lhs10.2 <- paste0('colnames(all_candidates_predictor_', names(env[i]), ')', sep='')
rhs10.2 <- paste0('c(lfmm.FDR.1.env',names(env[i]),',','lfmm.FDR.05.env',names(env[i]),',','lfmm.FDR.01.env',names(env[i]),')')
rhs10.2 <- gsub("lfmm","'lfmm",rhs10.2)
rhs10.2 <- gsub(",","',",rhs10.2)
rhs10.2 <- gsub(")","')",rhs10.2)
eq10.2  <- paste(paste(lhs10.2, rhs10.2, sep=' <- '), collapse='; ')
eval(parse(text=eq10.2))
}

list_of_all_candidates_predictors <- mget(ls(.GlobalEnv, pattern = "all_candidates_predictor_"))
lhs10.3 <- names(list_of_all_candidates_predictors)
lhs10.3 <- toString(lhs10.3)

# column bind the FDR results above (0.1, 0.05, 0.01) for each predictor into a single dataframe 
# Finding maximum length
pred_1 <- names(list_of_all_candidates_predictors[1])
pred_2 <- names(list_of_all_candidates_predictors[2])
max_ln <- max(c(length(eval(parse(text=pred_1))), length((eval(parse(text=pred_2))))))

# filling and binding
lhs10.5 <- paste0('all_candidates_by_all_predictors', sep='')
rhs10.5 <- paste0("data.frame(col1 = c(",pred_1,"[,1],rep(NA, max_ln - length(",pred_1,"[,1]))),
                                               col2 = c(",pred_1,"[,2],rep(NA, max_ln - length(",pred_1,"[,2]))),
                                               col3 = c(",pred_1,"[,3],rep(NA, max_ln - length(",pred_1,"[,3]))),
                                               col4 = c(",pred_2,"[,1],rep(NA, max_ln - length(",pred_2,"[,1]))),
                                               col5 = c(",pred_2,"[,2],rep(NA, max_ln - length(",pred_2,"[,2]))),
                                               col6 = c(",pred_2,"[,3],rep(NA, max_ln - length(",pred_2,"[,3]))))")
eq10.5  <- paste(paste(lhs10.5, rhs10.5, sep=' <- '), collapse='; ')
eval(parse(text=eq10.5))

# add the column names
colnames_pred_1 <- eval(parse(text=(paste0('colnames(',pred_1,')'))))
colnames_pred_2 <- eval(parse(text=(paste0('colnames(',pred_2,')'))))
colnames(all_candidates_by_all_predictors) <- c(colnames_pred_1,colnames_pred_2)

#finally write out the files
write.csv(all_candidates_by_all_predictors, paste0(output_path,species_binomial,'_LFMM_candidate_SNPs_by_predictor.csv'))
cat('> Output candidate SNPs by predictor saved \n', file=file.path(log_file), append=T)

# Bind all candidates by FDR cutoff (merge candidates across predictors)
all_candidates_by_all_predictors <- read.csv(paste0(output_path,species_binomial,'_LFMM_candidate_SNPs_by_predictor.csv'))
FDR.1 <- all_candidates_by_all_predictors[ , grepl( "FDR.1" , names( all_candidates_by_all_predictors ) ) ]
FDR.05 <- all_candidates_by_all_predictors[ , grepl( "FDR.05" , names( all_candidates_by_all_predictors ) ) ]
FDR.01 <- all_candidates_by_all_predictors[ , grepl( "FDR.01" , names( all_candidates_by_all_predictors ) ) ]

#FDR.1
lhs1 <- paste0('predictor_',1:n)
rhs1 <- paste0('as.data.frame(FDR.1[,', 1:n,']);colnames(predictor_',1:n,")=''", sep='')
eq1  <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))
lhs1 <- toString(lhs1)
lhs2 <- paste0('FDR.1')
rhs2 <- paste0('rbind(',lhs1,')')
eq2  <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
eval(parse(text=eq2))
FDR.1 <- na.omit(FDR.1)
colnames(FDR.1) <- 'LFMM.FDR.1'

#FDR.05
lhs1 <- paste0('predictor_',1:n)
rhs1 <- paste0('as.data.frame(FDR.05[,', 1:n,']);colnames(predictor_',1:n,")=''", sep='')
eq1  <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))
lhs1 <- toString(lhs1)
lhs2 <- paste0('FDR.05')
rhs2 <- paste0('rbind(',lhs1,')')
eq2  <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
eval(parse(text=eq2))
FDR.05 <- na.omit(FDR.05)
colnames(FDR.05) <- 'LFMM.FDR.05'

#FDR.01
lhs1 <- paste0('predictor_',1:n)
rhs1 <- paste0('as.data.frame(FDR.01[,', 1:n,']);colnames(predictor_',1:n,")=''", sep='')
eq1  <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
eval(parse(text=eq1))
lhs1 <- toString(lhs1)
lhs2 <- paste0('FDR.01')
rhs2 <- paste0('rbind(',lhs1,')')
eq2  <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
eval(parse(text=eq2))
FDR.01 <- na.omit(FDR.01)
colnames(FDR.01) <- 'LFMM.FDR.01'


# column bind the FDR results above (0.1, 0.05, 0.01) for each predictor into a single dataframe 
# Finding maximum length
max_ln <- max(c(length(eval(parse(text=FDR.1))), length(eval(parse(text=FDR.05))), length(eval(parse(text=FDR.01)))))
# filling and binding (base R)
lhs10.6 <- paste0('all_candidates', sep='')
rhs10.6 <- paste0("data.frame(col1 = c(",FDR.1,",rep(NA, max_ln - length(",FDR.1,"))),
                                               col2 = c(",FDR.05,",rep(NA, max_ln - length(",FDR.05,"))),
                                               col3 = c(",FDR.01,",rep(NA, max_ln - length(",FDR.01,"))))")
eq10.6  <- paste(paste(lhs10.6, rhs10.6, sep=' <- '), collapse='; ')
eval(parse(text=eq10.6))
colnames(all_candidates) <- c('LFMM.FDR.1', 'LFMM.FDR.05','LFMM.FDR.01')

write.csv(all_candidates, paste0(output_path,species_binomial,'_LFMM_candidate_SNPs.csv'))

cat('> Output candidate SNPs (merged) saved \n', file=file.path(log_file), append=T)
cat('> LFMM analysis completed successfully...\n\n', file=file.path(log_file), append=T)

}
#############################################################################################################################################################################################
gea_rda <- function(species_binomial) {
#############################################################################################################################################################################################

  # Run RDA to find adaptive SNPs
  
  rm(list=ls(all=TRUE))
  
  # Load packages, set some directories
  library(adegenet)   # for reading files
  library(vegan)
  library(psych)      # nice pair plots
  library(usdm)       # calculates variance inflation factors
  library(robust)     # for robust mahalanobis distance calculation
  library(qvalue)     # false discovery rate calculation
  library(qpcR)       # for binding columns of candidate SNPs with different lengths
  
  root_dir <- ('$YOUR_WORK_DIR')
  setwd(root_dir)
  
  genomic_data_path <- './-data-/genomic_data/'
  spatial_data_path <- './-data-/spatial_data/'
  
  colours <- c('#ff7f00','#1f78b4','#ffff33','#a6cee3','#33a02c','#e31a1c')

  # read args
  args <- commandArgs()
  print(args)
  species_binomial <- args[8]  # This may vary between systems depending on your HPC setup, the list of arguments will be printed at the beginning of your SLURM job logfile so if the jobs fail, make sure that this number matches the number in args[] that matches your species name
  
  # set params file
  params_all <- read.delim('./Params.tsv')
  
  # Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
  params <- params_all[which(params_all$species_binomial==species_binomial),]
  species_binomial <- params$species_binomial
  
  log_file <- paste0('./-outputs-/log_files/',species_binomial,'.log')
  sensitivity_path <- paste0('./-outputs-/',species_binomial,'/Sensitivity/')
  output_path <- paste0(sensitivity_path,'Adaptive_sensitivity/')
  dir.create(output_path)
  
  ##########
  # Detection of adaptive SNPs
  
  # Function to detect outliers from RDA: (courtesy of Brenna Forester)
  # -------------------------------------
  # r <- 1               # which RDA axis to process
  # z <- 3               # how many st.dev. from mean loading
  # x <- load.species_binomial       # loadings from RDA
  # e <- species_binomial.env        # env - HARD CODED FOR 2 ENV.
  # s <- species_binomial.scale      # snps
  
  outliers <- function(r,z,x,e,s) {
    dat <- x[,r]
    lims <- mean(dat) + c(-1, 1) * z * sd(dat)    
    out.load <- dat[dat < lims[1] | dat > lims[2]]   #load
    out.name <- names(out.load)                      #SNPs
    
    if (length(out.load) > 0) {
      axis <- rep(r, length(out.load))
      outdat <- t(rbind(out.name, as.numeric(out.load), axis))
      snpcors <- matrix(NA, nrow=length(out.load), ncol=2*ncol(e))
      
      for (k in 1:length(out.load)) {
        outsnp <- s[,out.name[k]]
        snpcors[k,1] <- as.numeric(cor.test(outsnp, e[,1])$estimate)
        snpcors[k,2] <- as.numeric(cor.test(outsnp, e[,1])$p.value)
        snpcors[k,3] <- as.numeric(cor.test(outsnp, e[,2])$estimate)
        snpcors[k,4] <- as.numeric(cor.test(outsnp, e[,2])$p.value )  }
      outdata <- cbind.data.frame(outdat, snpcors)
      return(outdata)
    }
  }    
 
    cat('--------------------------------------------------------------\n', file=log_file, append=T)
  cat('Running RDA (Redundancy Analysis)...\n', file=log_file, append=T)
  cat('--------------------------------------------------------------\n', file=log_file, append=T)
  
  # read in the env_data. csv
  #env <- read.csv(paste0(env_data_path,species_binomial,'/',species_binomial,'_env_data.csv'))
  
  #or read the data that is extracted automatically from your predictor variables
  
  env <- read.csv(paste0(spatial_data_path,species_binomial,'/',species_binomial,'_full_env_data.csv'))
  pop_assignment <- read.csv(paste0('./-outputs-/',species_binomial,'/Sensitivity/',species_binomial,'_pop_assignment_LEA.csv'))
  #env <- as.data.frame(cbind(env$Sample,pop_assignment$pop,env$bioclim_5,env$bioclim_18))
  lhs1 <- paste0('env',sep='')
  rhs1 <- paste0('as.data.frame(cbind(env$Sample, pop_assignment$pop, env$',params$env_predictor_1, ',env$',params$env_predictor_2,'))')
  eq1  <- paste0(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
  eval(parse(text=eq1))
  
  colnames(env) <- eval(parse(text=paste0("c('Sample', 'cluster', '",params$env_predictor_1,"','",params$env_predictor_2,"')")))
  
  # Data prep
  species_binomial.genlight <- read.PLINK(paste0(genomic_data_path,species_binomial,'/',species_binomial,'.raw'), map.file = paste0(genomic_data_path,species_binomial,'/',species_binomial,'.map'),
                                          quiet = FALSE, chunkSize = 1000, parallel = FALSE, n.cores = NULL)
  
  identical(as.character(env[,1]), species_binomial.genlight@ind.names)
  
  species <- as.matrix(species_binomial.genlight)  
  
  species <- as.data.frame(species)
  
  lhs1 <- paste0('species.full',sep='')
  rhs1 <- paste0('as.data.frame(cbind(env$Sample, pop_assignment$pop, env$',params$env_predictor_1, ',env$',params$env_predictor_2,'))')
  eq1  <- paste0(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
  eval(parse(text=eq1))
  
  #colnames(species.full) <- c('Sample', 'cluster', 'bioclim_5', 'bioclim_18')
  colnames(species.full) <- eval(parse(text=paste0("c('Sample', 'cluster', '",params$env_predictor_1,"','",params$env_predictor_2,"')")))
  species.full <- cbind(species.full,species)
  species.full <- species.full[order(species.full$cluster),]
  species.full$cluster <- as.numeric(species.full$cluster)
  
  lhs1  <- paste0('species.full$',params$env_predictor_1,sep='')
  rhs1  <- paste0('as.numeric(species.full$',params$env_predictor_1,')', sep='')
  eq1   <- paste0(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
  eval(parse(text=eq1))
  lhs1  <- paste0('species.full$',params$env_predictor_2,sep='')
  rhs1  <- paste0('as.numeric(species.full$',params$env_predictor_2,')', sep='')
  eq1   <- paste0(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
  eval(parse(text=eq1))
  
  #Impute within clusters by taking the mean genotype across individuals
  
  # Below code generalises the code used for Razgour et al. (2017), makes it flexible
  nclust <- unique(species.full$cluster)
  n    <- length(nclust)
  lhs1  <- paste('species',    1:n,     sep='_')
  rhs1  <- paste('species.full[species.full$cluster==',1:n,', c(-1:-4)]', sep='')
  eq1   <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
  eval(parse(text=eq1))
  
  n    <- length(nclust)
  lhs2  <- paste('cMr')
  rhs2  <- paste('round(colMeans(species_',1:n,', na.rm =TRUE)); indx <- which(is.na(species_',1:n, '), arr.ind=TRUE); species_' ,1:n, '[indx] <- cMr[indx[,2]]', sep='')
  eq2   <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
  eval(parse(text=eq2))
  
  lhs3  <- paste('rbind(')
  rhs3 <- capture.output(cat(lhs1, sep=','))
  eq3 <- paste0(lhs3,rhs3,')')
  eval(parse(text=eq3))
  
  species_binomial.imp <- eval(parse(text=eq3))
  
  identical(as.character(species.full[,1]), row.names(species_binomial.imp))
  species_binomial.env <- species.full[,3:4]
  colnames(species_binomial.env) <- c(params$env_predictor_1, params$env_predictor_2)
  
  # Rename the SNPs names to match across lfmm, RDA and PCAdapt analyses 
  features <- species_binomial.genlight@loc.names
  colnames(species_binomial.imp) <- features
  inds <- species_binomial.genlight@ind.names
  rownames(species_binomial.env) <- inds
  
  # Run the RDA
  species_binomial.rda <- rda(species_binomial.imp ~ ., data=species_binomial.env, scale=T)  
  species_binomial.rda
  RsquareAdj(species_binomial.rda)
  summary(eigenvals(species_binomial.rda, model = 'constrained'))
  screeplot(species_binomial.rda)
  
  cat('** WARNING: Decision needed - how many axes to retain for the RDA? Default is to match the number of predictors - in this case: ',ncol(species_binomial.env),'(',params$env_predictor_1,',',params$env_predictor_2,')\n', file=file.path(log_file), append=T)
  
  axes <- params$rda_axes
  
  # Check predictors are not too highly correlated
  
  vif.cca(species_binomial.rda) 
  
  # Plot the RDA
  colorby <- species.full[,2]
  
  clusters <- lhs1
  clusters <- toString(clusters)
  clusters <- gsub('species','Cluster',clusters)
  
  legend_text <- gsub('Cluster',"'Cluster", clusters)
  legend_text <- gsub(',',"',", legend_text)
  legend_text <- paste0(legend_text,"'")
  legend_text <- paste0('c(',legend_text,')')
  legend_text <- toString(legend_text)                
  levels(colorby) <- paste0('c(',clusters,')')
  
  png(filename=paste0(output_path,species_binomial,'_RDA_plot.png'), 
      type='cairo', units='cm', width=40, height=20, pointsize=12, res=300)
  par(cex.main=2, cex.axis=1.5)
  par(mfrow=c(1,2))
  par(mar=c(5,5,5,5))
  plot(species_binomial.rda, type='n', scaling=3, cex.lab=2, main = paste0(species_binomial))
  points(species_binomial.rda, display='species', pch=20, cex=0.7, col='gray32', scaling=3)
  points(species_binomial.rda, display='sites', pch=21, cex=1.3, col='gray32',scaling=3, bg=colours[colorby])
  text(species_binomial.rda, scaling = 3, labels=c(params$env_predictor_1,params$env_predictor_2), display = 'bp', col='#0868ac', cex=1.1)
  legend('topleft', legend = eval(parse(text=legend_text)), bty = 'n', col='gray32', pch = 21, cex=1.3, pt.bg = colours)
  screeplot(species_binomial.rda, main = 'Screeplot')
  dev.off()
  
  # species_binomial outlier detection
  # all candidates
  load.species_binomial <- summary(species_binomial.rda)$species[,1:2]  # loadings on constrained axes
  n_predictors <- ncol(species_binomial.env)
  
  #z <- 2.5 #sd from mean to class as outliers - 3 is more conservative
  lhs4 <- paste0('cand_',1:n_predictors)
  rhs4 <- paste0('outliers(',1:n_predictors, ',',params$rda_SD,',load.species_binomial, species_binomial.env, species_binomial.imp)')
  eq4 <- paste(paste(lhs4,rhs4, sep=' <- '), collapse='; ')
  eval(parse(text=eq4))
    
  lhs4 <- toString(lhs4)
  species_binomial.cand <- rbind.data.frame(cand_1,cand_2)
  lhs5 <- paste0('species_binomial.cand')
  rhs5 <- paste0('rbind.data.frame(',lhs4,')')
  eq5 <- paste(paste(lhs5,rhs5, sep=' <- '), collapse='; ')
  eval(parse(text=eq5))
  
  corr_text <- paste0('Corr-env',1:n_predictors)
  p_value_text <- paste0('p-env',1:n_predictors)
  corr_p_value_text <- paste0(paste(corr_text,p_value_text))
  corr_p_value_text <- toString(corr_p_value_text)
  corr_p_value_text <- gsub(" p",",p",corr_p_value_text)
  corr_p_value_text <- gsub(" ",",",corr_p_value_text)
  corr_p_value_text <- gsub(",,",",",corr_p_value_text)
  corr_p_value_text <- gsub(",","','",corr_p_value_text)
  corr_p_value_text <- paste0("'",corr_p_value_text)
  corr_p_value_text <- paste0(corr_p_value_text,"'")
  
  colnames_candidate_SNPs_first_three_columns <- c('SNP','Loading','Axis')
  
  lhs6 <- paste0('colnames_candidate_SNPs_remaining_columns')
  rhs6 <- paste0('c(',corr_p_value_text,')')
  eq6 <- paste(paste(lhs6,rhs6, sep=' <- '), collapse='; ')
  eval(parse(text=eq6))
  
  colnames_candidate_SNPs <- c(paste0(colnames_candidate_SNPs_first_three_columns),paste0(colnames_candidate_SNPs_remaining_columns))
  
  ####
  # if there are RDA SNPs identified, go on as normal, otherwise skip to the end
  if (length(species_binomial.cand)!='0'){
  colnames(species_binomial.cand) <- paste0(colnames_candidate_SNPs)
  
  species_binomial.cand$SNP <- as.character(species_binomial.cand$SNP)
  species_binomial.cand$SNP[duplicated(species_binomial.cand$SNP)] # Check there are no duplicate detections
  
  # from here it needs slightly more generalising in case of extra environmental predictors (here uses 2)
  for (i in 1:length(species_binomial.cand$SNP)) {
    bar <- species_binomial.cand[i,]
    species_binomial.cand[i,8] <- names(which.max(abs(bar[c(4,6)]))) # gives the variable
  }
  colnames(species_binomial.cand)[8] <- 'Max_corr'

# round to 2 dp for correlations
	species_binomial.cand$`Corr-env1` <- round(species_binomial.cand$`Corr-env1`,2)
	species_binomial.cand$`Corr-env2` <- round(species_binomial.cand$`Corr-env2`,2)

  write.csv(species_binomial.cand, file=paste0(output_path, species_binomial,'_RDA_candidate_SNPs_by_predictor_SD_',params$rda_SD,'.csv'), row.names=F)
  
  cat('> Output candidate SNPs saved and plotted \n', file=log_file, append=T)
  
  # Summarise the candidate SNPs associated with each predictor
  table(species_binomial.cand$Max_corr)
  # Summarise the candidate SNPs associated with each RDA axis
  table(species_binomial.cand$Axis)
  
  # species_binomial outlier plot
  sel <- species_binomial.cand$SNP
  env <- species_binomial.cand$Max_corr
  env[env=='Corr-env1'] <- '#e53032'
  env[env=='Corr-env2'] <- '#3585bb'
  
  # color snps by predictor
  all.snp <- rownames(species_binomial.rda$CCA$v)
  test <- all.snp
  
  for (i in 1:length(sel)) {
    foo <- match(sel[i],test)
    test[foo] <- env[i]
  }
  
  test[grep('_',test)] <- '#f1eef6'
  
  empty <- test
  empty[grep('#f1eef6',empty)] <- rgb(0,1,0, alpha=0) # transparent
  
  empty.outline <- ifelse(empty=='#00FF0000','#00FF0000','gray32')
  
  # Color by env predictor
  png(filename=paste0(output_path,species_binomial,'_RDA_SNPs.png'), 
      type='cairo', units='cm', width=35, height=35, pointsize=12, res=300)
  par(cex.main=2, cex.axis=1.5)
  par(mar=c(5,5,5,5))
  plot(species_binomial.rda, type='n', scaling=3, xlim=c(-1.5,1), ylim=c(-1,1), cex.axis=2, cex.lab=2)
  points(species_binomial.rda, display='species', pch=21, cex=1.3, col='gray32', bg=test, scaling=3)
  points(species_binomial.rda, display='species', pch=21, cex=1.3, col=empty.outline, bg=empty, scaling=3)
  text(species_binomial.rda, scaling = 3, labels=c(params$env_predictor_1,params$env_predictor_2), display = 'bp', col='#0868ac', cex=2)
  bg <- c('#e53032','#3585bb')
  legend('topleft', legend = c(params$env_predictor_1,params$env_predictor_2), bty = 'n', col='gray32', pch = 21, cex=2, pt.bg = bg)
  dev.off()
  
  }else{
  cat('RDA analysis found no SNPs with your given parameters! Try modifying the SD/GIF if you really need to, but dont go fishing \n', file=log_file, append=T)
  }
  
  # Here, if desired, we can postprocess the RDA results by adjusting the GIF, as we did for the LFMM analyses
  # This gives a list based on the set FDR thresholds, defined by the adjustment of the GIF
  
  # RDA outliers 
  load.rda <- scores(species_binomial.rda, choices=c(1:axes), display='species') # RDA loadings ('species') for axes 1:axes (defined above)
  
  # plot the histograms of loadings per predictor
  png(filename=paste0(output_path,species_binomial,'_RDA_histogram_loadings_SD_',params$rda_SD,'.png'), 
      type='cairo', units='cm', width=30, height=30, pointsize=12, res=300)
  par(cex.main=2, cex.axis=1.5, cex.lab=2)
  par(mar=c(5,5,5,5))
  par(mfrow=c(2,1))
  hist(load.rda[,1]) # histogram of loadings on RDA axis 1
  hist(load.rda[,2]) # histogram of loadings on RDA axis 2
  dev.off()
  
  zscale <- apply(load.rda, 2, scale)        
  mscale <- covRob(zscale, distance=TRUE, na.action=na.omit, estim='pairwiseGK')$dist
  
  (gif <- median(mscale)/qchisq(0.5, df=axes))
  gif
  
  cat('> Calculated GIF for predictor variables is: ',gif,'\n', file=file.path(log_file), append=T)
  
  rda.pval <- pchisq(mscale/gif, df=axes, lower.tail=FALSE)
  hist(rda.pval)
  
  scale_gif <- params$scale_gif_rda
  
  new.gif <- (gif*scale_gif)               # choose/change your modified GIF
  rda.pval1 <- pchisq(mscale/new.gif, df=axes, lower.tail=FALSE) 
  hist(rda.pval1) # this may look better, or be too liberal, depending on # of axes
  
  cat('> Updated GIF is: ',new.gif,' (original GIF*',scale_gif,')\n', file=file.path(log_file), append=T)
  
  png(filename=paste0(output_path,species_binomial,'_RDA_p_value_distribution.png'), 
      type='cairo', units='cm', width=30, height=30, pointsize=12, res=300)
  par(cex.main=2, cex.axis=1.5, cex.lab=2)
  par(mar=c(5,5,5,5))
  par(mfrow=c(2,1))
  hist((rda.pval), main='unadjusted p-values')       
  hist(rda.pval1, main='adjusted p-values')
  dev.off()
  
  cat('> Output summary of adjusted vs. unadjusted p-values plotted \n', file=file.path(log_file), append=T)
  
  #I'm using the modified p-values here...
  rda.qval <- qvalue(rda.pval1)$qvalues  
  (length(rFDR.1  <- which(rda.qval < 0.10)))  # how many candidates with an FDR=10%
  (length(rFDR.05 <- which(rda.qval < 0.05)))  # how many candidates with an FDR=5%
  (length(rFDR.01 <- which(rda.qval < 0.01)))  # how many candidates with an FDR=1%
  
  # We'll index on the column names (SNPs) from the input data set
  rda.FDR.1  <- colnames(species.full)[rFDR.1]
  rda.FDR.05 <- colnames(species.full)[rFDR.05]
  rda.FDR.01 <- colnames(species.full)[rFDR.01]
  
  all_candidates <- qpcR:::cbind.na(rda.FDR.1, rda.FDR.05, rda.FDR.01)
  
  # Write out the candidate SNPs to file
  write.csv(all_candidates, paste0(output_path,species_binomial,'_RDA_candidate_SNPs.csv'))
  
  # Look at where these candidates are in the ordination space:
  # Setting up the color scheme for plotting: neutral snps in gray, candidate snps in red
  snp.color     <- as.data.frame(colnames(species.full), stringsAsFactors=F)
  snp.color[,2] <- sapply(colnames(species.full), function(x) if(x %in% rda.FDR.05) 'gray32'  else '#00000000')
  snp.color[,3] <- sapply(colnames(species.full), function(x) if(x %in% rda.FDR.05) 'darkorange' else '#00000000')
  
  # axes 1 & 2 - zooming in to just the SNPs...
 # png(filename=paste0(output_path,species_binomial,'_RDA_SNPs_post_FDR<0.05_cutoff.png'), 
 # type='cairo', units='cm', width=35, height=35, pointsize=12, res=300)
 # par(cex.main=2, cex.axis=1.5, cex.lab=2)
 # par(mar=c(5,5,5,5))
 # plot(species_binomial.rda, type='n', scaling=3, xlim=c(-1.5,1), ylim=c(-1,1))
 # points(species_binomial.rda, display='species', pch=21, cex=1.3, col='gray32', bg='#f1eef6', scaling=3)
 # points(species_binomial.rda, display='species', pch=21, cex=1.3, col=snp.color[,2], bg=snp.color[,3], scaling=3)
 # text(species_binomial.rda, scaling=3, display='bp', col='#0868ac', cex=2)
 # legend('topleft', legend = c('post-FDR<0.05 cutoff'), bty = 'n', col='gray32', pch = 21, cex=2, pt.bg = 'darkorange')
 # dev.off()
  
  cat('> Output plot of candidate SNPs (post cut-off) saved and plotted \n', file=file.path(log_file), append=T)
  cat('> Candidate SNPs SD±',params$rda_SD,':', nrow(species_binomial.cand),'\n', file=file.path(log_file), append=T)
  cat('> Candidate SNPs FDR<0.1:', length(rda.FDR.1),'\n', file=file.path(log_file), append=T)
  cat('> Candidate SNPs FDR<0.05:', length(rda.FDR.05),'\n', file=file.path(log_file), append=T)
  cat('> Candidate SNPs FDR<0.01:', length(rda.FDR.01),'\n', file=file.path(log_file), append=T)
  cat('> RDA analysis completed successfully...\n\n', file=file.path(log_file), append=T)
  

  }

#############################################################################################################################################################################################
gea_rda_individual_categorisation <- function(species_binomial) {
##############################################################################################################################################################################################
  
  # Performs individual categorisation in ordination space using RDA
  # adaptive categroies defined in the params.tsv file
  
  library(LEA)
  library(adegenet)
  library(vegan)     # v 2.4-4
  library(tidyverse)
  library(data.table)
  
  rm(list=ls(all=TRUE))
  
  root_dir <- ('$YOUR_WORK_DIR/')
  setwd(root_dir)
  
  spatial_data_path <- './-data-/spatial_data/'
  
  # read args
  args <- commandArgs()
  print(args)
  species_binomial <- args[8]  # This may vary between systems depending on your HPC setup, the list of arguments will be printed at the beginning of your SLURM job logfile so if the jobs fail, make sure that this number matches the number in args[] that matches your species name
  
  # set params file
  params_all <- read.delim('./Params.tsv')
  
  # Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
  params <- params_all[which(params_all$species_binomial==species_binomial),]
  species_binomial <- params$species_binomial
  
  log_file <- paste0('./-outputs-/log_files/',species_binomial,'.log')
  sensitivity_path <- paste0('./-outputs-/',species_binomial,'/Sensitivity/')
  output_path <- paste0(sensitivity_path,'Adaptive_sensitivity/')
  
  cat('--------------------------------------------------------------\n', file=log_file, append=T)
  cat('Categorising individuals (using RDA)...\n', file=log_file, append=T)
  cat('--------------------------------------------------------------\n', file=log_file, append=T)
  
  # Data prep
  # --------------
  cat('Reading in environmental and genomic data...\n', file=log_file, append=T)
  
  # Subset only the relevant individuals
  temp1 <- "sel.ind <- as.character(read.table('"
  temp2 <- paste0("-data-/genomic_data/",species_binomial,"/",species_binomial,".ped'")
  temp3 <- ")[,2])"
  temp <- paste0(temp1,temp2,temp3)
  eval(parse(text=temp))
  
  # # Read in full env data
  env <- read.csv(paste0(spatial_data_path,species_binomial,'/',species_binomial,'_full_env_data.csv'))
  env <- env[c(params$env_predictor_1,params$env_predictor_2)]
  temp1 <- "rownames(env) <- as.character(read.table('"
  temp2 <- paste0("-data-/genomic_data/",species_binomial,"/",species_binomial,".ped'")
  temp3 <- ")[,2])"
  temp <- paste0(temp1,temp2,temp3)
  eval(parse(text=temp))
  
  # All loci identified:
  temp1 <- "loci.overlap <- as.character(read.table('"
  temp2 <- paste0("-data-/genomic_data/",species_binomial,"/",species_binomial,".map'")
  temp3 <- ")[,2])"
  temp <- paste0(temp1,temp2,temp3)
  eval(parse(text=temp))
  loci.overlap_df <- as.data.frame(loci.overlap)
  colnames(loci.overlap_df) <- 'Locus'
  
if (params$skip_gea=='yes'){  
  adaptive_loci <- readLines(paste0(output_path,species_binomial,'_adaptive_loci.txt'))  
  adaptive_loci <- str_split(adaptive_loci, pattern= ' ')  
  adaptive_loci <- unlist(adaptive_loci)
} else {

if (params$use_statistically_validated_snps_only=='yes'){  
  adaptive_loci <- readLines(paste0(output_path,species_binomial,'_adaptive_loci_validated.txt'))  
  adaptive_loci <- str_split(adaptive_loci, pattern= ' ')  
  adaptive_loci <- unlist(adaptive_loci)
}

if (file.exists(paste0(output_path,species_binomial,'_RDA_candidate_SNPs_by_predictor_SD_',params$rda_SD,'.csv')) | file.exists(paste0(output_path,species_binomial,'_LFMM_candidate_SNPs_by_predictor_FDR_',params$lfmm_FDR_threshold,'.csv'))) {

  # read in the output files from previous RDA and LFMM analyses
  #RDA
  RDA_adaptive_list <- read.csv(paste0(output_path,species_binomial,'_RDA_candidate_SNPs_by_predictor_SD_',params$rda_SD,'.csv'))
  RDA_adaptive_list <- RDA_adaptive_list$SNP
  RDA_adaptive_list <- na.omit(RDA_adaptive_list)
  RDA_adaptive_list <- str_sub(RDA_adaptive_list,1,nchar(RDA_adaptive_list)-2) # remove last two characters for each locus (e.g. _A) so they match the loci.overlap data
  
  #RDA gif adjusted
  RDA_adaptive_list_gif_adjusted <- read.csv(paste0(output_path,species_binomial,'_RDA_candidate_SNPs.csv'))
  RDA_adaptive_list_gif_adjusted <- RDA_adaptive_list_gif_adjusted $rda.FDR.05
  RDA_adaptive_list_gif_adjusted <- na.omit(RDA_adaptive_list_gif_adjusted)
  RDA_adaptive_list_gif_adjusted <- str_sub(RDA_adaptive_list_gif_adjusted,1,nchar(RDA_adaptive_list_gif_adjusted)-2) # remove last two characters for each locus (e.g. _A) so they match the loci.overlap data
  
  #LFMM FDR<0.05
  LFMM_adaptive_list <- read.csv(paste0(output_path,species_binomial,'_LFMM_candidate_SNPs.csv'))
  LFMM_adaptive_list <- LFMM_adaptive_list$LFMM.FDR.05
  LFMM_adaptive_list <- na.omit(LFMM_adaptive_list)
  LFMM_adaptive_list <- str_sub(LFMM_adaptive_list,1,nchar(LFMM_adaptive_list)-2) # remove last two characters for each locus (e.g. _A) so they match the loci.overlap data
  LFMM_adaptive_list <- LFMM_adaptive_list[LFMM_adaptive_list != "0"] # remove any zeros
  
  # Select which adaptive loci you want by setting params$which_loci in the params file
  # 0: only statistically validated loci based on simulations
  # 1: present in either RDA (SD<3) or LFMM (FDR<0.05)
  # 2: present in either RDA (FDR<0.05) or LFMM (FDR<0.05)
  # 3: only LFMM loci (FDR<0.05)
  # 4: only RDA loci (SD<3)
  # 5: only RDA loci (FDR<0.05)
  # 6: present in both RDA (SD<3) and LFMM (FDR<0.05)
  # 7: present in both RDA (FDR<0.05) and LFMM (FDR<0.05) - not recommended, often 0 loci
  
if (params$which_loci==0){
    adaptive_loci <- readLines(paste0(output_path,species_binomial,'_adaptive_loci_validated.txt'))  
    adaptive_loci <- str_split(adaptive_loci, pattern= ' ')  
    adaptive_loci <- unlist(adaptive_loci)
    adaptive_loci <- adaptive_loci[1:(length(adaptive_loci)-1)] # to get rid of trailing last blank entry
cat('Subsetting adaptive loci to retain only ones that were statistically validated using simulations...\n', file=log_file, append=T)
    cat('Number of loci: ',length(adaptive_loci),'\n', file=log_file, append=T)
}
 if (params$which_loci==1){
    adaptive_loci <- c(as.character(RDA_adaptive_list),as.character(LFMM_adaptive_list))
    cat('Subsetting adaptive loci present in either LFMM (FDR<0.05) or RDA (SD<3) analyses...\n', file=log_file, append=T)
    cat('Number of loci: ',length(adaptive_loci),'\n', file=log_file, append=T)
  } 
  if (params$which_loci==2){
    adaptive_loci <- c(as.character(RDA_adaptive_list_gif_adjusted),as.character(LFMM_adaptive_list))
    cat('Subsetting adaptive loci present in either LFMM (FDR<0.05) or RDA (FDR<0.05) analyses...\n', file=log_file, append=T)
    cat('Number of loci: ',length(adaptive_loci),'\n', file=log_file, append=T)
  } 
  if (params$which_loci==3){
    adaptive_loci <- as.character(LFMM_adaptive_list)
    cat('Subsetting adaptive loci present in LFMM (FDR<0.05) analysis only...\n', file=log_file, append=T)
    cat('Number of loci: ',length(adaptive_loci),'\n', file=log_file, append=T)
  } 
  if (params$which_loci==4){
    adaptive_loci <- as.character(RDA_adaptive_list)
    cat('Subsetting adaptive loci present in RDA (SD<3) analysis only...\n', file=log_file, append=T)
    cat('Number of loci: ',length(adaptive_loci),'\n', file=log_file, append=T)
  } 
  if (params$which_loci==5){
    adaptive_loci <- as.character(RDA_adaptive_list_gif_adjusted)
    cat('Subsetting adaptive loci present in RDA (FDR<0.05) analysis only...\n', file=log_file, append=T)
    cat('Number of loci: ',length(adaptive_loci),'\n', file=log_file, append=T)
  } 
  if (params$which_loci==6){
    adaptive_list_df <- as.data.frame(RDA_adaptive_list)
    colnames(adaptive_list_df) <- 'Locus'
    adaptive_list <- adaptive_list_df[adaptive_list_df$Locus %in% LFMM_adaptive_list, ]
    adaptive_loci <- loci.overlap_df[loci.overlap_df$Locus %in% adaptive_list, ]
    cat('Subsetting adaptive loci present in both LFMM (FDR<0.05) and RDA (SD<3) analyses...\n', file=log_file, append=T)
    cat('Number of loci: ',length(adaptive_loci),'\n', file=log_file, append=T)
  } 
  if (params$which_loci==7){
    adaptive_list_df <- as.data.frame(RDA_adaptive_list_gif_adjusted)
    colnames(adaptive_list_df) <- 'Locus'
    adaptive_list <- adaptive_list_df[adaptive_list_df$Locus %in% LFMM_adaptive_list, ]
    adaptive_loci <- loci.overlap_df[loci.overlap_df$Locus %in% adaptive_list, ]
    cat('Subsetting adaptive loci present in both LFMM (FDR<0.05) and RDA (FDR<0.05) analyses...\n', file=log_file, append=T)
    cat('Number of loci: ',length(adaptive_loci),'\n', file=log_file, append=T)
  } 
  
  # write this out to file (use it later for masking out adaptive regions when calculating neutral GD)
 if (params$which_loci!=0){
      writeLines(adaptive_loci, paste0(output_path,species_binomial,'_adaptive_loci.txt'), sep=' ')
  }
  # add a blank line at the end
  line = ""
  write(line, file = paste0(output_path,species_binomial,'_adaptive_loci.txt'), append =TRUE)
  } else {
  adaptive_loci <- readLines(paste0(output_path,species_binomial,'_adaptive_loci.txt'))  
  adaptive_loci <- str_split(adaptive_loci, pattern= ' ')  
  adaptive_loci <- unlist(adaptive_loci)
  cat('Skipped GEAs and basing further analysis on the supplied list of adaptive SNPs\n', file=log_file, append=T)
}
}  
  # Subset the imputed data:
  imp <- read.geno(paste0('-data-/genomic_data/',species_binomial,'/',species_binomial,'_imp.geno')) 
  row.names(imp) <- row.names(env)
  
  temp1 <- "colnames(imp) <- as.character(read.table('"
  temp2 <- paste0("-data-/genomic_data/",species_binomial,"/",species_binomial,".map'")
  temp3 <- ")[,2])"
  temp <- paste0(temp1,temp2,temp3)
  eval(parse(text=temp))
  

  # Check genomic and environmental data match
  species.overlap <- imp[sel.ind, adaptive_loci]
  identical(rownames(env), rownames(species.overlap))  # same order?
  
  cat('Performing RDA to categorise individuals...\n', file=log_file, append=T)
  
  # Adaptive RDA
  # This has a couple of embedded functions that will extract the coordinates of the biplot arrows of the RDA for your variables and add a 45 degree angle to either side 
  # and use this to create a polygon that captures the individuals that are falling within this range of each selected predictor (i.e. in a 90 degree radius following Razgour et al. 2019)
    
  RDA_overlap <- rda(species.overlap ~ ., data=env, scale=T)
  
  # Individual Loadings
  # -------------------
  ind.overlap <- scores(RDA_overlap, display='sites', scaling=3)  # individual ('sites') loadings on constrained axes
  write.csv(ind.overlap, paste0(output_path,species_binomial,'_RDA_ind_scores_climate_SNPs.csv'), row.names=T)
  
  # RDA plot initial - plots inds in ordination space and biplot arrows
  plot(RDA_overlap, type='n', scaling=3)
  points(RDA_overlap, display='sites', pch=21, cex=1.3, col='gray32',scaling=3, bg='gray95') #inds
  text(RDA_overlap, scaling = 3, labels=c(params$env_predictor_1,params$env_predictor_2), display = 'bp', col='forestgreen', cex=1.1) #biplot
  
  # extract coords of the biplot arrows and plot them 
  biplot_coords <- scores(RDA_overlap, scaling=3, display='bp')
  
  # extend biplots 
  biplot_coords_extend <- biplot_coords*1000 # extend the biplots to give one of the polygon points to ensure all points captured 
  points(biplot_coords,pch=21, cex=0.5,col='green')
  points(biplot_coords_extend,pch=21, cex=0.5,col='green')
   
  # get slope (=bearing) of first predictor biplot (Y2-Y1/X2-X1)
  biplot_coords <- scores(RDA_overlap, scaling=3, display='bp')
  env_1 <- biplot_coords[1,]
  env_1_slope <- (env_1[2]-0)/(env_1[1]-0)
  env_2 <- biplot_coords[2,]
  env_2_slope <- (env_2[2]-0)/(env_2[1]-0)
  
  plot(RDA_overlap, type='n', scaling=3)
  points(RDA_overlap, display='sites', pch=21, cex=1.3, col='gray32',scaling=3, bg='gray95') #inds
  text(RDA_overlap, scaling = 3, labels=c(params$env_predictor_1,params$env_predictor_2), display = 'bp', col='forestgreen', cex=1.1) #biplot
  abline(a=0,b=env_1_slope, lty=1, lwd=1.5, col='purple')
  
  # FUNCTIONS
  ## (0) Load required packages
  library(maptools)  ## For ContourLines2SLDF(), used for example data
  library(sp)        ## For spDists() and CRS()
  library(rgeos)     ## For gIntersection()
  library(geosphere) ## For gcIntermediate(), yielding paths along great circles
  
  ## (1) Define a couple of functions ...
  
  ## ... first a utility function that converts a two-column matrix of
  ## x-y coordinates (like that returned by geosphere::gcIntermediate)
  ## to a SpatialLines object (as needed by, e.g., rgeos::gIntersection) ...
  xyMatToSL <- function(mat, prj=CRS("+proj=longlat")) {
    id <- paste0(sample(letters, 10), collapse = "")
    linesList <- list(Lines(Line(mat), ID = id))
    SpatialLines(linesList, proj4string = prj)
  }
  
  ## ... and then a main function that computes a segment of a great
  ## circle beginning from a given focal point at a given initial
  ## bearing and travels until its first intersection with a line OR
  ## until it has gone maxDist meters.
  focalToFirstGCIntersection <-
    function(focalPt, lineLayer, initBearing=0, maxDist=1e6) {
      ## Draw a long line from pt at an initial bearing
      destPt <- destPoint(focalPt, b = initBearing, d = maxDist)
      gcSegment <- xyMatToSL(gcIntermediate(focalPt, destPt, n=100, addStartEnd=TRUE))
      ## Find nearest points of intersection or, if none, return point at given distance
      candidatePts <- gIntersection(gcSegment, lineLayer)
      destPt <- if(is.null(candidatePts)) {
        destPt} else {candidatePts[which.min(spDists(focalPt, candidatePts))]}
      ## Construct a line from point to it
      xyMatToSL(gcIntermediate(focalPt, destPt, addStartEnd=TRUE))
    }
    
  prj <- CRS("+proj=longlat")
  centre <- readWKT("POINT(0 0)", p4s=prj)
  
  # get box around plot area
  plot_lims <- par('usr')
  xlim_lower <- plot_lims[1]
  xlim_upper <- plot_lims[2]
  ylim_lower <- plot_lims[3]
  ylim_upper <- plot_lims[4]
  plot_area <- cbind(c(xlim_lower, xlim_upper, xlim_upper, xlim_lower, xlim_lower), c(ylim_upper, ylim_upper, ylim_lower, ylim_lower, ylim_upper))
  line_plot_area <- Line(plot_area)
  list_line_plot_area <- Lines(list(line_plot_area), ID = "a")
  spatial_lines_plot_area <- SpatialLines(list(list_line_plot_area))
  plot(spatial_lines_plot_area, lwd= 3, add=T, col='purple')
  
  # Predictor 1
  par(mfrow=c(1,1))
  plot(RDA_overlap, type='n', scaling=3)
  points(RDA_overlap, display='sites', pch=21, cex=1.3, col='gray32',scaling=3, bg='gray95') #inds
  text(RDA_overlap, scaling = 3, labels=c(params$env_predictor_1,params$env_predictor_2), display = 'bp', col='forestgreen', cex=1.1) #biplot
  
  # convert slope to bearing
  #https:/math.stackexchange.com/questions/1385006/how-do-i-convert-a-line-angle-to-a-navigational-bearing-scale-i-e-with-range
  angle_direction <- atan(env_1_slope) # arc tangent of slope of predictor biplot in radians
  degrees <- angle_direction*(180/3.142) # multiply by 180/pi to get degrees
  bearing <- 90 - degrees  # subtract from 90 degrees to match azimuthal bearings
  
  ## Compute great circle segments of maximum length 400 km.
  thetas <- seq(bearing,bearing+360,by=45)
  outLines <- lapply(thetas, function(X) {
    focalToFirstGCIntersection(centre, spatial_lines_plot_area, initBearing=X, maxDist=4000000)
  })
  outLines <- do.call(rbind, outLines)
  
  ## Plot results
  plot(outLines, col = "purple", lwd = 3, add = TRUE)
  
  # line 1 of outLines is not always the bearing you supplied (with thetas)
  # to find which outLine is the predictor can use biplots end point to see which one intersects with each line 

  biplot_coords <- scores(RDA_overlap, scaling=3, display='bp')
  biplot_coords <- data.frame(biplot_coords)
  biplot_coords <- biplot_coords[1,]
  prj <- CRS("+proj=longlat")

# draw biplot point  
biplot_point <- readWKT(paste0("POINT(",biplot_coords$RDA1," ",biplot_coords$RDA2,")", ",p4s=prj)"))

# add a small buffer to ensure it is not missed
biplot_point <- rgeos::gBuffer(biplot_point, width=0.2)
plot(biplot_point, add=T)

# intersect all outLines with the point to give true/false
intersect <- rgeos::gIntersects(biplot_point,outLines, byid = c(TRUE,TRUE))
lines_in_sequence <- as.data.frame(c(1:length(intersect)))
intersect_true_false <- as.data.frame(intersect)
lines <- cbind(lines_in_sequence,intersect_true_false)  
colnames(lines) <- c('line_number','true_false')
lines <- lines[1:(nrow(lines)-1),] # remove the last line (duplicate)

# grab the correct line
line_of_predictor <- which(lines$true_false=='TRUE')  
# so the inner an outer lines to make the required polygon for each predictor based on biplot positions are:
# line_of_predictor+1, line_of_predictor-1
# unless line of predictor = 1, then it is 
# line_of_predictor+1, #nrow(lines-1)
  
# these are all the end coords of the lines
  points(biplot_coords[1,])
  point1 <- outLines@lines[[1]] #
  point1 <- as.data.frame(coordinates(point1))
  point1 <- point1[52,]
  points(point1, add=T, cex=4)
  point2 <- outLines@lines[[2]]
  point2 <- as.data.frame(coordinates(point2))
  point2 <- point2[52,]
  points(point2, add=T, cex=4)
  point3 <- outLines@lines[[3]] #
  point3 <- as.data.frame(coordinates(point3))
  point3 <- point3[52,]
  points(point3, add=T, cex=4)
  point4 <- outLines@lines[[4]]
  point4 <- as.data.frame(coordinates(point4))
  point4 <- point4[52,]
  points(point4, add=T, cex=4)
  point5 <- outLines@lines[[5]]
  point5 <- as.data.frame(coordinates(point5))
  point5 <- point5[52,]
  points(point5, add=T, cex=4)
  point6 <- outLines@lines[[6]]
  point6 <- as.data.frame(coordinates(point6))
  point6 <- point6[52,]
  points(point6, add=T, cex=4)
  point7 <- outLines@lines[[7]]
  point7 <- as.data.frame(coordinates(point7))
  point7 <- point7[52,]
  points(point7, add=T, cex=4)
  point8 <- outLines@lines[[8]]
  point8 <- as.data.frame(coordinates(point8))
  point8 <- point8[52,]
  points(point8, add=T, cex=4)

  # take end points of lines adjacent to line_of_predictor for each biplot vector
  point1 <- outLines@lines[[line_of_predictor+1]] #
  point1 <- as.data.frame(coordinates(point1))
  point1 <- point1[52,]
  points(point1, add=T, cex=4, col='red')
  
  if (line_of_predictor == 1) {
  point2 <- outLines@lines[[nrow(lines-1)]]
  point2 <- as.data.frame(coordinates(point2))
  point2 <- point2[52,]
  points(point2, add=T, cex=4, col='red')  }else
    {
  point2 <- outLines@lines[[line_of_predictor-1]]
  point2 <- as.data.frame(coordinates(point2))
  point2 <- point2[52,]
  points(point2, add=T, cex=4, col='red')
    }
  
  origin <- as.data.frame(cbind(0,0)) # origin (0,0)
  
  # make polygon
  poly1_x <- as.numeric(c(origin[1], point1[1], biplot_coords_extend[1,1], point2[1]))
  poly1_y <- as.numeric(c(origin[2], point1[2], biplot_coords_extend[1,2], point2[2]))
  poly1_full <- sp::Polygon(cbind(poly1_x,poly1_y))
  poly1 <- sp::SpatialPolygons(list(sp::Polygons(list(poly1_full), ID='A')))
  plot(poly1, col="tomato", add=T)
  
  # Predictor 2
  par(mfrow=c(1,1))
  plot(RDA_overlap, type='n', scaling=3)
  points(RDA_overlap, display='sites', pch=21, cex=1.3, col='gray32',scaling=3, bg='gray95') #inds
  text(RDA_overlap, scaling = 3, labels=c(params$env_predictor_1,params$env_predictor_2), display = 'bp', col='forestgreen', cex=1.1) #biplot
  
  # convert slope to bearing
  #https:/math.stackexchange.com/questions/1385006/how-do-i-convert-a-line-angle-to-a-navigational-bearing-scale-i-e-with-range
  angle_direction <- atan(env_2_slope) # arc tangent of slope of predictor biplot in radians
  degrees <- angle_direction*(180/3.142) # multiply by 180/pi to get degrees
  bearing <- 90 - degrees  # subtract from 90 degrees to match azimuthal bearings
  
  ## Compute great circle segments of maximum length 400 km.
  thetas <- seq(bearing,bearing+360,by=45)
  outLines <- lapply(thetas, function(X) {
    focalToFirstGCIntersection(centre, spatial_lines_plot_area, initBearing=X, maxDist=4000000)
  })
  outLines <- do.call(rbind, outLines)
  
  ## Plot results
  plot(outLines, col = "purple", lwd = 3, add = TRUE)
  
  # line 1 of outLines is not always the bearing you supplied (with thetas)
  # to find which outLine is the predictor can use biplots end point to see which one intersects with each line 
  
  biplot_coords <- scores(RDA_overlap, scaling=3, display='bp')
  biplot_coords <- data.frame(biplot_coords)
  biplot_coords <- biplot_coords[2,]
  prj <- CRS("+proj=longlat")
  
  # draw biplot point  
  biplot_point <- readWKT(paste0("POINT(",biplot_coords$RDA1," ",biplot_coords$RDA2,")", ",p4s=prj)"))
  
  # add asmall buffer to ensure it is not missed
  biplot_point <- rgeos::gBuffer(biplot_point, width=0.2)
  plot(biplot_point, add=T)
  
  # intersect all outLines with the point to give true/false
  intersect <- rgeos::gIntersects(biplot_point,outLines, byid = c(TRUE,TRUE))
  lines_in_sequence <- as.data.frame(c(1:length(intersect)))
  intersect_true_false <- as.data.frame(intersect)
  lines <- cbind(lines_in_sequence,intersect_true_false)  
  colnames(lines) <- c('line_number','true_false')
  lines <- lines[1:(nrow(lines)-1),] # remove the last line (duplocate)
  
  # grab the correct line
  line_of_predictor <- which(lines$true_false=='TRUE')  
  
  # take the middle one if multiple lines interesect (should be correct as the first and last are the inner and outers
  if (length(line_of_predictor) > 1) {
      line_of_predictor <- median(line_of_predictor)
    }
  #
  #so the inner an outer lines to make the required polygon for each predictor based on biplot positions are:
  # line_of_predictor+1, line_of_predictor-1
  # unless line of predictor = 1, then it is 
  # line_of_predictor+1, #nrow(lines-1)
  
  # these are all the end coords of the lines
  points(biplot_coords[1,])
  point1 <- outLines@lines[[1]] #
  point1 <- as.data.frame(coordinates(point1))
  point1 <- point1[52,]
  points(point1, add=T, cex=4)
  point2 <- outLines@lines[[2]]
  point2 <- as.data.frame(coordinates(point2))
  point2 <- point2[52,]
  points(point2, add=T, cex=4)
  point3 <- outLines@lines[[3]] #
  point3 <- as.data.frame(coordinates(point3))
  point3 <- point3[52,]
  points(point3, add=T, cex=4)
  point4 <- outLines@lines[[4]]
  point4 <- as.data.frame(coordinates(point4))
  point4 <- point4[52,]
  points(point4, add=T, cex=4)
  point5 <- outLines@lines[[5]]
  point5 <- as.data.frame(coordinates(point5))
  point5 <- point5[52,]
  points(point5, add=T, cex=4)
  point6 <- outLines@lines[[6]]
  point6 <- as.data.frame(coordinates(point6))
  point6 <- point6[52,]
  points(point6, add=T, cex=4)
  point7 <- outLines@lines[[7]]
  point7 <- as.data.frame(coordinates(point7))
  point7 <- point7[52,]
  points(point7, add=T, cex=4)
  point8 <- outLines@lines[[8]]
  point8 <- as.data.frame(coordinates(point8))
  point8 <- point8[52,]
  points(point8, add=T, cex=4)
  
  #so take end points of lines adjacent to line_of_predictor for each biplot vector
  point1 <- outLines@lines[[line_of_predictor+1]] #
  point1 <- as.data.frame(coordinates(point1))
  point1 <- point1[52,]
  points(point1, add=T, cex=4, col='red')
  
  if (line_of_predictor == 1) {
    point2 <- outLines@lines[[nrow(lines-1)]]
    point2 <- as.data.frame(coordinates(point2))
    point2 <- point2[52,]
    points(point2, add=T, cex=4, col='red')  }else
    {
      point2 <- outLines@lines[[line_of_predictor-1]]
      point2 <- as.data.frame(coordinates(point2))
      point2 <- point2[52,]
      points(point2, add=T, cex=4, col='red')
    }
  
  origin <- as.data.frame(cbind(0,0)) # origin (0,0)
  
  # make polygon
  poly2_x <- as.numeric(c(origin[1], point1[1], biplot_coords_extend[2,1], point2[1]))
  poly2_y <- as.numeric(c(origin[2], point1[2], biplot_coords_extend[2,2], point2[2]))
  poly2_full <- sp::Polygon(cbind(poly2_x,poly2_y))
  poly2 <- sp::SpatialPolygons(list(sp::Polygons(list(poly2_full), ID='A')))
  plot(poly2, col="steelblue", add=T)
  

  ###### Point in polygon analysis to select inds within each of the polygons
  library(sp)
  
  points <-as.data.frame(ind.overlap)
  coordinates(points) <- ~RDA1+RDA2
  
  ind.overlap_df <- read.csv(paste0(output_path,species_binomial,'_RDA_ind_scores_climate_SNPs.csv'))
  ind.overlap_df$row <- 1:nrow(ind.overlap_df)
  
  # file to append sample names and lat/long
  samples_coords <- read.csv(paste0('./-data-/spatial_data/',species_binomial,'/',species_binomial,'_samples.csv'))
  
  library(sf)
  
  # env1 inds (hot-dry adapted)
  env1_poly <- st_as_sf(poly1) %>% st_set_crs('WGS84')
  points <- st_as_sf(points) %>% st_set_crs('WGS84')
  sf::sf_use_s2(FALSE) # turn off sf geometry checks
  kept_points <- as.data.frame(st_intersects(env1_poly, points))
  # take col.id and use to select subset of ind.overlap_df
  keep <- kept_points$col.id # the inds to keep
  env1 <- ind.overlap_df[ind.overlap_df$row %in% keep, ]
  colnames(env1) <- c('Sample', 'RDA1', 'RDA2','row')
  env1 <- samples_coords%>% right_join(env1, by=c("Sample"))
  env1 <- na.omit(env1)
  write.csv(env1,paste0(output_path,species_binomial,'_categorised_individuals_',params$category_1,'.csv'), row.names=FALSE)
  
  # env2 inds (cold-wet adapted)
  env2_poly <- st_as_sf(poly2) %>% st_set_crs('WGS84')
  points <- st_as_sf(points) %>% st_set_crs('WGS84')
  sf::sf_use_s2(FALSE) # turn off sf geometry checks
  kept_points <- as.data.frame(st_intersects(env2_poly, points))
  # take col.id and use to select subset of ind.overlap_df
  keep <- kept_points$col.id # the inds to keep
  env2 <- ind.overlap_df[ind.overlap_df$row %in% keep, ]
  colnames(env2) <- c('Sample', 'RDA1', 'RDA2','row')
  env2 <- samples_coords%>% right_join(env2, by=c("Sample"))
  env2 <- na.omit(env2)
  write.csv(env2,paste0(output_path,species_binomial,'_categorised_individuals_',params$category_2,'.csv'), row.names=FALSE)
  
  # Intermediate inds (neither hot-dry or cold-wet)
  env1_keep <- read.csv(paste0(output_path,species_binomial,'_categorised_individuals_',params$category_1,'.csv'))
  env2_keep <- read.csv(paste0(output_path,species_binomial,'_categorised_individuals_',params$category_2,'.csv'))
  all <- ind.overlap_df
  colnames(all) <- c('Sample', 'RDA1', 'RDA2', 'row')
  all <- samples_coords%>% right_join(all, by=c("Sample"))
  
  # rows present in above two categories
  rows_to_remove <- c(env1_keep$row, env2_keep$row)
  intermediate <- all[-c(rows_to_remove),]
  write.csv(intermediate,paste0(output_path,species_binomial,'_categorised_individuals_intermediate.csv'), row.names=FALSE)

# Quick check that all categories have data, if not then make a dummy row so the following code doesn't spit out an error
# we make the RDA1 and RDA2 values super high so there is no chance of it appearing on the visualisation plot
if (nrow(env1) =='0'){
  env1[1,] <- '1000';env1$RDA1 <- as.numeric(env1$RDA1);env1$RDA2 <- as.numeric(env1$RDA2)
  }  
if (nrow(env2) =='0'){
  env2[1,] <- '1000';env2$RDA1 <- as.numeric(env2$RDA1);env2$RDA2 <- as.numeric(env2$RDA2)
  }  
if (nrow(intermediate) =='0'){
  intermediate[1,] <- '1000';intermediate$RDA1 <- as.numeric(intermediate$RDA1);intermediate$RDA2 <- as.numeric(intermediate$RDA2)
 }  

  #############
  # Plot the outputs - subsets of each categorisation of individual

  #function for making transparent colours for polygon from Mark Gardener
  ## Transparent colors
  ## Mark Gardener 2015
  ## www.dataanalytics.org.uk
  
  t_col <- function(color, percent = 25, name = NULL) {
    #      color = color name
    #    percent = % transparency
    #       name = an optional name for the color
    
    ## Get RGB values for named color
    rgb.val <- col2rgb(color)
    
    ## Make new color using input color as base and alpha set by transparency
    t.col <- rgb(rgb.val[1], rgb.val[2], rgb.val[3],
                 max = 255,
                 alpha = (100 - percent) * 255 / 100,
                 names = name)
    
    ## Save the color
    invisible(t.col)
  }
  
  tomato <- t_col("tomato", perc = 66, name = "tomato")
  steelblue2 <- t_col("steelblue2", perc = 66, name = "steelblue2")
    
  # just for screen
  coordinates(intermediate) <- ~RDA1+RDA2
  coordinates(env1) <- ~RDA1+RDA2
  coordinates(env2) <- ~RDA1+RDA2
  
  plot(RDA_overlap, type='n', scaling=3)
  points(RDA_overlap, display='sites', pch=21, cex=1.3, col='gray32',scaling=3, bg='gray95') #inds
  plot(env1_poly, col=tomato, add=T)
  plot(env2_poly, col=steelblue2, add=T)
  points(env1, col='gray32', pch=21, bg='red', cex=1.3)
  points(env2, col='gray32', pch=21, bg='steelblue1', cex=1.3)
  points(intermediate, col='gray32', pch=21, bg='grey70', cex=1.3)
  text(RDA_overlap, scaling = 3, labels=c(params$env_predictor_1,params$env_predictor_2), display = 'bp', col='forestgreen', cex=1.1) #biplot
  legend('topright', legend=c(params$category_1,params$category_2,'intermediate'), ncol=1, col=c('red', 'steelblue1', 'gray32'), bg=c('white'), pch = c(19,19,21), cex=1.3)
  
  cat('Writing output plots...\n', file=log_file, append=T)
  
  #write to file
  
  png(filename=paste0(output_path,species_binomial,'_RDA_individual_categorisation.png'), 
      type='cairo', units='cm', width=35, height=35, pointsize=12, res=300)
  par(cex.main=2, cex.axis=1.5, cex.lab=2)
  par(mar=c(5,5,5,5))
  plot(RDA_overlap, type='n', scaling=3)
  points(RDA_overlap, display='sites', pch=21, cex=1.3, col='gray32',scaling=3, bg='gray95') #inds
  plot(env1_poly, col=tomato, add=T)
  plot(env2_poly, col=steelblue2, add=T)
  points(env1, col='gray32', pch=21, bg='red', cex=1.3)
  points(env2, col='gray32', pch=21, bg='steelblue1', cex=1.3)
  #points(intermediate, col='gray32', pch=21, bg='grey70', cex=1.3)
  text(RDA_overlap, scaling = 3, labels=c(params$env_predictor_1,params$env_predictor_2), display = 'bp', col='forestgreen', cex=2) #biplot
  legend('topright', legend=c(params$category_1,params$category_2,'intermediate'), ncol=1, col=c('red', 'steelblue1', 'gray32'), bg=c('white'), pch = c(19,19,21), cex=2)
  dev.off()
  
  cat('> Categorisation of individuals using RDA completed successfully...\n\n', file=file.path(log_file), append=T)
}

#############################################################################################################################################################################################
genomic_offset <- function(species_binomial) {
#############################################################################################################################################################################################

  # Calculates genomic offset across populations using modified RDA code from Capblancq and Forester (2021) # https:/github.com/Capblancq/RDA-landscape-genomics/tree/main
  
# Now the modified code
  library(LEA)
  library(raster)
  library(rgdal)
  
  rm(list=ls(all=TRUE))
  
  root_dir <- ('$YOUR_WORK_DIR')
  setwd(root_dir)
  
  # read args
  args <- commandArgs()
  print(args)
  species_binomial <- args[8]  # This may vary between systems depending on your HPC setup, the list of arguments will be printed at the beginning of your SLURM job logfile so if the jobs fail, make sure that this number matches the number in args[] that matches your species name
  
  # set params file
  params_all <- read.delim('./Params.tsv')
  
  # Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
  params <- params_all[which(params_all$species_binomial==species_binomial),]
  species_binomial <- params$species_binomial
  
  log_file <- paste0('./-outputs-/log_files/',species_binomial,'.log')
  sensitivity_path <- paste0('./-outputs-/',species_binomial,'/Sensitivity/')
  output_path <- paste0(sensitivity_path,'Adaptive_sensitivity/')
  spatial_data_path <- paste0('./-data-/spatial_data/')
  genomic_data_path <- paste0('./-data-/genomic_data/')


# Define the function:
genomic_offset <- function(RDA, K, env_pres, env_fut, range = NULL, method = "loadings", scale_env, center_env){
  
  # Mask with the range if supplied
  if(!is.null(range)){
    env_pres <- mask(env_pres, range)
    env_fut <- mask(env_fut, range)
  }
  
  # Formatting and scaling environmental rasters for projection
  var_env_proj_pres <- as.data.frame(scale(rasterToPoints(env_pres[[row.names(RDA$CCA$biplot)]])[,-c(1,2)], center_env[row.names(RDA$CCA$biplot)], scale_env[row.names(RDA$CCA$biplot)]))
  var_env_proj_fut <- as.data.frame(scale(rasterToPoints(env_fut[[row.names(RDA$CCA$biplot)]])[,-c(1,2)], center_env[row.names(RDA$CCA$biplot)], scale_env[row.names(RDA$CCA$biplot)]))

  # Predicting pixels genetic component based on the loadings of the variables
  if(method == "loadings"){
    # Projection for each RDA axis
    Proj_pres <- list()
    Proj_fut <- list()
    Proj_offset <- list()
    for(i in 1:K){
      # Current climates
      ras_pres <- env_pres[[1]]
      ras_pres[!is.na(ras_pres)] <- as.vector(apply(var_env_proj_pres[,names(RDA$CCA$biplot[,i])], 1, function(x) sum( x * RDA$CCA$biplot[,i])))
      names(ras_pres) <- paste0("RDA_pres_", as.character(i))
      Proj_pres[[i]] <- ras_pres
      names(Proj_pres)[i] <- paste0("RDA", as.character(i))
      # Future climates
      ras_fut <- env_fut[[1]]
      ras_fut[!is.na(ras_fut)] <- as.vector(apply(var_env_proj_fut[,names(RDA$CCA$biplot[,i])], 1, function(x) sum( x * RDA$CCA$biplot[,i])))
      Proj_fut[[i]] <- ras_fut
      names(ras_fut) <- paste0("RDA_fut_", as.character(i))
      names(Proj_fut)[i] <- paste0("RDA", as.character(i))
      # Single axis genetic offset 
      Proj_offset[[i]] <- abs(Proj_pres[[i]] - Proj_fut[[i]])
      names(Proj_offset)[i] <- paste0("RDA", as.character(i))
    }
  }
  
  # Predicting pixels genetic component based on predict.RDA
  if(method == "predict"){ 
    # Prediction with the RDA model and both set of envionments 
    pred_pres <- predict(RDA, var_env_proj_pres[,-c(1,2)], type = "lc")
    pred_fut <- predict(RDA, var_env_proj_fut[,-c(1,2)], type = "lc")
    # List format
    Proj_offset <- list()    
    Proj_pres <- list()
    Proj_fut <- list()
    for(i in 1:K){
      # Current climates
      ras_pres <- rasterFromXYZ(data.frame(var_env_proj_pres[,c(1,2)], Z = as.vector(pred_pres[,i])), crs = crs(env_pres))
      names(ras_pres) <- paste0("RDA_pres_", as.character(i))
      Proj_pres[[i]] <- ras_pres
      names(Proj_pres)[i] <- paste0("RDA", as.character(i))
      # Future climates
      ras_fut <- rasterFromXYZ(data.frame(var_env_proj_pres[,c(1,2)], Z = as.vector(pred_fut[,i])), crs = crs(env_pres))
      names(ras_fut) <- paste0("RDA_fut_", as.character(i))
      Proj_fut[[i]] <- ras_fut
      names(Proj_fut)[i] <- paste0("RDA", as.character(i))
      # Single axis genetic offset 
      Proj_offset[[i]] <- abs(Proj_pres[[i]] - Proj_fut[[i]])
      names(Proj_offset)[i] <- paste0("RDA", as.character(i))
    }
  }
  
  # Weights based on axis eigen values
  weights <- RDA$CCA$eig/sum(RDA$CCA$eig)
  
  # Weighing the current and future adaptive indices based on the eigen values of the associated axes
  Proj_offset_pres <- do.call(cbind, lapply(1:K, function(x) rasterToPoints(Proj_pres[[x]])[,-c(1,2)]))
  Proj_offset_pres <- as.data.frame(do.call(cbind, lapply(1:K, function(x) Proj_offset_pres[,x]*weights[x])))
  Proj_offset_fut <- do.call(cbind, lapply(1:K, function(x) rasterToPoints(Proj_fut[[x]])[,-c(1,2)]))
  Proj_offset_fut <- as.data.frame(do.call(cbind, lapply(1:K, function(x) Proj_offset_fut[,x]*weights[x])))
  
  # Predict a global genetic offset, incorporating the K first axes weighted by their eigen values
  ras <- Proj_offset[[1]]
  ras[!is.na(ras)] <- unlist(lapply(1:nrow(Proj_offset_pres), function(x) dist(rbind(Proj_offset_pres[x,], Proj_offset_fut[x,]), method = "euclidean")))
  names(ras) <- "Global_offset"
  Proj_offset_global <- ras
  
  # Return projections for current and future climates for each RDA axis, prediction of genetic offset for each RDA axis and a global genetic offset 
  return(list(Proj_pres = Proj_pres, Proj_fut = Proj_fut, Proj_offset = Proj_offset, Proj_offset_global = Proj_offset_global, weights = weights[1:K]))
}

# Now running it...
 
  cat('--------------------------------------------------------------\n', file=log_file, append=T)
  cat('Calculating genomic offsets using RDA ...\n', file=file.path(log_file), append=T)
  cat('--------------------------------------------------------------\n', file=log_file, append=T)
  
# Predicting future genomic offset from Capblancq and Forester (2021)
# https:/github.com/Capblancq/RDA-landscape-genomics/tree/main
  
# Once the genetic ~ environment relationship is characterized, it can be extrapolated to future environments to predict 
# a potential shift in adaptive optimum induced by climate change.The RDA-based method to predict this future maladaptation 
# is relatively simple. As done above, RDA can be used to predict the optimal adaptive genetic composition for each environmental
# pixel under consideration (Adaptive Index in Section 5), using both current and future environmental conditions. The difference 
# between the two predictions provides an estimate of the change in genetic composition that would be required to track climate change.  

library(raster)
library(stringr)
library(LEA)
library(vegan)
library(rgdal)

world_shapefile <- readOGR('./-data-/map_data/ne_50m_admin_0_countries.shp')

# First, run the RDA wth the list of adaptive SNPs

#cat('Reading in environmental and genomic data...\n', file=log_file, append=T)

# Subset only the relevant individuals
temp1 <- "sel.ind <- as.character(read.table('"
temp2 <- paste0("./-data-/genomic_data/",species_binomial,"/",species_binomial,".ped'")
temp3 <- ")[,2])"
temp <- paste0(temp1,temp2,temp3)
eval(parse(text=temp))

# read in env data
cat('> Reading in environmental data...\n', file=log_file, append=T)
env <- read.csv(paste0("./-data-/spatial_data/",species_binomial,"/",species_binomial,"_full_env_data.csv"))


cat('> Reading in genomic data...\n', file=log_file, append=T)
temp1 <- "rownames(env) <- as.character(read.table('"
temp2 <- paste0("./-data-/genomic_data/",species_binomial,"/",species_binomial,".ped'")
temp3 <- ")[,2])"
temp <- paste0(temp1,temp2,temp3)
eval(parse(text=temp))

# All loci identified:
temp1 <- "loci.overlap <- as.character(read.table('"
temp2 <- paste0("./-data-/genomic_data/",species_binomial,"/",species_binomial,".map'")
temp3 <- ")[,2])"
temp <- paste0(temp1,temp2,temp3)
eval(parse(text=temp))
loci.overlap_df <- as.data.frame(loci.overlap)
colnames(loci.overlap_df) <- 'Locus'

cat('> Reading in list of adaptive SNPs...\n', file=log_file, append=T)
# read in adaptive SNPs
if (params$use_statistically_validated_snps_only=='yes'){  
  adaptive_loci <- readLines(paste0(output_path,species_binomial,'_adaptive_loci_validated.txt'))  
  adaptive_loci <- str_split(adaptive_loci, pattern= ' ')  
  adaptive_loci <- unlist(adaptive_loci)
  adaptive_loci <- adaptive_loci[1:(length(adaptive_loci)-1)] # to get rid of trailing last blank entry
} else {

adaptive_loci <- readLines(paste0("./-outputs-/",species_binomial,"/Sensitivity/Adaptive_sensitivity/",species_binomial,"_adaptive_loci.txt"))
adaptive_loci <- str_split(adaptive_loci, pattern= ' ')  
adaptive_loci <- unlist(adaptive_loci)
adaptive_loci <- adaptive_loci[1:(length(adaptive_loci)-1)] # to get rid of trailing last blank entry
}
# Subset the imputed data:
imp <- read.geno(paste0("./-data-/genomic_data/",species_binomial,"/",species_binomial,"_imp.geno"))
row.names(imp) <- row.names(env)

temp1 <- "colnames(imp) <- as.character(read.table('"
temp2 <- paste0("./-data-/genomic_data/",species_binomial,"/",species_binomial,".map'")
temp3 <- ")[,2])"
temp <- paste0(temp1,temp2,temp3)
eval(parse(text=temp))

# Check genomic and environmental data match
species.overlap <- imp[sel.ind, adaptive_loci]
identical(rownames(env), rownames(species.overlap))  # same order?

#cat('Performing RDA woth adaptive SNPs...\n', file=log_file, append=T)

# Adaptive RDA
## Standardization of the variables
env <- read.csv(paste0("./-data-/spatial_data/",species_binomial,"/",species_binomial,"_full_env_data.csv"))
env <- env[,5:23] #(just climate)
env <- scale(env, center=TRUE, scale=TRUE) # center=TRUE, scale=TRUE are the defaults for scale()

## Recovering scaling coefficients
scale_env <- attr(env, 'scaled:scale')
center_env <- attr(env, 'scaled:center')

# Climatic table
env <- as.data.frame(env)
row.names(env) <- sel.ind

# run the RDA
RDA_outliers <- rda(species.overlap ~ ., data=env, scale=T)

current_list <- list.files(path=paste0('./-data-/spatial_data/',species_binomial,'/current_climate/'), full.names = TRUE)
future_list <- list.files(path=paste0('./-data-/spatial_data/',species_binomial,'/future_climate/'), full.names = TRUE)
  
env_pres <- stack(current_list)
env_fut <- stack(future_list)


## Running the function for genomic offset prediction
cat('> Calculating genomic offsets...\n', file=log_file, append=T)


#########
#quickly resample - delete this block after revisions
library(geodata)

spatial_dir <- paste0('./-data-/spatial_data/',species_binomial,'/')
presence_data <- read.csv(paste0(spatial_dir,species_binomial,'_presence_data.csv'))
presence_data <- presence_data[,-1] # discard row names
min_lat <- min(presence_data$LAT)
max_lat <- max(presence_data$LAT)
min_long <- min(presence_data$LONG)
max_long <- max(presence_data$LONG)
# add a couple of degrees buffer around points
# if lat/longs are negative the buffer needs to be subtracted..
min_lat <- min_lat-2
max_lat <- max_lat+2
min_long <- min_long-2
max_long <- max_long+2

extent <- c(min_lat,max_lat,min_long,max_long)
extent <- paste0(min_long,',',max_long,',',min_lat,',',max_lat)
template <- eval(parse(text=paste0('extent(',extent,')')))

mask <- raster(paste0(spatial_dir,'current_climate/bioclim_1.tif'))
# resample this down to simplify background point selection
#climate_template <- raster::getData('worldclim', var='tmin', res=2.5)
climate_template <- geodata::worldclim_global('worldclim', var='tmin', res=params$climate_res)
climate_template <- raster(climate_template) #transform back to raster not spatial raster
climate_template.crop <- crop(climate_template, template, snap='out')

env_pres = resample(env_pres,climate_template.crop,method="bilinear")
env_fut = resample(env_fut,climate_template.crop,method="bilinear")
#########

res_RDA_proj_future <- genomic_offset(RDA_outliers, K = params$k, env_pres = env_pres, env_fut = env_fut, range = NULL, method = "loadings", scale_env = scale_env, center_env = center_env)

## crop and write out the raster
samples <- read.csv(paste0(spatial_dir,species_binomial,'_samples.csv'))
coordinates(samples) <- ~ LONG + LAT
# Determine geographic extent of our data
max.lon <- ceiling(max(samples$LONG))
min.lon <- floor(min(samples$LONG))
max.lat <- ceiling(max(samples$LAT))
min.lat <- floor(min(samples$LAT))
geographic.extent <- extent(x = c(min.lon, max.lon, min.lat, max.lat))
CRS <- CRS('+proj=longlat +datum=WGS84') 
sp.crop <- crop(samples, geographic.extent, snap='out')
sp.crop@proj4string <- CRS
buffer_distance_degrees = params$bg_buff_dist_degrees
buffer <- rgeos::gBuffer(sp.crop, width=buffer_distance_degrees)
buffer <- raster::aggregate(buffer) #dissolve
buffer@proj4string <- CRS
cropped_raster <- crop(res_RDA_proj_future$Proj_offset_global,buffer, snap='out')
template <- buffer
mask.crop <- crop(cropped_raster, template, snap='in') 
crop <- setValues(mask.crop, NA) 
template.r <- rasterize(template, crop) 
mask.masked <- mask(x=mask.crop, mask=template.r) 
writeRaster(mask.masked,filename=paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_genomic_offset.asc'), overwrite=TRUE)

## Make table of offsets (extracted per population)
points <- read.csv(paste0("./-data-/spatial_data/",species_binomial,"/",species_binomial,"_full_env_data.csv"))
points <- points[,3:4]

genomic_offset <- raster::extract(res_RDA_proj_future$Proj_offset_global,points)
genomic_offset <- as.data.frame(genomic_offset)
genomic_offset <- cbind(points,genomic_offset)

genomic_offset <- genomic_offset[!duplicated(genomic_offset[c('LONG', 'LAT')]),]
# order it here to match the other outputs (i.e. sorted by order of populations defined in samples file in -data-/spatial_data)
exposure <- read.csv(paste0('-outputs-/',species_binomial,'/Exposure/',species_binomial,'_Exposure.csv'))
genomic_offset <- genomic_offset[order(match(genomic_offset$LAT,exposure$LAT)),]
write.csv(genomic_offset, paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_genomic_offset.csv'), row.names=FALSE)

# plot offsets
coordinates(points) <- ~ LONG + LAT

# defined colours
#offset_colours <- colorRampPalette(c('red','orange','lightyellow','white'))(100)

offset_colours <- colorRampPalette(rev(c('firebrick1','orange3','gold','aquamarine4','steelblue2')),bias=0.7)(1000)

library(terra)
png(paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_genomic_offset_plot.png'), units='cm', height=30, width=30, res=300)
par(cex.main=2, cex.axis=1.5, cex.lab=2)
par(mar=c(5,5,5,5))
par(mfrow=c(1,1))
plot(mask.masked, col=offset_colours, zlim=c(minValue(mask.masked),maxValue(mask.masked)), main='Genomic_offset')
plot(world_shapefile, add=T)
points(points, pch=19, cex = 1.2)
g <- terra::graticule(5, 5, crs="+proj=latlon") # every 5 degreees
plot(g, background=NULL, col="grey65", lty=2, retro=TRUE, add=TRUE)
terra::north()
dev.off()

cat('> DONE ...\n', file=log_file, append=T)
cat('Genomic offset completed successfully...\n\n', file=file.path(log_file), append=T)

}

#############################################################################################################################################################################################
quantify_local_adaptations <- function(species_binomial) {
#############################################################################################################################################################################################

  # Creates tables and maps of individuals that fall in adaptive categories across populations and individuals
  
  library(dplyr)
  library(rgeos)
  library(rgdal)
  
  rm(list=ls(all=TRUE))
  
  root_dir <- ('$YOUR_WORK_DIR')
  setwd(root_dir)
  
  # read args
  args <- commandArgs()
  print(args)
  species_binomial <- args[8]  # This may vary between systems depending on your HPC setup, the list of arguments will be printed at the beginning of your SLURM job logfile so if the jobs fail, make sure that this number matches the number in args[] that matches your species name
  
  # set params file
  params_all <- read.delim('./Params.tsv')
  
  # Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
  params <- params_all[which(params_all$species_binomial==species_binomial),]
  species_binomial <- params$species_binomial
  
  log_file <- paste0('./-outputs-/log_files/',species_binomial,'.log')
  sensitivity_path <- paste0('./-outputs-/',species_binomial,'/Sensitivity/')
  output_path <- paste0(sensitivity_path,'Adaptive_sensitivity/')
  spatial_data_path <- paste0('./-data-/spatial_data/')
 
  cat('--------------------------------------------------------------\n', file=log_file, append=T)
  cat('Quantifying local adaptations ...\n', file=file.path(log_file), append=T)
  cat('--------------------------------------------------------------\n', file=log_file, append=T)

  ###########################################################################
  # Part I - Separation and plotting of individually categorised individuals 
  ###########################################################################
  
  cat('> Reading categorised individuals based on step 9a...\n', file=log_file, append=T)
  
  # Read categorised individual genotypes from last step
  
  # first check all categrised files actually exists (and didn't fail')
if (file.exists(paste0(output_path,species_binomial,'_categorised_individuals_intermediate.csv')) & file.exists(paste0(output_path,species_binomial,'_categorised_individuals_',params$category_1,'.csv')) & file.exists(paste0(output_path,species_binomial,'_categorised_individuals_',params$category_2,'.csv')))  {
  	
  intermediate <- read.csv(paste0(output_path,species_binomial,'_categorised_individuals_intermediate.csv'),row.names=1)
  
  lhs1 <- paste0(params$category_1,sep='')
  rhs1 <- paste0('read.csv("',output_path,species_binomial,'_categorised_individuals_',params$category_1,'.csv", row.names=1)')
  eq1  <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
  eval(parse(text=eq1))

# make dummy data if there are no individuals from that category
 if (nrow(eval(parse(text=params$category_1))) =='0'){
 dummy <- cbind(0,0,0,0,0)
 colnames(dummy) <- c('LONG','LAT','RDA1','RDA2','row')
  lhs2 <- paste0(params$category_1,sep='')
  rhs2 <- paste0('dummy')
  eq2  <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
  eval(parse(text=eq2))
# and make sure it is stored as a dataframe (not a list)
lhs2.1 <- paste0(params$category_1,sep='')
  rhs2.1 <- paste0('as.data.frame(',params$category_1,')')
  eq2.1  <- paste(paste(lhs2.1, rhs2.1, sep=' <- '), collapse='; ')
  eval(parse(text=eq2.1))
}  

  lhs2 <- paste0(params$category_2,sep='')
  rhs2 <- paste0('read.csv("',output_path,species_binomial,'_categorised_individuals_',params$category_2,'.csv", row.names=1)')
  eq2  <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
  eval(parse(text=eq2))

# make dummy data if there are no individuals from that category
 if (nrow(eval(parse(text=params$category_2))) =='0'){
 dummy <- cbind(0,0,0,0,0)
 colnames(dummy) <- c('LONG','LAT','RDA1','RDA2','row')
  lhs2 <- paste0(params$category_2,sep='')
  rhs2 <- paste0('dummy')
  eq2  <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
  eval(parse(text=eq2))
# and make sure it is stored as a dataframe (not a list)
lhs2.1 <- paste0(params$category_2,sep='')
  rhs2.1 <- paste0('as.data.frame(',params$category_2,')')
  eq2.1  <- paste(paste(lhs2.1, rhs2.1, sep=' <- '), collapse='; ')
  eval(parse(text=eq2.1))
}  
  
# add the categorised genotypes
  lhs3 <- paste0(params$category_1,'$Genotype',sep='')
  rhs3 <- paste0('"',params$category_1,'"')
  eq3  <- paste(paste(lhs3, rhs3, sep=' <- '), collapse='; ')
  eval(parse(text=eq3))

  lhs4 <- paste0(params$category_2,'$Genotype',sep='')
  rhs4 <- paste0('"',params$category_2,'"')
  eq4  <- paste(paste(lhs4, rhs4, sep=' <- '), collapse='; ')
  eval(parse(text=eq4))
  
  intermediate$Genotype <- "intermediate"
  
  # read environmental data
  env <- read.csv(paste0(spatial_data_path,species_binomial,'/',species_binomial,'_full_env_data.csv'))
  env <- env[c('Sample', 'LAT', 'LONG', params$env_predictor_1,params$env_predictor_2)]
  
  # Append lats and longs to all genotype data
  lhs5 <- paste0('all_genotypes',sep='')
  rhs5 <- paste0('rbind(',params$category_1,',',params$category_2,',intermediate)')
  eq5  <- paste(paste(lhs5, rhs5, sep=' <- '), collapse='; ')
  eval(parse(text=eq5))
    
  # Clean up any points with NA
  points <- all_genotypes
  points[points == 0] <- NA
  points <- na.omit(points)
  
  points$row <- 1 # to enable counting below
  cat('> Summarising samples at each unique lat/long coords ...\n', file=log_file, append=T)
  	
  # Count number of samples at each long/lat
  library(plyr)
  ind_counts_per_pop <- ddply(points, .(points$LAT, points$LONG), nrow)
  
  # remove any coords of 0,0 (these are the dummy data that were added in case any category had zero individuals)
  ind_counts_per_pop[ind_counts_per_pop == 0] <- NA
  ind_counts_per_pop <- na.omit(ind_counts_per_pop)
  names(ind_counts_per_pop) <- c("LAT", "LONG", "n_samples")
  
  # define xlims and ylims for the plotting - give a 2 degree buffer either side of min/max x and y points in the dataset
  xmin <- min(points$LONG) -2
  xmax <- max(points$LONG) +2 
  ymin <- min(points$LAT) -2
  ymax <- max(points$LAT) +2
  
  cat('> Plotting categorised individuals ...\n', file=log_file, append=T)
  
  # Plot 1 - individuals by category
  # Subset data to only have populations that have >3 samples and add pop_ID
  individuals <- subset(ind_counts_per_pop, ind_counts_per_pop$n_samples>0)
  individuals$POP_ID <- c(1:nrow(individuals))
  
  # then join to the all_genotypes df
  individual_genotypes <- individuals%>% right_join(all_genotypes, by=c("LONG"))
  individual_genotypes <- na.omit(individual_genotypes)
  
  # count genotypes per individual
  genotype_counts_per_pop <- ddply(individual_genotypes, .(individual_genotypes$POP_ID, individual_genotypes$LAT.x, individual_genotypes$LONG, individual_genotypes$Genotype), nrow)
  colnames(genotype_counts_per_pop) <- c("POP_ID", "LAT", "LONG", "Genotype", "Frequency")
  library(reshape2)
  inds <- dcast(genotype_counts_per_pop, POP_ID~Genotype,sum)
 
   # if some columns (e.g. params$category_1 or 2 or intermediate) don's exist, then add them
  add_cols <- function(df, cols) {
    add <- cols[!cols %in% names(df)]
    if(length(add) != 0) df[add] <- NA
    return(df)
  }
  
  inds <- add_cols(inds, eval(parse(text=paste0("c('",params$category_1,"','",params$category_2, "','intermediate')"))))
  inds[is.na(inds)] <- 0
  
  # order the categories by the order specified in the category_1 and category_2 variables (otherwise it will alphabetise them by default)
 # this is done in an if else statement so that if any of the categories are not there the column order will be modified accordingly
   if (eval(parse(text=(paste0('nrow(',params$category_1,') <=0')))) & (eval(parse(text=(paste0('nrow(',params$category_2,') <=0')))))) {
   col_order <- c("POP_ID", "intermediate") } else {
    if (eval(parse(text=(paste0('nrow(',params$category_1,') <=0')))) & (eval(parse(text=(paste0('nrow(intermediate) <=0')))))) {
    col_order <- c("POP_ID", params$category_2) } else {
     if (eval(parse(text=(paste0('nrow(',params$category_2,') <=0')))) & (eval(parse(text=(paste0('nrow(intermediate) <=0')))))) {
     col_order <- c("POP_ID", params$category_1) } else {
      if (eval(parse(text=(paste0('nrow(',params$category_1,') <=0'))))) {
      col_order <- c("POP_ID", params$category_2, "intermediate") } else {
       if (eval(parse(text=(paste0('nrow(',params$category_2,') <=0'))))) {
       col_order <- c("POP_ID", params$category_1, "intermediate") } else {
        if (nrow(intermediate) <1) {
        col_order <- c("POP_ID", params$category_1, params$category_2) } else {
        
        # if none missing
        col_order <- c("POP_ID", params$category_1, params$category_2, "intermediate")
}
}
}
}
}
}

inds <- inds[, col_order]
inds <- individuals%>% right_join(inds, by=c("POP_ID"))
  
 # nameZs needs only the categories present in the dataframe, so if there is something missing it will mess up
 # best way to deal with this is to grab the unique columns in the dataframe and use that
 expected_nameZs <- eval(parse(text=(paste0("c('",params$category_1,"',","'",params$category_2,"',","'intermediate')")))) # based on params file
 actual_nameZs <- colnames(inds)
 nameZs <- intersect(expected_nameZs, actual_nameZs)
 
 # also the colours will be messed up if some category is missing, so best to define them and then use them
 # note the categories will automatically be alphabetically sorted later so colours need to be correct
 expected_nameZs_colours <- c("steelblue1","tomato","grey70") # cold_wet, hot_dry, intermediate in this case
 nameZs_colours <- as.data.frame(rbind(expected_nameZs,expected_nameZs_colours))
 nameZs_colours <- t(nameZs_colours)
 nameZs_colours <- as.data.frame(nameZs_colours)
 subset <- nameZs_colours[nameZs_colours$expected_nameZs %in% actual_nameZs,]
 nameZs_colours <- subset[,2]
  
  cat('> DONE ...\n', file=log_file, append=T)
  
  cat('> Plotting categorised populations ... (all unique lat/long coords with > 1 sample)...\n', file=log_file, append=T)
  
  # Plot 2 - populations by category
  # Subset data to only have populations that have >1 samples and add pop_ID
  populations <- subset(ind_counts_per_pop, ind_counts_per_pop$n_samples>1) # changed..
  populations$POP_ID <- c(1:nrow(populations))
  
  # then join to the all_genotypes df
  population_genotypes <- populations%>% right_join(all_genotypes, by=c("LONG"))
  population_genotypes <- na.omit(population_genotypes)
  # delete dup LAT.y column
  population_genotypes <- population_genotypes[ , -which(names(population_genotypes) %in% c("LAT.y"))]
  
  # count genotypes per population
  genotype_counts_per_pop <- ddply(population_genotypes, .(population_genotypes$POP_ID, population_genotypes$LAT.x, population_genotypes$LONG, population_genotypes$Genotype), nrow)
  colnames(genotype_counts_per_pop) <- c("POP_ID", "LAT", "LONG", "Genotype", "Frequency")
  library(reshape2)
  pops <- dcast(genotype_counts_per_pop, POP_ID~Genotype,sum)
      
  # order the categories by the order specified in the category_1 and category_2 variables (otherwise it will alphabetise them by default)
 # this is done in an if else statement so that if any of the categories are not there the column order will be modified accordingly
   if (eval(parse(text=(paste0('nrow(',params$category_1,') <=1')))) &(eval(parse(text=(paste0('nrow(',params$category_2,') <=1')))))) {
   col_order <- c("POP_ID", "intermediate") } else {
    if (eval(parse(text=(paste0('nrow(',params$category_1,') <=1')))) & (eval(parse(text=(paste0('nrow(intermediate) <=1')))))) {
    col_order <- c("POP_ID", params$category_2) } else {
     if (eval(parse(text=(paste0('nrow(',params$category_2,') <=1')))) & (eval(parse(text=(paste0('nrow(intermediate) <=1')))))) {
     col_order <- c("POP_ID", params$category_1) } else {
      if (eval(parse(text=(paste0('nrow(',params$category_1,') <=1'))))) {
      col_order <- c("POP_ID", params$category_2, "intermediate") } else {
       if (eval(parse(text=(paste0('nrow(',params$category_2,') <=1'))))) {
       col_order <- c("POP_ID", params$category_1, "intermediate") } else {
        if (nrow(intermediate) <1) {
        col_order <- c("POP_ID", params$category_1, params$category_2) } else {
       
       # if none missing
        col_order <- c("POP_ID", params$category_1, params$category_2, "intermediate")
}
}
}
}
}
}

  
  # if some columns (e.g. params$category_1 or 2 or intermediate) don's exist, then add them
  add_cols <- function(df, cols) {
    add <- cols[!cols %in% names(df)]
    if(length(add) != 0) df[add] <- NA
    return(df)
  }
  
  pops <- add_cols(pops, eval(parse(text=paste0("c('",params$category_1,"','",params$category_2, "','intermediate')"))))
  pops[is.na(pops)] <- 0
  
pops <- pops[, col_order]
pops <- populations%>% right_join(pops, by=c("POP_ID"))


cat('> Plotting individual categorisation maps...\n', file=file.path(log_file), append=T)

##### 
library(mapplots)
library(shapefiles)
library(raster)
library(terra)
library(stringr)

# read in country borders and SDM output as a template
world_shapefile <- readOGR(paste0(root_dir,'./-data-/map_data/ne_50m_admin_0_countries.shp'))
mask <- raster(paste0(root_dir,'-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_genomic_offset.asc'))
world_shapefile <- crop(world_shapefile,mask)
    xmin <- mask@extent@xmin
    xmax <- mask@extent@xmax
    ymin <- mask@extent@ymin
    ymax <- mask@extent@ymax

# read in shapefile to mapplots using shapefiles library
shapefile <- file.path(paste0(root_dir,'./-data-/map_data/ne_50m_admin_0_countries'))
shapefile <- read.shapefile(shapefile)

# read in the adaptively categorised individuals
pies1 <- read.csv(paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_categorised_individuals_',nameZs[1],'.csv'))
pies2 <- read.csv(paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_categorised_individuals_',nameZs[2],'.csv'))
pies3 <- read.csv(paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_categorised_individuals_',nameZs[3],'.csv'))

# Again make dummy data if there are no individuals from that category
 if (nrow(pies1)=='0'){
 dummy <- cbind(0,0,0,0,0,0)
 colnames(dummy) <- c('Sample','LONG','LAT','RDA1','RDA2','row')
  lhs2 <- paste0(params$category_1,sep='')
  rhs2 <- paste0('dummy')
  eq2  <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
  eval(parse(text=eq2))
# and make sure it is stored as a dataframe (not a list)
lhs2.1 <- paste0(params$category_1,sep='')
  rhs2.1 <- paste0('as.data.frame(',params$category_1,')')
  eq2.1  <- paste(paste(lhs2.1, rhs2.1, sep=' <- '), collapse='; ')
  eval(parse(text=eq2.1))
pies1 <- as.data.frame(dummy)
}  
 if (nrow(pies2)=='0'){
 dummy <- cbind(0,0,0,0,0,0)
 colnames(dummy) <- c('Sample','LONG','LAT','RDA1','RDA2','row')
  lhs2 <- paste0(params$category_2,sep='')
  rhs2 <- paste0('dummy')
  eq2  <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
  eval(parse(text=eq2))
# and make sure it is stored as a dataframe (not a list)
lhs2.1 <- paste0(params$category_2,sep='')
  rhs2.1 <- paste0('as.data.frame(',params$category_2,')')
  eq2.1  <- paste(paste(lhs2.1, rhs2.1, sep=' <- '), collapse='; ')
  eval(parse(text=eq2.1))
pies2 <- as.data.frame(dummy)
}  


pies1$category <- nameZs[1]
pies2$category <- nameZs[2]
pies3$category <- nameZs[3]
pies <- rbind(pies1,pies2,pies3)
pies$category <- as.factor(pies$category)
pies$count <- 1
xyz_inds <- make.xyz(pies$LON,pies$LAT,pies$count, pies$category)
# xyz_inds will be in alphabetical order, so colours need to be assigned correctly

#figure out where the legend should be drawn
xlim <- c(xmin,xmax)
ylim <- c(ymin,ymax)

x_range <- xmax-xmin #get ranges of extent for x
y_range <- ymax-ymin #get ranges of extent for x
x_range <- abs(x_range) #make positive even if lat/longs are negative
y_range <- abs(x_range) #make positive even if lat/longs are negative

x <- xmax-((x_range/100)*15)
y <- ymin+((y_range/100)*15)

# draw panel 1 - map all individuals and local adaptations
png(filename=paste0(output_path,species_binomial,'_adaptive_categorisation_maps.png'), type='cairo', units='cm', width=30, height=30, pointsize=12, res=300)
par(mfrow=c(1,2))
basemap(xlim, ylim, main = "Local adaptations of all populations")
draw.shape(shapefile, col="cornsilk")
col <- expected_nameZs_colours
draw.pie(xyz_inds$x, xyz_inds$y, xyz_inds$z, radius = 0.4, col=col)
legend.pie(x,y,labels=c("cold_wet","hot_dry","intermediate"), inset=0.1, radius=0.75, bty="o", bg="white", col=col, cex=0.8, label.dist=1.5)
#legend.z <- round(max(rowSums(xyz_pops$z,na.rm=TRUE))/10^6,0)
#legend.bubble("topright",z=legend.z,round=1,maxradius=0.4,bty="n",txt.cex=0.6)
 abline(h=c(-180,-175,-170,-165,-160,-155,-150,-145,-140,-135,-130,-125,-120,-115,-110,-105,-100,-95,-90,-85,-80,-75,-70,-65,-60,-55,-50,-45,-40,-35,-30,-25,-20,-15,-10,-5,0,5,10,15,20,25,30,35,40,45,50,55,60,65,70,75,80,85,90,95,100,105,110,115,120,125,130,135,140,145,150,155,160,165,170,175,180), lty=3, lwd=1, col='grey65')
abline(v=c(-180,-175,-170,-165,-160,-155,-150,-145,-140,-135,-130,-125,-120,-115,-110,-105,-100,-95,-90,-85,-80,-75,-70,-65,-60,-55,-50,-45,-40,-35,-30,-25,-20,-15,-10,-5,0,5,10,15,20,25,30,35,40,45,50,55,60,65,70,75,80,85,90,95,100,105,110,115,120,125,130,135,140,145,150,155,160,165,170,175,180), lty=3, lwd=1, col='grey65')

# subset the populations with >1 sample
xyz_pops <- as.data.frame(xyz_inds$z)
xyz_pops$n <- xyz_pops[,1] + xyz_pops[,2] + xyz_pops[,3]
xyz_pops <- xyz_pops[xyz_pops$n>1,]
library(stringr)
LONG_LAT <- row.names(xyz_pops)
LONG <- str_split_fixed(LONG_LAT, ",", 2)[, 1] #extract the first column of str_split_fixed and put it back in the df as a new column
LAT <- str_split_fixed(LONG_LAT, ",", 2)[, 2] #extract the second column of str_split_fixed and put it back in the df as a new column
LAT <- gsub(' ', '', LAT) #remove blank spaces after commas
xyz_pops$LONG <- LONG  #append back to dataframe
xyz_pops$LAT <- LAT #append back to dataframe

#keep only 'pies' populations that are matching xyz_pops (i.e. those with >1 individual)
pies_pops <- subset(pies, LONG %in% xyz_pops$LONG)
xyz_pops <- make.xyz(pies_pops$LON,pies_pops$LAT,pies_pops$count, pies_pops$category)

# draw panel 2 - map all pops with >1 individuals and local adaptations
basemap(xlim, ylim, main = "Local adaptations of all populations with >1 individual")
draw.shape(shapefile, col="cornsilk")
col <- expected_nameZs_colours
draw.pie(xyz_pops$x, xyz_pops$y, xyz_pops$z, radius = 0.4, col=col)
legend.pie(x,y,labels=c("cold_wet","hot_dry","intermediate"), inset=0.1, radius=0.75, bty="o", bg="white", col=col, cex=0.8, label.dist=1.5)
legend.z <- round(max(rowSums(xyz_pops$z,na.rm=TRUE))/10^6,0)
#legend.bubble("topright",z=legend.z,round=1,maxradius=0.4,bty="n",txt.cex=0.4)
abline(h=c(-180,-175,-170,-165,-160,-155,-150,-145,-140,-135,-130,-125,-120,-115,-110,-105,-100,-95,-90,-85,-80,-75,-70,-65,-60,-55,-50,-45,-40,-35,-30,-25,-20,-15,-10,-5,0,5,10,15,20,25,30,35,40,45,50,55,60,65,70,75,80,85,90,95,100,105,110,115,120,125,130,135,140,145,150,155,160,165,170,175,180), lty=3, lwd=1, col='grey65')
abline(v=c(-180,-175,-170,-165,-160,-155,-150,-145,-140,-135,-130,-125,-120,-115,-110,-105,-100,-95,-90,-85,-80,-75,-70,-65,-60,-55,-50,-45,-40,-35,-30,-25,-20,-15,-10,-5,0,5,10,15,20,25,30,35,40,45,50,55,60,65,70,75,80,85,90,95,100,105,110,115,120,125,130,135,140,145,150,155,160,165,170,175,180), lty=3, lwd=1, col='grey65')
dev.off()

cat('> DONE ...\n', file=log_file, append=T)

  # write files
  write.csv(inds,paste0(output_path,species_binomial,'_adaptive_categorisation_individuals.csv'), row.names = FALSE)
  write.csv(pops,paste0(output_path,species_binomial,'_adaptive_categorisation_populations.csv'), row.names = FALSE)
  
  cat('> Output plots and data written...\n\n', file=log_file, append=T)
  cat('> Local adaptation analyses completed successfully...\n\n', file=log_file, append=T)
    } else {
  cat('> Unable to assess local adaptations, files do not exist! Check the outputs of the individual categorisation step ...\n', file=file.path(log_file), append=T)
  	}
  	
}

#############################################################################################################################################################################################
neutral_sensitivity <- function(species_binomial) {
#############################################################################################################################################################################################
  
  # Calculate neutral genetic diversity using PLINK (masking out the adaptive SNPs)

  library(tibble)
  library(stringr)
  
  rm(list=ls(all=TRUE))
  
  root_dir <- ('$YOUR_WORK_DIR')
  setwd(root_dir)
   
  spatial_data_path <- './-data-/spatial_data/'
  
  # read args
  args <- commandArgs()
  print(args)
  species_binomial <- args[8]  # This may vary between systems depending on your HPC setup, the list of arguments will be printed at the beginning of your SLURM job logfile so if the jobs fail, make sure that this number matches the number in args[] that matches your species name
  
  # set params file
  params_all <- read.delim('./Params.tsv')
  
  # Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
  params <- params_all[which(params_all$species_binomial==species_binomial),]
  species_binomial <- params$species_binomial
  
  log_file <- paste0('./-outputs-/log_files/',species_binomial,'.log')
  sensitivity_path <- paste0('./-outputs-/',species_binomial,'/Sensitivity/')
  output_path <- paste0(sensitivity_path,'Neutral_sensitivity/')
  dir.create(paste0(output_path))
  

  cat('--------------------------------------------------------------\n', file=log_file, append=T)
  cat('Quantifying neutral sensitivity ...\n', file=file.path(log_file), append=T)
  cat('--------------------------------------------------------------\n', file=log_file, append=T)
  
  # #make output plink directory 
  # dir.create(paste0('./-outputs-/',species_binomial,'/plink/'), showWarnings = FALSE)
  
  ##### 1. Plink to calculate genetic diversity (heterozygosity)
  cat('> Calculating observed heterozygosity and nucleotide diversity per population...\n', file=log_file, append=T)
  
  ### A. 'Naive' Heterozygosity
  
  plink_executable <- params$plink_executable
  system(paste0(plink_executable))
  
  #calculate GD (naive, using all SNPs, both neutral and adaptive)
  plink_input <- paste0('./-data-/genomic_data/',species_binomial,'/',species_binomial)
  plink_output <- paste0(output_path,species_binomial)
  dir.create(paste0(output_path))
  system(paste0(plink_executable,' --het --file ', plink_input, ' --out ', plink_output,' --allow-extra-chr'))
  
  cat('> Heterozygosity (observed) calculated using all SNPs...\n', file=log_file, append=T)
  cat('> Now masking out adaptive regions and recalculating heterozygosity based on neutral SNPs only...\n', file=log_file, append=T)
  
  ### B. 'Neutral' Heterozygosity
  # to calculate neutral genetic diversity we need to change the chromosome coding at specific loci and then use a chr mask...
  # adaptive list needs to use the one separated by spaces (written after step 9a)
 
  map_file <- read.table(paste0('./-data-/genomic_data/',species_binomial,'/',species_binomial,'.map'))

if (params$which_loci==0){
    adaptive_list <- read.delim(paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_adaptive_loci_validated.txt'), header=F, sep =' ')
    adaptive_list <- adaptive_list[1:(length(adaptive_list)-1)] # to get rid of trailing last blank entry
    adaptive_list <- t(adaptive_list)
    adaptive_list <- as.data.frame(adaptive_list)
}else{
  adaptive_list <- read.delim(paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_adaptive_loci.txt'), header=F, sep =' ')
  adaptive_list <- t(adaptive_list)
  adaptive_list <- as.data.frame(adaptive_list)
}

  # for adaptive loci grab the line, replace chromosome values 'un' with '2' 
  library(dplyr)
  tmp1 <- subset(map_file, V2 %in% adaptive_list$V1)
  tmp1$V1 <- '2'
  
  # bind the file to the original map file then check for duplicates (i.e. deleting the originals with 'un')
  tmp2 <- rbind(tmp1,map_file)
  tmp3 <- tmp2 %>% filter(duplicated(V2) == FALSE)
  
  #replace all 'un' with '1' and save the relevant columns (so n loci remain the same)
  tmp4 <- as.data.frame(replace(tmp3$V1, tmp3$V1=='un', '1'))
  tmp4[tmp4==2] <- 1
  
  
  neutral_masked_map <- cbind(tmp4, tmp3$V2, tmp3$V3, tmp3$V4)
  colnames(neutral_masked_map) <- c('V1','V2','V3','V4')
  write.table(neutral_masked_map, paste0(plink_output,'_neutral.map'), sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
  
  # Now recalculate GD (neutral only) by masking out adaptive GD (we have changed all chrs to 1 except the adaptive ones, which are 2)
  # first make copy of the original plink .ped file but append '_neutral'
  file.copy(paste0(plink_input,'.ped'), paste0(plink_output, '_neutral.ped'))
  plink_neutral_input <- paste0(output_path,species_binomial,'_neutral')
  plink_neutral_output <-  paste0(plink_output,'_neutral')
  system(paste0(plink_executable,' --het --file ', plink_neutral_input, ' --out ', plink_neutral_output,' --chr 1'))
  
  cat('> Heterozygosity calculated...\n', file=log_file, append=T)
  
  ### C. manipulate and save outputs so they are non-text and readable by R
  # We do some manipulation of the files so that they are in readable format
  neutral_het <- read.delim(paste0(plink_neutral_output,'.het'))
  neutral_het <- toString(neutral_het)
  neutral_het <- str_squish(neutral_het)                      # remove spaces
  neutral_het <- str_replace_all(neutral_het, '"', '')        # remove quotes
  neutral_het <- str_replace_all(neutral_het, ',', '\n')      # reinsert line breaks
  neutral_het <- str_replace_all(neutral_het, "^ ", '')       # remove leading " "
  neutral_het <- str_replace_all(neutral_het, "^c..", '')    # remove leading "c(  "
  neutral_het <- str_replace_all(neutral_het, ' ', ',')       # remove spaces, change to commas
  neutral_het <- str_replace_all(neutral_het, ',,', '')       # remove double commas
  neutral_het <- str_replace_all(neutral_het, '\\)$', '')     # remove closing bracket
  write.table(neutral_het,paste0(plink_neutral_output,'.het.csv'), sep=',', quote=FALSE, col.names = FALSE, row.names=FALSE) # write out
  
  naive_het <- read.delim(paste0(plink_output,'.het'))
  naive_het <- toString(naive_het)
  naive_het <- str_squish(naive_het)                      # remove spaces
  naive_het <- str_replace_all(naive_het, '"', '')        # rempve quotes
  naive_het <- str_replace_all(naive_het, ',', '\n')      # reinsert line breaks
  naive_het <- str_replace_all(naive_het, "^c..", '')    # remove leading "c(  "
  naive_het <- str_replace_all(naive_het, "^ ", '')       # remove leading " "
  naive_het <- str_replace_all(naive_het, ' ', ',')       # remove spaces, change to commas
  naive_het <- str_replace_all(naive_het, ',,', '')       # remove double commas
  naive_het <- str_replace_all(naive_het, '\\)$', '')     # remove closing bracket
  write.table(naive_het,paste0(plink_output,'.het.csv'), sep=',', quote=FALSE, col.names = FALSE, row.names=FALSE) # write out
  
  #D. Summarise the neutral heterozgosity across populations (i.e. unique geographic coordinates)
  # read in those plink summary csv files and the map file for the species
  neutral_het <- read.table(paste0(plink_neutral_output,'.het.csv'), sep =',')
  colnames(neutral_het) <- c('FID ','Sample','O_HOM','E_HOM','N_NM','F') # reinsert the plink output column names
  
  naive_het <- read.table(paste0(plink_output,'.het.csv'), sep =',')
  colnames(naive_het) <- c('FID ','Sample','O_HOM','E_HOM','N_NM','F') # reinsert the plink output column names
  
  # read in the map file
  map_file <- read.delim(paste0(plink_neutral_input,'.map'), header=FALSE)
  
  # Append lats and longs to the data (sample, lat, long)
  # env <- read.csv(paste0('-data-/env_data/',species_binomial,'/',species_binomial,'_env_data.csv'))
  # env <- env[,c(1,3,4)]
  
  env <- read.csv(paste0(spatial_data_path,species_binomial,'/',species_binomial,'_full_env_data.csv'))
  #pop_assignment <- read.csv(paste0('./-outputs-/',species_binomial,'/Sensitivity/',species_binomial,'_pop_assignment_LEA.csv'))
  #env <- as.data.frame(cbind(env$Sample,pop_assignment$pop,env$bioclim_5,env$bioclim_18))
  lhs1 <- paste0('env',sep='')
  rhs1 <- paste0('as.data.frame(cbind(env$Sample, env$LAT, env$LONG))')
  eq1  <- paste0(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
  eval(parse(text=eq1))
  colnames(env) <- c('Sample','LAT','LONG')
  
  neutral_het <- env%>% right_join(neutral_het, by=c("Sample"))
  
  #count total and neutral loci 
  neutral_loci <- map_file[map_file$V1 == '1',]
  adaptive_loci <- map_file[map_file$V1 == '2',]
  
  number_total_loci <- nrow(map_file)
  number_neutral_loci <- nrow(neutral_loci)
  number_adaptive_loci <- nrow(adaptive_loci)
  
  neutral_het$Observed_hom <- (neutral_het$O_HOM/number_neutral_loci)
  neutral_het$Observed_het <- 1-(neutral_het$Observed_hom)
  neutral_het$Expected_hom <- (neutral_het$E_HOM/number_neutral_loci)
  neutral_het$Expected_het <- 1-(neutral_het$Expected_hom)
  
  # Clean up any records with NA
  neutral_het <- na.omit(neutral_het)
  
  cat('> Summarising heterozygosity across populations...\n', file=log_file, append=T)
  # Get a list of samples at each long/lat then use that to summarise heterozygosity...
  # First make pop_i dataset of each sample (i.e. every unique location contains the data for each individual)
  long_list <- unique(neutral_het$LONG)
  lat_list <- unique(neutral_het$LAT)
  
  n    <- length(long_list)
  for(i in long_list){
    cat("\n",i,"... read!")
    lhs <- paste0('pop_', 1:n)
    rhs <- paste0('neutral_het[neutral_het$LONG %in% ', long_list[1:n], ', ]')
    eq <- paste(paste(lhs, rhs, sep=' <- '), collapse='; ')
    eval(parse(text=eq))
  } 
  
  # get the mean_population F (from the F column output by plink)
  lhs <- paste0('pop_', 1:n, '_mean_population_F')
  rhs <- paste0("mean(pop_", 1:n, "$F)")
  eq <- paste(paste(lhs, rhs, sep=' <- '), collapse='; ')
  eval(parse(text=eq))
  
  # get list of these mean population F values across all populations
  lhs <- paste0('pop_', 1:n, '_mean_population_F')
  eq <- paste(paste(lhs, sep=','), collapse=', ')
  
  # rbind them all to a dataframe
  lhs <- paste0('mean_population_F')
  rhs <- paste0('rbind(', eq,')')
  eq <- paste(paste(lhs, rhs, sep=' <- '), collapse=' ')
  eval(parse(text=eq))
    
  cat('> Creating neutral sensitivity metrics per population...\n', file=log_file, append=T)
  
  # make a metric to measure 'neutral sensitivity'
  # first calculate the heterozygosity per pop as in Razgour et al. 2017
  neutral_heterozygosity <- (1-mean_population_F)
  
  # make dataframe of coordinates, individual sample numbers and neutral heterozygosity
  df <- cbind(lat_list, long_list, neutral_heterozygosity)
  
  # get the quantiles of the data
  q1 <- as.numeric(quantile(neutral_heterozygosity, probs=0.1))
  q2 <- as.numeric(quantile(neutral_heterozygosity, probs=0.2))
  q3 <- as.numeric(quantile(neutral_heterozygosity, probs=0.3))
  q4 <- as.numeric(quantile(neutral_heterozygosity, probs=0.4))
  q5 <- as.numeric(quantile(neutral_heterozygosity, probs=0.5))
  q6 <- as.numeric(quantile(neutral_heterozygosity, probs=0.6))
  q7 <- as.numeric(quantile(neutral_heterozygosity, probs=0.7))
  q8 <- as.numeric(quantile(neutral_heterozygosity, probs=0.8))
  q9 <- as.numeric(quantile(neutral_heterozygosity, probs=0.9))
 
# get the intervals based on the range of the data
  lhs3.9.1 <- paste0('min', sep='')
  rhs3.9.1 <- paste0('min(neutral_heterozygosity)')
  eq3.9.1  <- paste(paste(lhs3.9.1, rhs3.9.1, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.9.1))
  lhs3.9.1 <- paste0('max', sep='')
  rhs3.9.1 <- paste0('max(neutral_heterozygosity)')
  eq3.9.1  <- paste(paste(lhs3.9.1, rhs3.9.1, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.9.1))
  range <- max-min
  increments <- range/10
  i10 <- min
  i9 <- min+increments
  i8 <- i9+increments
  i7 <- i8+increments
  i6 <- i7+increments
  i5 <- i6+increments
  i4 <- i5+increments
  i3 <- i4+increments
  i2 <- i3+increments
  i1 <- i2+increments

  # use defined thresholds from params file
  thresholds <- params$neutral_sensitivity_heterozygosity_thresholds
  thresholds <- as.data.frame(unlist(strsplit(thresholds,",")))
  thresholds$number <- c(1:10)
  colnames(thresholds) <- c('value','number')

 # generate the scores based on the option selected - 'defined', 'interval', or 'quantile'
if (params$neutral_sensitivity_quantification=='defined'){
#defined
  neutral_sensitivity <- as.data.frame(findInterval(neutral_heterozygosity,c(as.numeric(thresholds$value))))
  neutral_sensitivity <- 10-neutral_sensitivity }else{
 if (params$neutral_sensitivity_quantification=='interval'){ 
# interval
    neutral_sensitivity <- as.data.frame(findInterval(neutral_heterozygosity,(c(i10,i9,i8,i7,i6,i5,i4,i3,i2,i1))))
	neutral_sensitivity <- 11-neutral_sensitivity }else{
	if (params$neutral_sensitivity_quantification=='quantile'){ 
# quantile
  		neutral_sensitivity <- as.data.frame(findInterval(neutral_heterozygosity,(c(q1,q2,q3,q4,q5,q6,q7,q8,q9))))
  		neutral_sensitivity <- 10-neutral_sensitivity
  }
}
}
   
  # bind final file and write out
  neutral_heterozygosity_summary <- cbind(df, neutral_sensitivity)
  colnames(neutral_heterozygosity_summary) <- c('LAT','LONG','Neutral_heterozygosity', 'Neutral_sensitivity')
  write.csv(neutral_heterozygosity_summary,paste0(output_path,species_binomial,"_neutral_sensitivity.csv"), row.names=FALSE)

  cat('> DONE!\n\n', file=log_file, append=T)
  
  cat('> Now calculating nucleotide diversity based on neutral SNPs only...\n', file=log_file, append=T)

# We are also calculating nucleotide diversity, which is the better metric to use (but is not suitable for any population with <2 individuals)
library(pegas)
library(stringr)

# read the neutral ped
data <- read.delim(paste0('./-outputs-/',species_binomial,'/Sensitivity/Neutral_sensitivity/',species_binomial,'_neutral.ped'), header=FALSE)
# chop off unnecessary columns so it's just the sample names, pops and seqs
data <- data[,2:ncol(data)]
data <- data[-c(2:5)]
colnames(data) <- 1:ncol(data)
sample_names <- data[,1]
sample_genotypes <- data[,2:ncol(data)]
sample_genotypes[sample_genotypes==0] <- c('N')
sample_genotypes[sample_genotypes=='TRUE'] <- c('N')

# do in for loop for each individual
for (i in 1:nrow(data)){
  sample_genotypes_string <- eval(parse(text=(paste0('toString(sample_genotypes[',i,',])'))))
  sample_genotypes_string <- as.character(sample_genotypes_string)
  sample_genotypes_string <- gsub(' ','',sample_genotypes_string) #remove " "
  sample_genotypes_string <- gsub(',','',sample_genotypes_string) #remove ","
  #row <- paste0('> ',eval(parse(text=paste0('sample_names[',i,']'))))
  row <- paste0('',eval(parse(text=paste0('sample_names[',i,']'))))
  row_seq <- paste0(sample_genotypes_string)
  row_seq <- paste0('\n',row_seq,'\n')
  sample <- gsub('> ','Sample_',row)

  sample <- gsub('-','_',row) # added to deal with '-' in sample names
  
  row <- paste0(row,row_seq,'\n')
  lhs <- sample
  rhs <- paste0("paste(row)")
  eq <- paste(lhs, rhs, sep=' <- ', collapse='; ')
  eval(parse(text=eq))
}

# grab lists of samples per unique population from exposure outputs
samples <- read.csv(paste0('./-data-/spatial_data/',species_binomial,'/',species_binomial,'_samples.csv'))
exposure <- read.csv(paste0('./-outputs-/',species_binomial,'/Exposure/',species_binomial,'_Exposure.csv'))
unique <- as.data.frame(cbind(unique(samples$LAT),unique(samples$LONG)))
colnames(unique) <- c('LAT','LONG')

# iterate over each unique geographic location to get a list of the samples within it (i.e. a population) 
for (i in 1:nrow(unique)) {
  x <- which(samples$LONG==unique$LONG[i])
  #sample_names_pops <- samples[x,]; sample_names_pops <- sample_names_pops$Sample
  lhs1 <- paste0('sample_names_pop_',i)
  rhs1 <- paste0('samples[x,]; sample_names_pops <- sample_names_pop_',i,'$Sample')
  eq1 <- paste(lhs1, rhs1, sep=' <- ', collapse='; ')
  eval(parse(text=eq1))
  lhs2 <- paste0('sample_names_pop_',i)
  rhs2 <- paste0('sample_names_pop_',i,'$Sample')
  eq2 <- paste(lhs2, rhs2, sep=' <- ', collapse='; ')
  eval(parse(text=eq2))
}

# then bind inds to make pop fastas
dir.create(paste0('./-outputs-/',species_binomial,'/Sensitivity/Neutral_sensitivity/fastas/'))
for (i in 1:nrow(unique)) {
  pattern_to_search <- paste0('sample_names_pop_',i)
  # for all populations with >1 individual
  for (j in 1:length(eval(parse(text=pattern_to_search)))){
    lhs3 <- paste0('test_pop_',i,'_ind_',j)
    #rhs3 <- paste0('mget(ls(pattern = paste0("Sample_",eval(parse(text=pattern_to_search))[',j,'])))')
    rhs3 <- paste0('mget(ls(pattern = paste0(eval(parse(text=pattern_to_search))[',j,'])))')
    eq3 <- paste(lhs3, rhs3, sep=' <- ', collapse='; ')
    eval(parse(text=eq3))
    test <- mget(ls(pattern = paste0('test_pop_',i,'_ind_')))
    #test <- mget(ls(pattern = paste0("Sample_",eval(parse(text=pattern_to_search))[j])))
    	for (k in 1:length(test)){
      	xyz <- eval(parse(text=paste0(names(test[k]))))
      	names <- names(xyz)
      	lhs4 <- paste0('crumble_',k)
      	rhs4 <- paste0('xyz$',names)
      	eq4 <- paste(lhs4, rhs4, sep=' <- ', collapse='; ')
      	eval(parse(text=eq4))
      	# need to extract the actual information from the list, without the extra stuff - like this
      	all_inds <- mget(ls(pattern = 'crumble'))
      	all_inds <- paste0(all_inds)
      	all_inds <- paste("> ", all_inds, sep = "")
      	writeLines(all_inds,paste0('./-outputs-/',species_binomial,'/Sensitivity/Neutral_sensitivity/fastas/',species_binomial,'_pop_',i,'.fasta'))	  
    	}
    # clear inds for the next iteration of the loop
    rm(list = ls(pattern = "^crumble"))
  }
}

  cat('> Nucleotide diversity calculated...\n', file=log_file, append=T)
  cat('> Summarising nucleotide diversity across populations...\n', file=log_file, append=T)

# then calculate nuc.div across each population
# loop over all unique pops
for (i in 1:nrow(unique)) {
  lhs5 <- paste0('pop_',i)
  rhs5 <- paste0("read.dna(paste0('./-outputs-/',species_binomial,'/Sensitivity/Neutral_sensitivity/fastas/',species_binomial,'_pop_',i,'.fasta'), 'fasta')")
  eq5 <- paste(lhs5, rhs5, sep=' <- ', collapse='; ')
  eval(parse(text=eq5))
  
  lhs5 <- paste0('pop_',i,'_nucleotide_diversity')
  rhs5 <- paste0('nuc.div(pop_',i,')')
  eq5 <- paste(lhs5, rhs5, sep=' <- ', collapse='; ')
  eval(parse(text=eq5))
}

# add sample information and write to csv
nucleotide_diversities <- mget(ls(pattern='_nucleotide_diversity'))
nucleotide_diversity <- as.data.frame(nucleotide_diversities)

names <- colnames(nucleotide_diversity)
ordered_names <- str_sort(names, numeric = TRUE)
ordered_names <- toString(ordered_names)
string <- gsub("pop","nucleotide_diversity$pop",ordered_names) 

string1 <- 'cbind('
string3 <- ')'
x <- paste(string1,string,string3)

nucleotide_diversity <- eval(parse(text=paste0(x)))
nucleotide_diversity <- t(nucleotide_diversity)

nucleotide_diversity <- cbind(unique,nucleotide_diversity)
nucleotide_diversity[nucleotide_diversity=='NaN'] <- 0

# append to the neutral_sensitivity file
neutral_heterozygosity_summary
all_metrics <- cbind (neutral_heterozygosity_summary,nucleotide_diversity$nucleotide_diversity)
all_metrics <- all_metrics[,c(1,2,3,5,4)]
colnames(all_metrics) <-  c('LAT','LONG','Neutral_heterozygosity', 'Neutral_nucleotide_diversity','Neutral_sensitivity')

  cat('> Creating neutral sensitivity metrics per population...\n', file=log_file, append=T)
  
# make a metric to measure 'neutral sensitivity'
  neutral_nucleotide_diversity <- all_metrics$Neutral_nucleotide_diversity

  # make dataframe of coordinates, individual sample numbers and neutral heterozygosity
  #df <- cbind(lat_list, long_list, ind_counts_per_pop$N_individuals, neutral_heterozygosity)
  
  # get the quantiles of the data
  q1 <- as.numeric(quantile(neutral_nucleotide_diversity, probs=0.1))
  q2 <- as.numeric(quantile(neutral_nucleotide_diversity, probs=0.2))
  q3 <- as.numeric(quantile(neutral_nucleotide_diversity, probs=0.3))
  q4 <- as.numeric(quantile(neutral_nucleotide_diversity, probs=0.4))
  q5 <- as.numeric(quantile(neutral_nucleotide_diversity, probs=0.5))
  q6 <- as.numeric(quantile(neutral_nucleotide_diversity, probs=0.6))
  q7 <- as.numeric(quantile(neutral_nucleotide_diversity, probs=0.7))
  q8 <- as.numeric(quantile(neutral_nucleotide_diversity, probs=0.8))
  q9 <- as.numeric(quantile(neutral_nucleotide_diversity, probs=0.9))
 
# get the intervals based on the range of the data
  lhs3.9.1 <- paste0('min', sep='')
  rhs3.9.1 <- paste0('min(neutral_nucleotide_diversity)')
  eq3.9.1  <- paste(paste(lhs3.9.1, rhs3.9.1, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.9.1))
  lhs3.9.1 <- paste0('max', sep='')
  rhs3.9.1 <- paste0('max(neutral_nucleotide_diversity)')
  eq3.9.1  <- paste(paste(lhs3.9.1, rhs3.9.1, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.9.1))
  range <- max-min
  increments <- range/10
  i10 <- min
  i9 <- min+increments
  i8 <- i9+increments
  i7 <- i8+increments
  i6 <- i7+increments
  i5 <- i6+increments
  i4 <- i5+increments
  i3 <- i4+increments
  i2 <- i3+increments
  i1 <- i2+increments

  # use defined thresholds from params file
  thresholds <- params$neutral_sensitivity_nucleotide_diversity_thresholds
  thresholds <- as.data.frame(unlist(strsplit(thresholds,",")))
  thresholds$number <- c(1:10)
  colnames(thresholds) <- c('value','number')

# any population with nucleotide diversity of 0 (i.e. only 1 individual) remains as zero
 # generate the scores based on the option selected - 'defined', 'interval', or 'quantile'
if (params$neutral_sensitivity_quantification=='defined'){
#defined
  neutral_sensitivity <- as.data.frame(findInterval(neutral_nucleotide_diversity,c(as.numeric(thresholds$value))))
  neutral_sensitivity <- 10-neutral_sensitivity }else{
 if (params$neutral_sensitivity_quantification=='interval'){ 
# interval
    neutral_sensitivity <- as.data.frame(findInterval(neutral_nucleotide_diversity,(c(i10,i9,i8,i7,i6,i5,i4,i3,i2,i1))))
	neutral_sensitivity <- 11-neutral_sensitivity }else{
	if (params$neutral_sensitivity_quantification=='quantile'){ 
# quantile
  		neutral_sensitivity <- as.data.frame(findInterval(neutral_nucleotide_diversity,(c(q1,q2,q3,q4,q5,q6,q7,q8,q9))))
  		neutral_sensitivity <- 10-neutral_sensitivity
  }
}
}

colnames(neutral_sensitivity) <- c('neutral_sensitivity')
# By default, if heterozygosity is not requested as the neutral sensitivity metric, neutral sensitivity will be based on this
if (params$neutral_sensitivity_metric!='heterozygosity') {
all_metrics$Neutral_sensitivity <- neutral_sensitivity$neutral_sensitivity
}

# and if Neutral_nucleotide_diversity is zero then neutral sensitivity becomes zero (and is accounted for later when summarising final population vulnerability)
for (i in 1:nrow(all_metrics)) { 
    if (all_metrics$Neutral_nucleotide_diversity[i] == 0) {
        all_metrics$Neutral_sensitivity[i] <- 0
    }
}

write.csv(all_metrics, paste0(output_path,species_binomial,"_neutral_sensitivity.csv"), row.names=FALSE)

cat('> Neutral sensitivity analyses completed successfully ...\n\n', file=log_file, append=T)
  
}

#############################################################################################################################################################################################
adaptive_sensitivity <- function(species_binomial) {
#############################################################################################################################################################################################

# Quantifies 'adaptive sensitivity' across populations based on genomic offset (if params$adaptive_sensitivity_rule == '1'), or by simply counting the proportions of adapted individuals (if params$adaptive_sensitivity_rule == '2')
  
rm(list=ls(all=TRUE))
  
  root_dir <- ('$YOUR_WORK_DIR')
  setwd(root_dir)
  
  # read args
  args <- commandArgs()
  print(args)
  species_binomial <- args[8]  # This may vary between systems depending on your HPC setup, the list of arguments will be printed at the beginning of your SLURM job logfile so if the jobs fail, make sure that this number matches the number in args[] that matches your species name
  
  # set params file
  params_all <- read.delim('./Params.tsv')
  
  # Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
  params <- params_all[which(params_all$species_binomial==species_binomial),]
  species_binomial <- params$species_binomial
  
  spatial_dir <- paste0(root_dir,'-data-/spatial_data/',species_binomial,'/')
  log_file <- paste0('-outputs-/log_files/',species_binomial,'.log')
  
  library(raster)
  library(rgdal)
  library(sp)
  library(tidyverse)
  library(reshape2)
  library(plyr)
  library(ggplot2)
  library(ggpubr)
  library(usdm)
  
  cat('--------------------------------------------------------------\n', file=log_file, append=T)
  cat('Quantifying adaptive sensitivity...\n', file=log_file, append=T)
  cat('--------------------------------------------------------------\n', file=log_file, append=T)
  
  # Calculate adaptive sensitivity metric for each population
  library(plyr)
  
  cat('> Generating adaptive sensitivity metrics...\n', file=log_file, append=T)
  
  # first check if adaptive categorisation step worked, if not we will set a standard ('5') for all populations
  if (file.exists(paste0('-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_adaptive_categorisation_individuals.csv'))) {

  # list of unique geographic individuals/populations (including numbers of inds adapted to relative conditions)
  ind_list_by_category <- read.csv(paste0('-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_adaptive_categorisation_individuals.csv'))
  
  #list of neutral sensitivity scores per individuals/populations
  neutral_sensitivity <- read.csv(paste0('-outputs-/',species_binomial,'/Sensitivity/Neutral_sensitivity/',species_binomial,'_neutral_sensitivity.csv'))
  neutral_sensitivity <- neutral_sensitivity[,c(1,2,5)]
  #neutral_sensitivity[neutral_sensitivity$Neutral_sensitivity=='NA'] <- 0

 # exposure <- exposure[,c(1,2,8,9)]
  exposure <- read.csv(paste0('-outputs-/',species_binomial,'/Exposure/',species_binomial,'_Exposure.csv'))
  exposure <- exposure[,c(1,2)]
  colnames(exposure) <- c('LONG', 'LAT')
  
  # join neutral sensitivity
  sensitivity <- ind_list_by_category%>% right_join(neutral_sensitivity, by=c("LONG"))
  
  # which col names are actually in sensitivity? grab these and use to select the columns (in case one or more category is not present)
  expected_categories <- c(params$category_1, params$category_2,'intermediate')
  column_names <- colnames(sensitivity)
  actual_categories <- intersect(expected_categories,column_names)
  
  sensitivity <- sensitivity[,c('LONG','LAT.x','n_samples','POP_ID',actual_categories,'Neutral_sensitivity')]
  colnames(sensitivity) <- c('LONG','LAT','n_samples','POP_ID', actual_categories,'neutral_sensitivity' )
  sensitivity <- na.omit(sensitivity)
  
  # join exposure
  df <- sensitivity%>% right_join(exposure, by=c('LONG','LAT'))
  df <- na.omit(df)
  
  # read in genomic offset values
  genomic_offset <- read.csv(paste0('-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_genomic_offset.csv'))
  df <- df%>% right_join(genomic_offset, by=c('LONG','LAT'))

  # get the quantiles of the data
  q1 <- as.numeric(quantile(df$genomic_offset, probs=0.1))
  q2 <- as.numeric(quantile(df$genomic_offset, probs=0.2))
  q3 <- as.numeric(quantile(df$genomic_offset, probs=0.3))
  q4 <- as.numeric(quantile(df$genomic_offset, probs=0.4))
  q5 <- as.numeric(quantile(df$genomic_offset, probs=0.5))
  q6 <- as.numeric(quantile(df$genomic_offset, probs=0.6))
  q7 <- as.numeric(quantile(df$genomic_offset, probs=0.7))
  q8 <- as.numeric(quantile(df$genomic_offset, probs=0.8))
  q9 <- as.numeric(quantile(df$genomic_offset, probs=0.9))
  
  # get the intervals based on the range of the data
  lhs3.9.1 <- paste0('min', sep='')
  rhs3.9.1 <- paste0('min(df$genomic_offset)')
  eq3.9.1  <- paste(paste(lhs3.9.1, rhs3.9.1, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.9.1))
  lhs3.9.1 <- paste0('max', sep='')
  rhs3.9.1 <- paste0('max(df$genomic_offset)')
  eq3.9.1  <- paste(paste(lhs3.9.1, rhs3.9.1, sep=' <- '), collapse='; ')
  eval(parse(text=eq3.9.1))
  range <- max-min
  increments <- range/10
  i10 <- min
  i9 <- min+increments
  i8 <- i9+increments
  i7 <- i8+increments
  i6 <- i7+increments
  i5 <- i6+increments
  i4 <- i5+increments
  i3 <- i4+increments
  i2 <- i3+increments
  i1 <- i2+increments

  # use defined thresholds from params file
  thresholds <- params$genomic_offset_thresholds
  thresholds <- as.data.frame(unlist(strsplit(thresholds,",")))
  thresholds$number <- c(1:10)
  colnames(thresholds) <- c('value','number')

 # generate the scores based on the option selected - 'defined', 'interval', or 'quantile'

if (params$genomic_offset_quantification=='defined'){
#defined
 adaptive_sensitivity <- as.data.frame(findInterval(df$genomic_offset,c(as.numeric(thresholds$value))))
  colnames(adaptive_sensitivity) <- 'adaptive_sensitivity'
  df <- cbind(df,adaptive_sensitivity) }else{
 if (params$genomic_offset_quantification=='interval'){ 
# interval
    adaptive_sensitivity <- as.data.frame(findInterval(df$genomic_offset,(c(i10,i9,i8,i7,i6,i5,i4,i3,i2,i1))))
	colnames(adaptive_sensitivity) <- 'adaptive_sensitivity'
	df <- cbind(df,adaptive_sensitivity) }else{
	if (params$genomic_offset_quantification=='quantile'){ 
# quantile
  		adaptive_sensitivity <- as.data.frame(findInterval(df$genomic_offset,(c(q1,q2,q3,q4,q5,q6,q7,q8,q9))))
	    colnames(adaptive_sensitivity) <- 'adaptive_sensitivity'
	    df <- cbind(df,adaptive_sensitivity)  }
cat(paste0('> Adaptive sensitivity calculated based on genomic offsets per population \n'), file=log_file, append=T)
}
}
}

# write out
# trim off to 2 decimal places (except for LONG/LAT)  
library(dplyr)
adaptive_sensitivity <- df
adaptive_sensitivity <- adaptive_sensitivity %>% mutate_at(vars(-LONG,-LAT), funs(round(., 2)))
write.csv(adaptive_sensitivity,paste0('-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,"_adaptive_sensitivity.csv"), row.names=FALSE)
  cat('> Adaptive sensitivity analyses completed successfully...\n\n', file=log_file, append=T)

}

#############################################################################################################################################################################################
adaptive_sdms_biomod2 <- function(species_binomial) {
#############################################################################################################################################################################################
  
  # Builds adaptive sdms using biomod2
  
  rm(list=ls(all=TRUE))
  
  #library(devtools)
  
  library(biomod2)
  library(terra)
  library(raster)
  library(rgdal)
  library(sp)
  
  root_dir <- ('$YOUR_WORK_DIR')
  setwd(root_dir)
  
  # set params file
  params_all <- read.delim('./Params.tsv')
  
  # read args
  args <- commandArgs()
  print(args)
  species_binomial <- args[8]  # This may vary between systems depending on your HPC setup, the list of arguments will be printed at the beginning of your SLURM job logfile so if the jobs fail, make sure that this number matches the number in args[] that matches your species name
  
  # Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
  params <- params_all[which(params_all$species_binomial==species_binomial),]
  species_binomial <- params$species_binomial
  
  spatial_dir <- paste0(root_dir,'-data-/spatial_data/',species_binomial,'/')
  log_file <- paste0(root_dir,'./-outputs-/log_files/',species_binomial,'.log')
  adaptive_sdm_dir <- paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/adaptive_SDMs/')
  dir.create(adaptive_sdm_dir)
  
  # # copy maxent.jar file to directory
  # file.copy(paste0(root_dir,'-data-/maxent.jar'), paste0(params$maxent_path,'/maxent.jar'))
  setwd(adaptive_sdm_dir)
  
  ############################
  #. Build adaptive species distribution models
  
  cat('--------------------------------------------------------------\n', file=log_file, append=T)
  cat('Building adaptive SDMs using biomod2 package...\n', file=log_file, append=T)
  cat('--------------------------------------------------------------\n', file=log_file, append=T)

#first check all categorised files actually exists (and didn't fail')
if (file.exists(paste0(root_dir,'/-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_categorised_individuals_',params$category_1,'.csv')) & file.exists(paste0(root_dir,'/-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_categorised_individuals_',params$category_2,'.csv'))) 
{ 
  # for loop for categorised inds
  for (i in c(params$category_1,params$category_2,'intermediate')) {
    cat('> Building models for ' ,i, ' individuals...\n', file=log_file, append=T)
    
  # read presences (thinned)
  presences <- read.csv(paste0(root_dir,'-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_categorised_individuals_',i,'.csv'))
  presences <- presences[,c('LONG','LAT')] # keep only the coordinates
  presences <- na.omit(presences)
  presences$presence <- TRUE # add presences column, biomod needs this
  pres_abs <- presences$presence
  #presences <- presences[,1:2]
  
  # read absences (already generated)
  bg <- read.csv(paste0(root_dir,'-outputs-/',species_binomial,'/Exposure/SDMs/',species_binomial,'_background_points.csv'))
  bg <- bg[,2:3]
  bg$presence <- FALSE
  colnames(bg) <- c('LONG', 'LAT', 'presence')
  
  presence_absences <- rbind(presences,bg) # bind presences and absences to create PA table (all presences = 'TRUE', absences = 'FALSE)
  #presence_absences <- presence_absences[,c(2,1,3)] # reorder columns so lat then long
  
  # read predictors and rename them properly
  current_climate_lst <- list.files(path=paste0(spatial_dir,'/current_climate/'),pattern='.tif$',full.names = T)
  current_climate <- raster::stack(current_climate_lst)
  names_lst <- gsub(paste0(spatial_dir,'/current_climate/'),'',current_climate_lst)
  names_lst <- gsub('.tif','',names_lst)
  names(current_climate) <- names_lst
  
  future_climate_lst <- list.files(path=paste0(spatial_dir,'/future_climate/'),pattern='.tif$',full.names = T)
  future_climate <- raster::stack(future_climate_lst)
  names_lst <- gsub(paste0(spatial_dir,'/future_climate/'),'',future_climate_lst)
  names_lst <- gsub('.tif','',names_lst)
  names(future_climate) <- names_lst
  
  # Reducing highly correlated variables (usng VIF) based on raster data extracted at presence points - only if yes in params file
  if (params$perform_vif == 'yes') {
    library(usdm)
    # re-read presences (thinned) just for this step
    presences <- read.csv(paste0(root_dir,'-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_categorised_individuals_',i,'.csv'))
    presences <- presences[,c('LONG','LAT')] # keep only the coordinates
    presences <- na.omit(presences)
    uncorrelated_vars <- raster::extract(current_climate, presences)
    uncorrelated_vars <- data.frame(uncorrelated_vars)
    
    vif <- vifstep(uncorrelated_vars)
    vif
    
    current_climate <- exclude(current_climate, vif)
    current_climate_spat_rast <- rast(current_climate)
    
    future_climate <- exclude(future_climate, vif)
    future_climate_spat_rast <- rast(future_climate)
  } else {
    
    # Using subset of current predictors from the full set - only if defined in params$subset_predictors
    if (params$subset_predictors != '') {
      lst_predictors <- params$subset_predictors
      lst_predictors <- paste0(params$subset_predictors,',') # add a comma to last element so it is captured in below code for adding file extensions
      lst_predictors <- gsub(",",".tif,",lst_predictors) # add file extensions
      lst_predictors <- unlist(strsplit(lst_predictors,",")) # split them in to list
      
      # current
      # append full path before it for current predictors
      for (j in 1:length(lst_predictors)){
        lhs <- paste0('lst_predictors[',j,']')
        rhs <- paste0("paste0('",spatial_dir,"/current_climate/',lst_predictors[",j,"])")
        eq <- paste(paste(lhs, rhs, sep=' <- '), collapse='; ')
        eval(parse(text=eq))
      }
      
      current_climate <- raster::stack(lst_predictors)
      # rename them to their proper names
      lst_predictors <- params$subset_predictors
      lst_predictors <- paste0(params$subset_predictors,',') # add a comma to last element so it is captured in below code for adding file extensions
      lst_predictors <- unlist(strsplit(lst_predictors,",")) # split them in to list
      names(current_climate) <- lst_predictors
      
      # terra raster
      
      # subset the list based on params$subset_predictors
      current_lst_predictors <- params$subset_predictors
      current_lst_predictors <- paste0(params$subset_predictors,',') # add a comma to last element so it is captured in below code for adding file extensions
      current_lst_predictors <- gsub(",",".tif,",current_lst_predictors) # add file extensions
      current_lst_predictors <- unlist(strsplit(current_lst_predictors,",")) # split them in to list
      current_lst_predictors <- paste0(spatial_dir,'/current_climate/',current_lst_predictors) # add a comma to first element so it is captured in below code for adding file extensions
      
      current_climate_spat_rast <- rast(current_lst_predictors)
      
      # rename them to their proper names
      current_lst_predictors <- params$subset_predictors
      current_lst_predictors <- paste0(params$subset_predictors,',') # add a comma to last element so it is captured in below code for adding file extensions
      current_lst_predictors <- unlist(strsplit(current_lst_predictors,",")) # split them in to list
      names(current_climate_spat_rast) <- current_lst_predictors
      
      
      # #future
      # append full path before it for future predictors
      lst_predictors <- params$subset_predictors
      lst_predictors <- paste0(params$subset_predictors,',') # add a comma to last element so it is captured in below code for adding file extensions
      lst_predictors <- gsub(",",".tif,",lst_predictors) # add file extensions
      lst_predictors <- unlist(strsplit(lst_predictors,",")) # split them in to list
      
      for (k in 1:length(lst_predictors)){
        lhs <- paste0('lst_predictors[',k,']')
        rhs <- paste0("paste0('",spatial_dir,"/future_climate/',lst_predictors[",k,"])")
        eq <- paste(paste(lhs, rhs, sep=' <- '), collapse='; ')
        eval(parse(text=eq))
      }
      future_climate <- raster::stack(lst_predictors)
      # rename them to their proper names
      lst_predictors <- params$subset_predictors
      lst_predictors <- paste0(params$subset_predictors,',') # add a comma to last element so it is captured in below code for adding file extensions
      lst_predictors <- unlist(strsplit(lst_predictors,",")) # split them in to list
      names(future_climate) <- lst_predictors
      
      future_lst_predictors <- params$subset_predictors
      future_lst_predictors <- paste0(params$subset_predictors,',') # add a comma to last element so it is captured in below code for adding file extensions
      future_lst_predictors <- gsub(",",".tif,",future_lst_predictors) # add file extensions
      future_lst_predictors <- unlist(strsplit(future_lst_predictors,",")) # split them in to list
      future_lst_predictors <- paste0(spatial_dir,'/future_climate/',future_lst_predictors) # add a comma to first element so it is captured in below code for adding file extensions
      
      future_climate_spat_rast <- rast(future_lst_predictors)
      
      # rename them to their proper names
      future_lst_predictors <- params$subset_predictors
      future_lst_predictors <- paste0(params$subset_predictors,',') # add a comma to last element so it is captured in below code for adding file extensions
      future_lst_predictors <- unlist(strsplit(future_lst_predictors,",")) # split them in to list
      names(future_climate_spat_rast) <- future_lst_predictors
      
    }
    
    # plot predictors
    world_shapefile <- readOGR(paste0(root_dir,'./-data-/map_data/ne_50m_admin_0_countries.shp'))
    xmin <- current_climate[[1]]@extent@xmin
    xmax <- current_climate[[1]]@extent@xmax
    ymin <- current_climate[[1]]@extent@ymin
    ymax <- current_climate[[1]]@extent@ymax
    lhs <- paste0('cropped_shapefile')
    rhs <- paste0('crop(world_shapefile, extent(',xmin,',',xmax,',',ymin,',',ymax,'))')
    eq <- paste(paste(lhs, rhs, sep=' <- '), collapse='; ')
    eval(parse(text=eq))
        
    cat('> Predictor variables checked for autocorrelation using sample locations and Variance Inflation Factors...\n', file=log_file, append=T)
    cat('> Predictors remaining:\n', file=log_file, append=T)
    cat(paste0(capture.output(current_climate)), '\n', file=log_file, append=T)
    
  }
  
  # Format Data with true absences
  presence_absences$presence[presence_absences$presence == 'TRUE'] <- 1
  presence_absences$presence[presence_absences$presence == 'FALSE'] <- 0
  presence_absences$presence <- as.numeric(presence_absences$presence)
  presence_absences_xy <- presence_absences[,1:2]
  presence_absences.PA <- ifelse(presence_absences$presence == 1, 1, NA)
  colnames(presence_absences_xy) <- c('X_WGS84', 'Y_WGS84')
  
  myPAtable <- data.frame(PA1 = ifelse(presence_absences$presence == 1, TRUE, FALSE),
                               PA2 = ifelse(presence_absences$presence == 1, TRUE, FALSE))
  for (l in 1:ncol(myPAtable)) myPAtable[sample(which(myPAtable[, l] == FALSE), 100), l] = TRUE # 500
  
  crs(current_climate_spat_rast) <- "+proj=longlat +datum=WGS84 +no_defs"
  
  current_climate_spat_rast <- stack(current_climate_spat_rast)

  myBiomodData <- BIOMOD_FormatingData(resp.var = presence_absences.PA,
                                      expl.var = current_climate_spat_rast, 
                                      # expl.var = current, 
                                       resp.xy = presence_absences_xy,
                                       resp.name = paste0(species_binomial,'_',i),
                                       PA.strategy = 'user.defined',
                                       PA.user.table = myPAtable)
  

  bm_DefaultModelingOptions()
  cat('> Building models for ' ,i, ' individuals...\n', file=log_file, append=T)
  
  cat('> Building adaptive SDMs for ' ,i, ' individuals using SDM algorithms - ',params$biomod_algorithms, ', with', params$sdm_reps_per_algorithm,'replicates per algorithm\n', file=log_file, append=T)
  cat('> Number of background points: ', nrow(bg), file=log_file, append=T)
  
  # Create default modeling options
  myBiomodOptions <- BIOMOD_ModelingOptions()
  myBiomodOptions
  
  #edit the maxent path (Doesn't like my dropbox path...)
  myBiomodOptions <- BIOMOD_ModelingOptions(MAXENT = list(path_to_maxent.jar = params$maxent_path))
  myBiomodCV <- BIOMOD_CrossValidation(bm.format = myBiomodData, nb.rep=10)
  head(myBiomodCV)
  
  
  models <- params$biomod_algorithms
  models <- paste0("'",models)
  models <- paste('c(',models,')')
  models <- eval(parse(text=models))
  
   
  # RUN MODELS
  # Single models
  myBiomodModelOut <- BIOMOD_Modeling(bm.format = myBiomodData,
                                      bm.options = myBiomodOptions,
                                      models = (models),
                                      nb.rep = params$sdm_reps_per_algorithm,
                                      data.split.perc = params$data_split_percentage,
                                      data.split.table = myBiomodCV,
                                      var.import = 3,
                                      metric.eval = c('TSS','ROC'),
                                      do.full.models = FALSE)
  
  #
  # seed.val = 123)
  # nb.cpu = 8)
  myBiomodModelOut
  
  # Get evaluation scores & variables importance
  get_evaluations(myBiomodModelOut)
  get_variables_importance(myBiomodModelOut)
  
  
  # as with previous SDMs in biomod2, many output images are available, can be uncommented here if you want them
  # we keep only the variable importance figure output as default
   
  # Represent evaluation scores & variables importance
  #png(paste0(species_binomial,'_',i,'_biomod_model_algorithm_performance_general.png'), units='cm', height=30, width=30, res=300)
  #bm_PlotEvalMean(bm.out = myBiomodModelOut)
  #dev.off()
  #png(paste0(species_binomial,'_',i,'_biomod_model_algorithm_performance_boxplots.png'), units='cm', height=30, width=30, res=300)
  #bm_PlotEvalBoxplot(bm.out = myBiomodModelOut, group.by = c('algo', 'algo'))
  #dev.off()
  #png(paste0(species_binomial,'_',i,'_biomod_model_algorithm_performance_scatterplots.png'), units='cm', height=30, width=30, res=300)
  #bm_PlotEvalBoxplot(bm.out = myBiomodModelOut, group.by = c('algo', 'run'))
  #dev.off()
  png(paste0(species_binomial,'_',i,'_biomod_variable_importance_general.png'), units='cm', height=30, width=30, res=300)
  bm_PlotVarImpBoxplot(bm.out = myBiomodModelOut, group.by = c('expl.var', 'algo', 'algo'))
  dev.off()
  #png(paste0(species_binomial,'_',i,'_biomod_variable_importance_by_algorithm.png'), units='cm', height=30, width=30, res=300)
  #bm_PlotVarImpBoxplot(bm.out = myBiomodModelOut, group.by = c('expl.var', 'algo', 'full.name'))
  #dev.off()
  #png(paste0(species_binomial,'_',i,'_biomod_variable_importance_by_predictor.png'), units='cm', height=30, width=30, res=300)
  #bm_PlotVarImpBoxplot(bm.out = myBiomodModelOut, group.by = c('algo', 'expl.var', 'full.name'))
  #dev.off()
  # Represent response curves
  #png(paste0(species_binomial,'_',i,'_biomod_response_curves_by_predictor_min.png'), units='cm', height=30, width=30, res=300)
  #bm_PlotResponseCurves(bm.out = myBiomodModelOut, 
  #                      models.chosen = get_built_models(myBiomodModelOut)[c(1:3, 12:14)],
  #                      fixed.var = 'median')
  #dev.off()
  #png(paste0(species_binomial,'_',i,'_biomod_response_curves_by_predictor_median.png'), units='cm', height=30, width=30, res=300)
  #bm_PlotResponseCurves(bm.out = myBiomodModelOut, 
  #                      models.chosen = get_built_models(myBiomodModelOut)[c(1:3, 12:14)],
  #                      fixed.var = 'min')
  #dev.off()
  #png(paste0(species_binomial,'_',i,'_biomod_response_curves_by_predictor_median_probabilities.png'), units='cm', height=30, width=30, res=300)
  #bm_PlotResponseCurves(bm.out = myBiomodModelOut, 
  #                      models.chosen = get_built_models(myBiomodModelOut)[3],
  #                      fixed.var = 'median',
  #                      do.bivariate = TRUE)
  #dev.off()
  
  
  ####Ensemble models
  # Model ensemble models
  myBiomodEM <- BIOMOD_EnsembleModeling(bm.mod = myBiomodModelOut,
                                        models.chosen = 'all',
                                        em.by = 'all',
                                        metric.select = c('ROC'),
                                        metric.select.thresh = c(params$ROC_min),
                                        var.import = 3,
                                        metric.eval = c('TSS','ROC'),
                                        prob.mean = TRUE,
                                        prob.median = TRUE,
                                        prob.cv = TRUE,
                                        prob.ci = TRUE,
                                        prob.ci.alpha = 0.05,
                                        committee.averaging = TRUE,
                                        prob.mean.weight = TRUE,
                                        prob.mean.weight.decay = 'proportional')
  myBiomodEM
  
  # Get evaluation scores & variables importance
  get_evaluations(myBiomodEM)
  get_variables_importance(myBiomodEM)
  
  # Represent evaluation scores & variables importance
  #png(paste0(species_binomial,'_',i,'_biomod_ensemble_model_algorithm_performance_general.png'), units='cm', height=30, width=30, res=300)
  #bm_PlotEvalMean(bm.out = myBiomodEM, group.by = 'full.name')
  #dev.off()
  #png(paste0(species_binomial,'_',i,'_biomod_ensemble_model_algorithm_performance_boxplots.png'), units='cm', height=30, width=30, res=300)
  #bm_PlotEvalBoxplot(bm.out = myBiomodEM, group.by = c('full.name', 'full.name'))
  #dev.off()
  png(paste0(species_binomial,'_',i,'_biomod_ensemble_variable_importance_by_predictors_general.png'), units='cm', height=30, width=30, res=300)
  bm_PlotVarImpBoxplot(bm.out = myBiomodEM, group.by = c('expl.var', 'full.name', 'full.name'))
  dev.off()
  #png(paste0(species_binomial,'_',i,'_biomod_ensemble_variable_importance_by_predictors_boxplots.png'), units='cm', height=30, width=30, res=300)
  #bm_PlotVarImpBoxplot(bm.out = myBiomodEM, group.by = c('expl.var', 'full.name', 'algo'))
  #dev.off()

  # Represent response curves
  #png(paste0(species_binomial,'_',i,'_biomod_ensemble_response_curves_by_predictor_median.png'), units='cm', height=30, width=30, res=300)
  #bm_PlotResponseCurves(bm.out = myBiomodEM, 
  #                      models.chosen = get_built_models(myBiomodEM)[c(1, 6, 7)],
  #                      fixed.var = 'median')
  #dev.off()
  #png(paste0(species_binomial,'_',i,'_biomod_ensemble_response_curves_by_predictor_min.png'), units='cm', height=30, width=30, res=300)
  #bm_PlotResponseCurves(bm.out = myBiomodEM, 
  #                      models.chosen = get_built_models(myBiomodEM)[c(1, 6, 7)],
  #                      fixed.var = 'min')
  #dev.off()
  #png(paste0(species_binomial,'_',i,'_biomod_ensemble_response_curves_by_predictor_median_probabilities.png'), units='cm', height=30, width=30, res=300)
  #bm_PlotResponseCurves(bm.out = myBiomodEM, 
  #                      models.chosen = get_built_models(myBiomodEM)[7],
  #                      fixed.var = 'median',
  #                      do.bivariate = TRUE)
  #dev.off()
  
  # Ensemble with these "good models"
  cat('> Building final ensemble model with passed thresholds ROC>', params$ROC_min,'...\n', file=log_file, append=T)
  
  # ensure predictors are a rasterstack
current_climate_spat_rast <- stack(current_climate_spat_rast)

  # Project ensemble models (building single projections) # i.e. the ensemble for current
  myBiomodEM_current_Proj <- BIOMOD_EnsembleForecasting(bm.em = myBiomodEM,
                                                        proj.name = 'Current_EM',
                                                        new.env = current_climate_spat_rast, # current_climate_spat_rast
                                                       # new.env = current, # testing
                                                        models.chosen = 'all',
                                                        binary.meth='ROC',
                                                        metric.binary = 'all',
                                                        metric.filter = 'all',
                                                        build.clamping.mask = TRUE)
  
   # ensure predictors are a rasterstack
future_climate_spat_rast <- stack(future_climate_spat_rast)

  
  # Project ensemble models (building single projections) # i.e. the ensemble for the future
  myBiomodEM_future_Proj <- BIOMOD_EnsembleForecasting(bm.em = myBiomodEM,
                                                       proj.name = 'Future_EM',
                                                       new.env = future_climate_spat_rast, # future_climate_spat_rast
                                                       #new.env = future, # testing
                                                       models.chosen = 'all',
                                                       binary.meth='ROC',
                                                       metric.binary = 'all',
                                                       metric.filter = 'all',
                                                       build.clamping.mask = TRUE)
  myBiomodEM_current_Proj
  #plot(myBiomodEM_current_Proj)

  myBiomodEM_future_Proj
  #plot(myBiomodEM_future_Proj)
  
  # Plot outputs
  # Probabilistic (continuous 0-1) maps - current and future
  current_ROC <- raster(paste0(getwd(),"/", myBiomodData@sp.name,"/proj_Current_EM/", "proj_Current_EM_", myBiomodData@sp.name, "_ensemble_ROCfilt.tif",sep=""))
  current_ROC <- current_ROC/1000
  future_ROC <- raster(paste0(getwd(),"/", myBiomodData@sp.name,"/proj_Future_EM/", "proj_Future_EM_", myBiomodData@sp.name, "_ensemble_ROCfilt.tif",sep=""))
  future_ROC <- future_ROC/1000
  sdm_colours <- colorRampPalette(c('midnightblue','seagreen','chartreuse3','chartreuse2','yellow','orange','indianred'))(100)
  world_shapefile <- readOGR(paste0(root_dir,'/-data-/map_data/ne_50m_admin_0_countries.shp'))
  xmin <- current_climate@extent@xmin
  xmax <- current_climate@extent@xmax
  ymin <- current_climate@extent@ymin
  ymax <- current_climate@extent@ymax
  lhs <- paste0('cropped_shapefile')
  rhs <- paste0('crop(world_shapefile, extent(',xmin,',',xmax,',',ymin,',',ymax,'))')
  eq <- paste(paste(lhs, rhs, sep=' <- '), collapse='; ')
  eval(parse(text=eq))
  
  png(filename=paste0('./',species_binomial,'_',i,'_SDMs_current_and_future.png'),type='cairo', units='cm', width=40, height=30, pointsize=12, res=300) 
  par(mfrow=c(1,2))
  par(cex.main=2, cex.axis=1.5, cex.lab=2)
  par(mar=c(5,5,5,10))
  plot(current_ROC, col=sdm_colours, zlim=c(0,1), main = "Current SDM")
  plot(cropped_shapefile,  add=T, lwd=1.4)
  points(presences, pch=21, cex=0.75, bg='darkorange3',col='black')
  g <- terra::graticule(5, 5, crs="+proj=latlon") # every 5 degreees
  plot(g, background=NULL, col="grey65", lty=2, retro=TRUE, add=TRUE)
  terra::north()
  plot(future_ROC, col=sdm_colours, zlim=c(0,1), main = "Future SDM")
  plot(cropped_shapefile,  add=T, lwd=1.4)
  points(presences, pch=21, cex=0.75, bg='darkorange3',col='black')
  g <- terra::graticule(5, 5, crs="+proj=latlon") # every 5 degreees
  plot(g, background=NULL, col="grey65", lty=2, retro=TRUE, add=TRUE)
  terra::north()
  dev.off()
  
  # write out ensembles as rasters
  writeRaster(current_ROC, filename=paste0('./',species_binomial,'_',i,'_ensemble_SDM_current.asc'), overwrite=TRUE)
  writeRaster(future_ROC, filename=paste0('./',species_binomial,'_',i,'_ensemble_SDM_future.asc'), overwrite=TRUE)

  # Binary presence/absence(1/0) maps - current and future
  # we read them in first and save them as rasters, before doing the summary of all locally adapted individuals outside of the loop
  current_bin <- raster(paste0(getwd(),"/", myBiomodData@sp.name,"/proj_Current_EM/", "proj_Current_EM_", myBiomodData@sp.name, "_ensemble_ROCbin.tif",sep=""))
  future_bin <- raster(paste0(getwd(),"/", myBiomodData@sp.name,"/proj_Future_EM/", "proj_Future_EM_", myBiomodData@sp.name, "_ensemble_ROCbin.tif",sep=""))

  # write out ensembles as rasters
  writeRaster(current_bin, filename=paste0('./',species_binomial,'_',i,'_ensemble_SDM_current_binary.asc'), overwrite=TRUE)
  writeRaster(future_bin, filename=paste0('./',species_binomial,'_',i,'_ensemble_SDM_future_binary.asc'), overwrite=TRUE)
  
  cat('> Output adaptive SDMs (present and future) for ',i, 'individuals saved and plotted \n', file=log_file, append=T)
  
  }
  
  cat('> Plotting final binary range change maps for all categories ... \n', file=log_file, append=T)
  
  lhs1 <- paste0(params$category_1,'_current',sep='')
  rhs1 <- paste0('raster("',paste0('./',species_binomial,'_',params$category_1,'_ensemble_SDM_current_binary','.asc")'))
  eq1  <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
  eval(parse(text=eq1))
  #hot_dry_current <- raster(paste0(output_dir,species_binomial,'_ensemble_SDM_current_binary_hot_dry.asc'))
  
  lhs2 <- paste0(params$category_2,'_current',sep='')
  rhs2 <- paste0('raster("',paste0('./',species_binomial,'_',params$category_2,'_ensemble_SDM_current_binary','.asc")'))
  eq2  <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
  eval(parse(text=eq2))
  #cold_wet_current <- raster(paste0(output_dir,species_binomial,'_ensemble_SDM_current_binary_cold_wet.asc'))
  
  lhs3 <- paste0('both_current',sep='')
  rhs3 <- paste0('overlay(',lhs1,',',lhs2, ',fun="sum")')
  eq3  <- paste(paste(lhs3, rhs3, sep=' <- '), collapse='; ')
  eval(parse(text=eq3))
  #both_current <- overlay(hot_dry_current,cold_wet_current, fun='sum') 
  
  lhs4 <- paste0(params$category_1,'_future',sep='')
  rhs4 <- paste0('raster("',paste0('./',species_binomial,'_',params$category_1,'_ensemble_SDM_future_binary.asc")'))
  eq4  <- paste(paste(lhs4, rhs4, sep=' <- '), collapse='; ')
  eval(parse(text=eq4))
  #hot_dry_future <- raster(paste0(output_dir,species_binomial,'_ensemble_SDM_future_binary_hot_dry.asc'))
  
  lhs5 <- paste0(params$category_2,'_future',sep='')
  rhs5 <- paste0('raster("',paste0('./',species_binomial,'_',params$category_2,'_ensemble_SDM_future_binary.asc")'))
  eq5  <- paste(paste(lhs5, rhs5, sep=' <- '), collapse='; ')
  eval(parse(text=eq5))
  #cold_wet_future <- raster(paste0(output_dir,species_binomial,'_ensemble_SDM_future_binary_cold_wet.asc'))
  
  lhs6 <- paste0('both_future',sep='')
  rhs6 <- paste0('overlay(',lhs4,',',lhs5, ',fun="sum")')
  eq6  <- paste(paste(lhs6, rhs6, sep=' <- '), collapse='; ')
  eval(parse(text=eq6))
  
 hot_dry_current[hot_dry_current < 1] <- NA
 hot_dry_future[hot_dry_future < 1] <- NA
 cold_wet_current[cold_wet_current < 1] <- NA
 cold_wet_future[cold_wet_future < 1] <- NA
 both_current[both_current < 2] <- NA
 both_future[both_future < 2] <- NA
 
  # plot
  world_shapefile <- readOGR(paste0(root_dir,'-data-/map_data/ne_50m_admin_0_countries.shp'))
  xmin <- current_climate[[1]]@extent@xmin
  xmax <- current_climate[[1]]@extent@xmax
  ymin <- current_climate[[1]]@extent@ymin
  ymax <- current_climate[[1]]@extent@ymax
  lhs <- paste0('cropped_shapefile')
  rhs <- paste0('crop(world_shapefile, extent(',xmin,',',xmax,',',ymin,',',ymax,'))')
  eq <- paste(paste(lhs, rhs, sep=' <- '), collapse='; ')
  eval(parse(text=eq))
  
  png(filename=paste0('./',species_binomial,'_binary_SDMs_current_and_future.png'),type='cairo', units='cm', width=40, height=30, pointsize=12, res=300) 
  par(mfrow=c(1,2))
  plot(current_climate[[1]], legend=FALSE, col = 'grey90',main = "Locally adapted SDMs - current climatic conditions")
  plot(eval(parse(text=paste0(lhs1))), legend=FALSE, col ='tomato', add = T)
  plot(eval(parse(text=paste0(lhs2))), legend=FALSE, col ='steelblue', add = T)
  plot(both_current, legend=FALSE, col ='yellow', add = T)
  #plot(cropped_shapefile, lwd=1.4, add = T)
  
  plot(future_climate[[1]], legend=FALSE, col = 'grey90',main = "Locally adapted SDMs - future climatic conditions")
  plot(hot_dry_future, legend=FALSE, col ='tomato', add = T)
  plot(cold_wet_future, legend=FALSE, col ='steelblue', add = T)
  plot(both_future, legend=FALSE, col ='yellow', add = T)
  legend('topright', legend=c(params$category_1,params$category_2,'both'), ncol=1, col=c('red', 'steelblue', 'yellow'), bg=c('transparent'), pch = c(19,19,19), cex=1.3)
  #plot(cropped_shapefile, lwd=1.4, add = T)
  dev.off()
  
  cat('> Adaptive SDMs completed successfully...\n\n', file=log_file, append=T)
} else {	
  		cat('\n> Unable to build adaptive SDMs, files do not exist! Check the outputs of the individual categorisation step ...\n', file=file.path(log_file), append=T)
  	   }

}

#############################################################################################################################################################################################
create_circuitscape_inputs <- function(species_binomial) {
#############################################################################################################################################################################################
  
  ########## Create ini and julia files for Circuitscape analysis
  
  rm(list=ls(all=TRUE))
  
  library (raster)
  library(tidyverse)
  
  root_dir <- ('$YOUR_WORK_DIR')
  setwd(root_dir)
  
  # Functions first, to write the actual ini and jl files as well as sh if using HPC
  
  # INI
  create_circuitscape_inifile <- function(coordinates,rasterfile)
  {
    ini_text <- NULL
    ini_text <- c("[Options for advanced mode]",
                  "ground_file_is_resistances = True",
                  "remove_src_or_gnd = keepall",
                  "ground_file = (Browse for a ground point file)",
                  "use_unit_currents = False",
                  "source_file = (Browse for a current source file)",
                  "use_direct_grounds = False",
                  "",
                  "[Mask file]",
                  "mask_file = None",
                  "use_mask = False",
                  "",
                  "[Calculation options]",
                  "low_memory_mode = False",
                  "parallelize = False",
                  "solver = cg+amg",
                  "print_timings = True",
                  "preemptive_memory_release = False",
                  "print_rusages = False",
                  "max_parallel = 0",
                  "",
                  "[Short circuit regions (aka polygons)]",
                  "polygon_file = (Browse for a short-circuit region file)",
                  "use_polygons = False",
                  "",
                  
                  "[Options for one-to-all and all-to-one modes]",
                  "use_variable_source_strengths = False",
                  "variable_source_file = None",
                  "",
                  "[Output options]",
                  "set_null_currents_to_nodata = False",
                  "set_focal_node_currents_to_zero = False",
                  "set_null_voltages_to_nodata = False",
                  "compress_grids = False",
                  "write_cur_maps = True",
                  "write_volt_maps = False",
                  paste("output_file = ",gsub(".asc",".csv",rasterfile),sep=""),
                  "write_cum_cur_map_only = True",
                  "log_transform_maps = False",
                  "write_max_cur_maps = False",
                  "",
                  "[Version]",
                  "version = unknown",
                  "",
                  "[Options for reclassification of habitat data]",
                  "reclass_file = (Browse for file with reclassification data)",
                  "use_reclass_table = False",
                  "",
                  "[Logging Options]",
                  "log_level = INFO",
                  "log_file = None",
                  "profiler_log_file = None",
                  "screenprint_log = True",
                  "",
                  "[Options for pairwise and one-to-all and all-to-one modes]",
                  "included_pairs_file = None",
                  "use_included_pairs = False",
                  paste("point_file =",cluster_point_file_path),
                  "",
                  "[Connection scheme for raster habitat data]",
                  "connect_using_avg_resistances = True",
                  "connect_four_neighbors_only = False",
                  
                  "[Habitat raster or graph]",
                  "habitat_map_is_resistances = False",
                  paste("habitat_file = ",rasterfile,sep=""),
                  "",
                  "[Circuitscape mode]",
                  "data_type = raster",
                  "scenario = pairwise",
                  "")
    writeLines(ini_text,paste(gsub(".asc","",rasterfile),".ini",sep=""))
  }
  
  # JL
  create_circuitscape_jlfile <- function(coordinates,rasterfile)
  {
    ini_file <- gsub('asc','ini',rasterfile)
    ini_text <- NULL
    ini_text <- c('using Pkg',
                  'Pkg.add("Circuitscape")',
                  'using Circuitscape',
                  paste0('compute("',ini_file,'")'),
                  "")
    writeLines(ini_text,paste(gsub(".asc","",rasterfile),".jl",sep=""))
  }
  
  
  ############################
  # Create circuitscape ini,jl files
  
  # read args
  args <- commandArgs()
  print(args)
  species_binomial <- args[8]  # This may vary between systems depending on your HPC setup, the list of arguments will be printed at the beginning of your SLURM job logfile so if the jobs fail, make sure that this number matches the number in args[] that matches your species name
  
  # set params file
  params_all <- read.delim('./Params.tsv')
  
  # Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
  params <- params_all[which(params_all$species_binomial==species_binomial),]
  species_binomial <- params$species_binomial
  
  log_file <- paste0('./-outputs-/log_files/',species_binomial,'.log')
  output_path <- paste0('-outputs-/',species_binomial,'/Landscape_barriers/')
  current_env_data_path <- paste0('-data-/spatial_data/',species_binomial,'/current_climate/')
  future_env_data_path <- paste0('-data-/spatial_data/',species_binomial,'/future_climate/')
  circuitscape_path <- paste0(output_path,'/circuitscape/')
  dir.create(output_path)
  dir.create(circuitscape_path)
  
  cat('--------------------------------------------------------------\n', file=log_file, append=T)
  cat('Creating Circuitscape *.ini and *.jl files...\n', file=log_file, append=T)
  cat('--------------------------------------------------------------\n', file=log_file, append=T)
  
  # make circuitscape directory and copy sdm files there
#  cat('> Copying SDMs (current and future)...', file=log_file, append=T)
#  cat(' DONE!\n', file=log_file, append=T)
#  file.copy(paste0('./-outputs-/',species_binomial,'/Exposure/SDMs/',species_binomial,'_ensemble_SDM_current.asc'), paste0(output_path,'/circuitscape/'), recursive=TRUE)
#  file.copy(paste0('./-outputs-/',species_binomial,'/Exposure/SDMs/',species_binomial,'_ensemble_SDM_future.asc'), paste0(output_path,'/circuitscape/'), recursive=TRUE)

    
  # if required, change suitabilities of 0 to 0.0001 (i.e. not complete barriers which will throw out -9's for connectivity values from circuitscape)
  # (this drastically increases circuitscape runtime)
  # if(params$circuitscape_transform_zeros=='yes'){
  #   current <- raster(paste0('./-outputs-/',species_binomial,'/Exposure/SDMs/',species_binomial,'_ensemble_SDM_current.asc'))
  #   future <- raster(paste0('./-outputs-/',species_binomial,'/Exposure/SDMs/',species_binomial,'_ensemble_SDM_future.asc'))
  #   current[current==0] <- 0.001
  #   future[future==0] <- 0.001
  #   writeRaster(current,paste0(output_path,'/circuitscape/',species_binomial,'_ensemble_SDM_current.asc'), overwrite=TRUE)
  #   writeRaster(future,paste0(output_path,'/circuitscape/',species_binomial,'_ensemble_SDM_future.asc'), overwrite=TRUE)
  # } else {
  #   current <- raster(paste0('./-outputs-/',species_binomial,'/Exposure/SDMs/',species_binomial,'_ensemble_SDM_current.asc'))
  #   future <- raster(paste0('./-outputs-/',species_binomial,'/Exposure/SDMs/',species_binomial,'_ensemble_SDM_future.asc'))
  # }
  # 
  # make circuitscape points file from geo-coordinates (from genomic data)
  cat('> Creating points file from georeferenced genomic samples...', file=log_file, append=T)
  points <- read.csv(paste0('./-data-/spatial_data/',species_binomial,'/',species_binomial,'_samples.csv')) # read spatial occurrences
  points <- as.data.frame(cbind(1:nrow(points),points$LONG, points$LAT)) # reorganise columns so that it is a 3 column df: (1: number of samples, long, lat)
  write_tsv(points, paste0(circuitscape_path,species_binomial,'_circuitscape_points.txt'), col_names = FALSE)
  cat(' DONE!\n', file=log_file, append=T)
  
  input.dir = (paste0(circuitscape_path))
  file.pattern    <- '*.asc$'  #regex
  
# This will run if you have not chosen to skip circuitscape layer parameterisation
  cat('> Parameterising circuitscape input resistance layer...', file=log_file, append=T)
if (params$skip_circuitscape_layer_parameterisation!='yes'){  

  # The below code will prepare resistance surfaces as standard, all ranging from 0 (no resistance) to a maximum value of resistance (i.e. a barrier)
  # it is typically scaled between 0 (connected) and 100 (barrier)
  # these are then combined into a single circuitscape surface for resistance modelling based on the information supplied in the params file for circuitscape_layers and circuitscape_weights
  # the landcov variables are recategorised land cover based on forest being least reistant than other land cover types
  # but you can recategorise in other ways depending on your species ecology
  
  
# if loop here to do these below only if they are included in the circuitscape_layers list
circuitscape_layers <- params$circuitscape_layers

if (grepl("current_sdm", circuitscape_layers)){
  # first read in the relevant layers that already exist
  current_sdm <- raster(paste0('./-outputs-/',species_binomial,'/Exposure/SDMs/',species_binomial,'_ensemble_SDM_current.asc')) # already scaled between 0 and 1
  
  #scale the sdm
  current_sdm_resistance <- current_sdm*100
  current_sdm_resistance  <- 100-current_sdm_resistance
  writeRaster(current_sdm_resistance, paste0('./-outputs-/',species_binomial,'/Landscape_barriers/circuitscape/current_sdm_resistance.asc'), overwrite=TRUE)
}

if (grepl("landcov", circuitscape_layers)){
  land_cover <- raster(paste0('./-data-/spatial_data/',species_binomial,'/current_climate/land_cover.tif'))

  # landcov1_resistance - 1=conifer/broadleaf;5=broadleaf/conifer;10=mosaic forest;20=mosaic; 40=shrub & grass; 50=crops & water;60=bare; 75=urban 
  m <- c(11,50, 14,50, 20,10, 30,10, 40,5, 50,5, 60,5, 70,1, 90,1, 100,5, 110,20, 120,20, 130,40, 140,40, 150,50, 160,50, 170,50, 180,50, 190,75, 200,60, 210,NA, 220,NA, 230,NA)
  rclmat <- matrix(m, ncol=2, byrow=TRUE)
  landcov1_resistance <- reclassify(land_cover, rclmat)
  writeRaster(landcov1_resistance, paste0('./-outputs-/',species_binomial,'/Landscape_barriers/circuitscape/landcov1_resistance.asc'), overwrite=TRUE)
   
  # landcov2_resistance - 1=conifer/broadleaf;5=broadleaf/conifer;10=mosaic forest;20=mosaic; 50=other land cover
  m <- c(11,50, 14,50, 20,10, 30,10, 40,5, 50,5, 60,5, 70,1, 90,1, 100,5, 110,20, 120,20, 130,50, 140,50, 150,50, 160,50, 170,50, 180,50, 190,50, 200,50, 210,NA, 220,50, 230,50)
  rclmat <- matrix(m, ncol=2, byrow=TRUE)
  landcov2_resistance <- reclassify(land_cover, rclmat)
  writeRaster(landcov2_resistance, paste0('./-outputs-/',species_binomial,'/Landscape_barriers/circuitscape/landcov2_resistance.asc'), overwrite=TRUE)
  
  # landcov3_resistance - 1=conifer/broadleaf;5=broadleaf/conifer;10=mosaic forest;20=mosaic; 100=other land cover 
  m <- c(11,100, 14,100, 20,10, 30,10, 40,5, 50,5, 60,5, 70,1, 90,1, 100,5, 110,20, 120,20, 130,100, 140,100, 150,100, 160,100, 170,100, 180,100, 190,100, 200,100, 210,NA, 220,100, 230,100)
  rclmat <- matrix(m, ncol=2, byrow=TRUE)
  landcov3_resistance <- reclassify(land_cover, rclmat)
  writeRaster(landcov3_resistance, paste0('./-outputs-/',species_binomial,'/Landscape_barriers/circuitscape/landcov3_resistance.asc'), overwrite=TRUE)
}  
    
if (grepl("slope", circuitscape_layers)){
   slope <- raster(paste0('./-data-/spatial_data/',species_binomial,'/current_climate/slope.tif'))

 #rescale slope
  slope.min <- minValue(slope)
  slope.max <- maxValue(slope)
  slope_resistance <- ((slope - slope.min) / (slope.max - slope.min) - 0 ) * 1
  slope_resistance[slope_resistance == 0] <- NA
  slope_resistance[slope_resistance > 1] <- 1
  slope_resistance <- slope_resistance*100
  writeRaster(slope_resistance, paste0('./-outputs-/',species_binomial,'/Landscape_barriers/circuitscape/slope_resistance.asc'), overwrite=TRUE)
}  
   
 for (layer in c('bioclim_1','bioclim_2','bioclim_3','bioclim_4','bioclim_5','bioclim_6','bioclim_7','bioclim_8','bioclim_9','bioclim_10','bioclim_11','bioclim_12','bioclim_13','bioclim_14','bioclim_15','bioclim_16','bioclim_17','bioclim_18','bioclim_19')){   
   #if (grepl(layer, circuitscape_layers)){
   layer_name <- raster(paste0('./-data-/spatial_data/',species_binomial,'/current_climate/',layer,'.tif'))   
 
  #rescale
   layer_name.min <- minValue(layer_name)
   layer_name.max <- maxValue(layer_name)
   layer_name_resistance <- ((layer_name - layer_name.min) / (layer_name.max - layer_name.min) - 0 ) * 1
   layer_name_resistance[layer_name_resistance == 0] <- NA
   layer_name_resistance[layer_name_resistance > 1] <- 1
   layer_name_resistance <- layer_name_resistance*100
   writeRaster(layer_name_resistance, paste0('./-outputs-/',species_binomial,'/Landscape_barriers/circuitscape/',layer,'_resistance.asc'), overwrite=TRUE)
   
   # read in raster per layer to make sure it is in memory, otherwise is overwritten
   lhs <- paste0(layer,'_resistance')
   rhs <-  paste0("raster('./-data-/spatial_data/",species_binomial,"/current_climate/",layer,".tif')") # already scaled between 0 and 1
   eq <- paste(paste(lhs, rhs, sep=' <- '), collapse='; ')
   eval(parse(text=eq))
 
 #  }
  }

  # Finally, generate the layer with all the information combined
  # this can be scaled as you wish, e.g. by supplying circuitscape_weights looking externally in ResistanceGA 
  
# match the env_predictor_1 and env_predictor_2 to your environmental variables
env_1_resistance <- eval(parse(text=paste0(params$env_predictor_1,'_resistance'))) 
env_2_resistance <- eval(parse(text=paste0(params$env_predictor_2,'_resistance'))) 

  # read the resistance layers to be used in the cumulative circuitscape resistance surface
  layers <- eval(parse(text=paste0("c(",params$circuitscape_layers,")")))
  layers <- stack(layers)
  
  # read in the weights you wish to assign to each layer
  weights <- eval(parse(text=paste0("c(",params$circuitscape_weights,")")))
  weights <- as.numeric(weights)
  
# separate the layer names
layers_separated <- c(params$circuitscape_layers)
layers_separated <- unlist(strsplit(layers_separated, ","))

# Flexible code to take in any number of layers and add them up (defined by the number of layers defined in the circuitscape_layers and circuitscape_weights in params file)
  for (i in 1:length(layers_separated)) {# will give the relevant layer and weights for each layer
    lhs1  <- paste0('weighted_layer_',i, sep='')
    rhs1  <- paste0('(eval(parse(text=layers_separated[', i, ']))*weights[',i,'])',    sep='')
    eq1   <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
    eval(parse(text=eq1))
}

# get these variable names and create string to add them (separated by "+")
weighted_layers <- ls(pattern = "weighted_layer_")
text <- paste0(weighted_layers)
text <- toString(text)
text <- gsub(',',' +',text)

cumulative_circuitscape_layer <- eval(parse(text=paste0(text)))

# scale final cumulative raster to ensure it ranges between 0 (connected) and 100 (barrier)
library(terra)
cumulative_circuitscape_layer <- rast(cumulative_circuitscape_layer)
minmax <- minmax(cumulative_circuitscape_layer)    
cumulative_circuitscape_layer <- (cumulative_circuitscape_layer - minmax[1,]) / (minmax[2,] - minmax[1,])
cumulative_circuitscape_layer <- cumulative_circuitscape_layer * 100

# write out file
writeRaster(cumulative_circuitscape_layer, paste0('./-outputs-/',species_binomial,'/Landscape_barriers/circuitscape/cumulative_circuitscape_layer.asc'), overwrite=TRUE)

# plot all layers that you have parameterised as well as the cumulative reistance surface
# Flexible code to plot any number of layers (defined by the number of layers defined in the circuitscape_layers and circuitscape_weights in params file)
  
  lhs1  <- paste0("plot(",paste0(layers_separated),", main=",paste0("'",layers_separated,",")," weight=",paste0(weights,"')", sep=''))
  
  png(paste0('./-outputs-/',species_binomial,'/Landscape_barriers/circuitscape/circuitscape_layers.png'), type='cairo', units='cm', width=45, height=45, pointsize=12, res=300)
  par(cex.main=2.5, cex.axis=2.5, cex.lab=2.5)
  par(mar=c(5,5,5,12))
 # calculate size of plot items required for your layers
 number_of_panels_required <- length(layers_separated)
 sqrt_panels <- sqrt(number_of_panels_required)
 sqrt_panels <- ceiling(sqrt_panels) # round up
 par(mfrow=c(sqrt_panels,sqrt_panels))
  # plot each scaled resistance layer defined by circuitscape_layers in params file
  for (i in 1:length(layers_separated)) {eval(parse(text=lhs1[i]))
  g <- terra::graticule(5, 5, crs="+proj=latlon") # every 5 degreees
  plot(g, background=NULL, col="grey65", lty=2, retro=TRUE, add=TRUE)
  terra::north()
}
  dev.off()
  
  
  # plot the cumulative weighted resistance layer defined by circuitscape_weights
   png(paste0('./-outputs-/',species_binomial,'/Landscape_barriers/circuitscape/circuitscape_cumulative_layer.png'), type='cairo', units='cm', width=30, height=30, pointsize=28, res=300)
    par(cex.main=3, cex.axis=3, cex.lab=3)
    par(mar=c(5,5,5,5))
    par(mfrow=c(1,1))
	plot(cumulative_circuitscape_layer, main='Cumulative circuitscape layer')
    g <- terra::graticule(5, 5, crs="+proj=latlon") # every 5 degreees
    plot(g, background=NULL, col="grey65", lty=2, retro=TRUE, add=TRUE)
    terra::north()
   dev.off()

  cat('> Circuitscape input resistance layer saved...', file=log_file, append=T)
 

  # write the parameterized cumulative layer out
  # read them in again, plot to show
  
  file.pattern    <- '*cumulative_circuitscape_layer.asc$'  #regex
  rasterfile = list.files(path=input.dir, pattern=file.pattern, full.names=TRUE, recursive=FALSE, ignore.case=TRUE, include.dirs=FALSE)
  rastername_only = list.files(path=input.dir, pattern=file.pattern, full.names=FALSE, recursive=FALSE, ignore.case=TRUE, include.dirs=FALSE)
  
  file.pattern_ini <- gsub('asc','ini',rasterfile)
  #inifile = list.files(path=input.dir, pattern=file.pattern_ini, full.names=TRUE, recursive=FALSE, ignore.case=TRUE, include.dirs=FALSE)
  
  cluster_output_file_path <- paste0(circuitscape_path)
  cluster_point_file_path <- paste0(circuitscape_path,species_binomial,'_circuitscape_points.txt')
  cluster_habitat_file_path <- paste0(circuitscape_path)
  
  rasterstack <- stack(rasterfile)

  coordinates <- paste0(circuitscape_path,species_binomial,'_circuitscape_points.txt')
  
    cat('> Creating Circuitscape *.ini file...', file=log_file, append=T)
    create_circuitscape_inifile(coordinates,rasterfile)
    cat('> DONE!\n', file=log_file, append=T)
    cat('> Creating Circuitscape *.jl file...', file=log_file, append=T)
    create_circuitscape_jlfile(coordinates,rasterfile)
    cat('> DONE!\n', file=log_file, append=T)
  
  cat('> Circuitscape files created successfully...\n\n', file=log_file, append=T)
  
  } else {
      cat('Skipping Circuitscape input resistance layer parameterisation as it has been performed outside of the LotE toolbox...\n\n', file=log_file, append=T)
}

}

#############################################################################################################################################################################################
landscape_barriers <- function(species_binomial) {
#############################################################################################################################################################################################
  
  # Calculate 'Landscape barriers' across populations
  
  library(raster)
  library(viridis)
  library(rgdal)
  
  rm(list=ls(all=TRUE))
  
  root_dir <- ('$YOUR_WORK_DIR')
  setwd(root_dir)
  
  # read args
  args <- commandArgs()
  print(args)
  species_binomial <- args[8]  # This may vary between systems depending on your HPC setup, the list of arguments will be printed at the beginning of your SLURM job logfile so if the jobs fail, make sure that this number matches the number in args[] that matches your species name
 
  # set params file
  params_all <- read.delim('./Params.tsv')
  
  # Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
  params <- params_all[which(params_all$species_binomial==species_binomial),]
  species_binomial <- params$species_binomial
  
  spatial_dir <- paste0('-data-/spatial_data/',species_binomial,'/')
  log_file <- paste0('-outputs-/log_files/',species_binomial,'.log')
  
  ############################
  # Calculate landscape barriers
  
  cat('--------------------------------------------------------------\n', file=log_file, append=T)
  cat('Calculating Landscape barriers for each population based on Circuitscape outputs...\n', file=log_file, append=T)
  cat('--------------------------------------------------------------\n', file=log_file, append=T)
  
  # colour scheme from viridis package
  viridis <- viridis(50, alpha = 1, begin = 0.2, end = 0.9, direction = 1, option = "D")
  
  # now check outputs
  circuitscape_output <- raster(paste0('-outputs-/',species_binomial,'/Landscape_barriers/circuitscape/cumulative_circuitscape_layer.csv_cum_curmap.asc'))

  samples <- read.csv(paste0('-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_adaptive_sensitivity.csv'))
  samples <- unique(samples[,1:2])
  coordinates(samples) <- ~ LONG + LAT
  
  circuitscape_output.min <- min(values(circuitscape_output))
  circuitscape_output.max <- max(values(circuitscape_output))
  circuitscape_output.max <- circuitscape_output.max/10
  output_scale <- ((circuitscape_output - circuitscape_output.min) / (circuitscape_output.max - circuitscape_output.min) - 0 ) * 1
  output_scale[output_scale == 0] <- NA
  output_scale[output_scale > 1] <- 1
  
  # plot
  world_shapefile <- readOGR(paste0(root_dir,'./-data-/map_data/ne_50m_admin_0_countries.shp'))
  xmin <- circuitscape_output[[1]]@extent@xmin
  xmax <- circuitscape_output[[1]]@extent@xmax
  ymin <- circuitscape_output[[1]]@extent@ymin
  ymax <- circuitscape_output[[1]]@extent@ymax
  lhs <- paste0('cropped_shapefile')
  rhs <- paste0('crop(world_shapefile, extent(',xmin,',',xmax,',',ymin,',',ymax,'))')
  eq <- paste(paste(lhs, rhs, sep=' <- '), collapse='; ')
  eval(parse(text=eq))
  
  png(filename=paste0('-outputs-/',species_binomial,'/Landscape_barriers/circuitscape/',species_binomial,'_circuitscape_landscape_connectivity.png'), 
      type='cairo', units='cm', width=40, height=30, pointsize=20, res=300)
  par(mfrow=c(1,1))
  plot(output_scale, col=viridis, zlim=c(0,1), main = 'Circuitscape landscape connectivity')
  points(samples, col="darkorange1", pch=19, cex=0.5, add=T)
  plot(cropped_shapefile, lwd=1.4, add=T)
  g <- terra::graticule(5, 5, crs="+proj=latlon") # every 5 degreees
  plot(g, background=NULL, col="grey65", lty=2, retro=TRUE, add=TRUE)
  terra::north()
  dev.off()
  
  cat('> Plotted Circuitscape landscape connectivity map... \n', file=log_file, append=T)
  
  # now calculate landscape barriers
  #read in the circuitscape 3 columns out (raw untransformed outputs)
  results <- read.csv(paste0('-outputs-/',species_binomial,'/Landscape_barriers/circuitscape/cumulative_circuitscape_layer.csv_resistances_3columns.out'), sep =' ', header=FALSE)
  colnames(results) <- c('pop1', 'pop2', 'connectivity')
  
  max_dispersal_distance_km <- params$max_dispersal_distance_km # reading from params file
  
  # calculate distances in km 
  library(sp)
  
  samples <- read.csv(paste0('-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_adaptive_sensitivity.csv'))
  
  samples <- cbind(samples$LONG, samples$LAT) # in case they are in the wrong order
  distances <- (spDists(samples, longlat = TRUE))
  
  samples <- read.csv(paste0('-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_adaptive_sensitivity.csv'))
  
  row.names(distances) <- samples$POP_ID
  colnames(distances) <-  samples$POP_ID
  
  # Subset the output predictions  
  # store the distances
  for (i in 1:nrow(samples)) {# should be samples$POP_ID because if there are missing pops it will mess up
    lhs1  <- paste0('pop_', i,     sep='')
    rhs1  <- paste0('distances[,', i,']', sep='')
    eq1   <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
    eval(parse(text=eq1))
    #retain list of populations which are within the distance of the specified max_dispersal_distance_km variable
    lhs2  <- paste0('pop_filtered_', i,     sep='')
    rhs2  <- paste0('names(which(pop_',i,' <',max_dispersal_distance_km,'))' , sep='')
    eq2   <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
    eval(parse(text=eq2))
    
    # flag the corresponding instances in the output results dataframe to keep  
    lhs3  <- paste0('pop_', i, '_keep_list',     sep='')
    rhs3  <- paste0('results$pop1 %in% pop_filtered_',i, '| results$pop2 %in% pop_filtered_',i, sep='')
    eq3   <- paste(paste(lhs3, rhs3, sep=' <- '), collapse='; ')
    eval(parse(text=eq3))
    
    # then subset the dataframe based on those flags
    lhs4  <- paste0('pop_', i, '_connectivity',     sep='')
    rhs4  <- paste0('results[c(pop_',i,'_keep_list), ]', sep='') #  rhs4
    eq4   <- paste(paste(lhs4, rhs4, sep=' <- '), collapse='; ')
    eval(parse(text=eq4))
    
    lhs5  <- paste0('pop_', i, '_connectivity_mean',     sep='')
    rhs5  <- paste0('mean(pop_',i,'_connectivity$connectivity)', sep='') #  rhs4
    eq5   <- paste(paste(lhs5, rhs5, sep=' <- '), collapse='; ')
    eval(parse(text=eq5))
  }
  
  
  #list pattern output_mean_pop and create a dataframe with the mean connectivity per pop 
  output_mean_pops <- mget(ls(pattern = "_connectivity_mean"))
  output_mean_pops <- as.data.frame(output_mean_pops)
  output_mean_pops <- t(output_mean_pops)
  
  samples <- read.csv(paste0('-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_adaptive_sensitivity.csv'))
  samples <- unique(samples[,1:2])
  mean_connectivity_pops <- as.data.frame(cbind(samples,output_mean_pops))
  colnames(mean_connectivity_pops) <- c('LAT','LONG','mean_connectivity')
  
  # normalise the connectivity scores between 0 and 1
  # this forms the basis of our metric
  mean_connectivity_pops$mean_connectivity_normalised <-  (mean_connectivity_pops$mean_connectivity-min(mean_connectivity_pops$mean_connectivity))/(max(mean_connectivity_pops$mean_connectivity)-min(mean_connectivity_pops$mean_connectivity))

  # if all same, then set all to '5'
  if (length(unique(mean_connectivity_pops$mean_connectivity_normalised)) == '1') {
    landscape_barriers <- 5
    
    #bind to the final dataframe and write out
    landscape_barriers <- cbind(mean_connectivity_pops,landscape_barriers)
    colnames(landscape_barriers) <- c('LAT','LONG','mean_connectivity','mean_connectivity_normalised','landscape_barriers')
    write.csv(landscape_barriers, paste0('-outputs-/',species_binomial,'/Landscape_barriers/',species_binomial,'_Landscape_barriers.csv'))
    
  }else{
    # get the quantiles of the data
    q1 <- as.numeric(quantile(mean_connectivity_pops$mean_connectivity_normalised, probs=0.1))
    q2 <- as.numeric(quantile(mean_connectivity_pops$mean_connectivity_normalised, probs=0.2))
    q3 <- as.numeric(quantile(mean_connectivity_pops$mean_connectivity_normalised, probs=0.3))
    q4 <- as.numeric(quantile(mean_connectivity_pops$mean_connectivity_normalised, probs=0.4))
    q5 <- as.numeric(quantile(mean_connectivity_pops$mean_connectivity_normalised, probs=0.5))
    q6 <- as.numeric(quantile(mean_connectivity_pops$mean_connectivity_normalised, probs=0.6))
    q7 <- as.numeric(quantile(mean_connectivity_pops$mean_connectivity_normalised, probs=0.7))
    q8 <- as.numeric(quantile(mean_connectivity_pops$mean_connectivity_normalised, probs=0.8))
    q9 <- as.numeric(quantile(mean_connectivity_pops$mean_connectivity_normalised, probs=0.9))
    
    # get the intervals based on the range of the data
    lhs3.9.1 <- paste0('min', sep='')
    rhs3.9.1 <- paste0('min(mean_connectivity_pops$mean_connectivity_normalised)')
    eq3.9.1  <- paste(paste(lhs3.9.1, rhs3.9.1, sep=' <- '), collapse='; ')
    eval(parse(text=eq3.9.1))
    lhs3.9.1 <- paste0('max', sep='')
    rhs3.9.1 <- paste0('max(mean_connectivity_pops$mean_connectivity_normalised)')
    eq3.9.1  <- paste(paste(lhs3.9.1, rhs3.9.1, sep=' <- '), collapse='; ')
    eval(parse(text=eq3.9.1))
    range <- max-min
    increments <- range/10
    i10 <- min+0.0001
    i9 <- min+increments
    i8 <- i9+increments
    i7 <- i8+increments
    i6 <- i7+increments
    i5 <- i6+increments
    i4 <- i5+increments
    i3 <- i4+increments
    i2 <- i3+increments
    i1 <- i2+increments
    
    # use defined thresholds from params file
    thresholds <- params$landscape_barriers_thresholds
    thresholds <- as.data.frame(unlist(strsplit(thresholds,",")))
    thresholds$number <- c(1:10)
    colnames(thresholds) <- c('value','number')
    
    
    params$landscape_barriers_quantification <- 'defined'
    params$landscape_barriers_quantification <- 'interval'
    params$landscape_barriers_quantification <- 'quantile'
    # generate the scores based on the option selected - 'defined', 'interval', or 'quantile'
    if (params$landscape_barriers_quantification=='defined'){
      #defined
      landscape_barriers <- as.data.frame(findInterval(mean_connectivity_pops$mean_connectivity_normalised,c(as.numeric(thresholds$value))))
      landscape_barriers <- 10-landscape_barriers }else{
        if (params$landscape_barriers_quantification=='interval'){ 
          # interval
          landscape_barriers <- as.data.frame(findInterval(mean_connectivity_pops$mean_connectivity_normalised,(c(i10,i9,i8,i7,i6,i5,i4,i3,i2,i1))))
          landscape_barriers <- (10-landscape_barriers) }else{
            if (params$landscape_barriers_quantification=='quantile'){ 
              # quantile
              landscape_barriers <- as.data.frame(findInterval(mean_connectivity_pops$mean_connectivity_normalised,(c(q1,q2,q3,q4,q5,q6,q7,q8,q9))))
              landscape_barriers <- 10-landscape_barriers
            }
          }
       }
    #bind to the final dataframe and write out
    landscape_barriers <- cbind(mean_connectivity_pops,landscape_barriers)
    colnames(landscape_barriers) <- c('LAT','LONG','mean_connectivity','mean_connectivity_normalised','landscape_barriers')
    
    # round mean connectivity and the normalised versions to 2 dp
    landscape_barriers$mean_connectivity <- round(landscape_barriers$mean_connectivity, 2)
    landscape_barriers$mean_connectivity_normalised <- round(landscape_barriers$mean_connectivity_normalised, 2)

    write.csv(landscape_barriers, paste0('-outputs-/',species_binomial,'/Landscape_barriers/',species_binomial,'_Landscape_barriers.csv'))
  }
  
  cat('> Calculated landscape barriers metrics and wrote to file... \n', file=log_file, append=T)
  cat('> Landscape barriers analyses completed... \n\n', file=log_file, append=T)
  
}
  
#############################################################################################################################################################################################
population_vulnerability <- function(species_binomial) {
#############################################################################################################################################################################################
    
  # Quantify 'Population vulnerability' across populations by combining the Exposure, Sensitivity and Landscape barriers outputs
  # Create final output figures and tables
  
  library(rgdal)
  library(tmap)
  library(dplyr)
  library(spatstat)  # Used for the dirichlet tessellation function
  library(maptools)  # Used for conversion from SPDF to ppp
  library(raster)    # Used to clip out thiessen polygons
  library(sp)
  
  # Load genetic diversity  data
  rm(list=ls(all=TRUE))
  
  root_dir <- ('$YOUR_WORK_DIR')
  setwd(root_dir)
  
  # read args
  args <- commandArgs()
  print(args)
  species_binomial <- args[8]  # This may vary between systems depending on your HPC setup, the list of arguments will be printed at the beginning of your SLURM job logfile so if the jobs fail, make sure that this number matches the number in args[] that matches your species name
  
  # set params file
  params_all <- read.delim('./Params.tsv')
  
  # Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
  params <- params_all[which(params_all$species_binomial==species_binomial),]
  species_binomial <- params$species_binomial
  
  log_file <- paste0('-outputs-/log_files/',species_binomial,'.log')
  final_outputs <- paste0('-outputs-/',species_binomial,'/Population_vulnerability/')
  dir.create(final_outputs)
  
  cat('--------------------------------------------------------------\n', file=log_file, append=T)
  cat('Summarising analyses and generating final population vulnerability scores...\n', file=log_file, append=T)
  cat('--------------------------------------------------------------\n', file=log_file, append=T)
  
  exposure <- read.csv(paste0('-outputs-/',species_binomial,'/Exposure/',species_binomial,'_Exposure.csv'))
  sensitivity <- read.csv(paste0('-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_adaptive_sensitivity.csv')) # also contains neutral sensitivity
  landscape_barriers <- read.csv(paste0('-outputs-/',species_binomial,'/Landscape_barriers/',species_binomial,'_Landscape_barriers.csv'))
  
  colnames(exposure) <-c('LONG','LAT',paste0(params$env_predictor_1,'_current'),paste0(params$env_predictor_1,'_future'),paste0(params$env_predictor_2,'_current'),paste0(params$env_predictor_2,'_future'),'sdm_current','sdm_future','sdm_dissimilarity','i_sdm_change','i_final_sdm_change',paste0('ii_',params$env_predictor_1,'_diff'),paste0('ii_final_',params$env_predictor_1,'_diff'),paste0('iii_',params$env_predictor_2,'_diff'),paste0('iii_final_',params$env_predictor_2,'_diff'), 'exposure')
  
  # order them by LAT
  vulnerability <- cbind(exposure$LAT,exposure$LONG,exposure$exposure,sensitivity$neutral_sensitivity,sensitivity$adaptive_sensitivity,landscape_barriers$landscape_barriers)
  vulnerability <- as.data.frame(vulnerability)
  colnames(vulnerability) <- c('LAT','LONG','exposure','neutral_sensitivity','adaptive_sensitivity','landscape_barriers')

  # remove zeros for max min calculation - affects neutral sensitivity (in case of single individual populations where nucleotide diversity values are zero)
  vulnerability[vulnerability==0] <- NA
  # save max and min scores per population for later visualisations
   vulnerability_max_min <- as.data.frame(vulnerability)
    vulnerability_max_min$max <- colnames(vulnerability_max_min[,3:6])[apply( vulnerability_max_min[,3:6],1,which.max)]
    vulnerability_max_min$min <- colnames(vulnerability_max_min[,3:6])[apply( vulnerability_max_min[,3:6],1,which.min)]

  # remake vulnerability again for calculations
  # order them by LAT
  vulnerability <- cbind(exposure$LAT,exposure$LONG,exposure$exposure,sensitivity$neutral_sensitivity,sensitivity$adaptive_sensitivity,landscape_barriers$landscape_barriers)
  vulnerability <- as.data.frame(vulnerability)
  colnames(vulnerability) <- c('LAT','LONG','exposure','neutral_sensitivity','adaptive_sensitivity','landscape_barriers')

  #### Rules for calculations
  # Rules: calculating Population Vulnerability 
  # 0: Population vulnerability = mean score of Exposure, Neutral Sensitivity, Adaptive Sensitivity, Landscape barriers - accounting for columns containing zeros
  # 1: Population vulnerability = mean score of Exposure, Neutral Sensitivity, Adaptive Sensitivity, Landscape barriers
  # 2: Population vulnerability = 70% weighting Exposure, 10% rest each
  # 3: Population vulnerability = 70% weighting neutral sensitivity, 10% rest each
  # 4: Population vulnerability = 70% weighting adaptive sensitivity, 10% rest each
  # 5: Population vulnerability = 70% weighting Elandscape barriers, 10% rest each

if (params$pop_vulnerability_rule==0){
 non_zero_cols <- as.data.frame(rowSums(vulnerability[,3:6] > 0)) # count non zero columns
 colnames(non_zero_cols) <- c('non_zero_cols')
 vulnerability$population_vulnerability <- NA # create empty space first
 for (i in 1:nrow(vulnerability)){
 vulnerability$population_vulnerability[i] <- (vulnerability$exposure[i] + vulnerability$neutral_sensitivity[i] + vulnerability$adaptive_sensitivity[i] + vulnerability$landscape_barriers[i])/non_zero_cols[i,]
 cat('Population vulnerability calculated based on mean of Exposure, Neutral Sensitivity, Adaptive Sensitivity, and Landscape barriers (excluding zero-values)...\n', file=log_file, append=T)
 }
 }else{
    if (params$pop_vulnerability_rule==1){
    exposure_weighted <- (vulnerability$exposure/100)*25 # = 25%
    neutral_sensitivity_weighted <- (vulnerability$neutral_sensitivity/100)*25 # =25%
    adaptive_sensitivity_weighted <- (vulnerability$adaptive_sensitivity/100)*25 # = 25%
    landscape_barriers_weighted <- (vulnerability$landscape_barriers/100)*25 # = 25%
    vulnerability$population_vulnerability <- (exposure_weighted + neutral_sensitivity_weighted + adaptive_sensitivity_weighted + landscape_barriers_weighted)
    cat('Population vulnerability calculated based on mean of Exposure, Neutral Sensitivity, Adaptive Sensitivity, and Landscape barriers...\n', file=log_file, append=T)
  }else{
    if (params$pop_vulnerability_rule==2){
      exposure_weighted <- (vulnerability$exposure/100)*70 # = 70%
      neutral_sensitivity_weighted <- (vulnerability$neutral_sensitivity/100)*10 # =10%
      adaptive_sensitivity_weighted <- (vulnerability$adaptive_sensitivity/100)*10 # = 10%
      landscape_barriers_weighted <- (vulnerability$landscape_barriers/100)*10 # = 10%
      vulnerability$population_vulnerability <- (exposure_weighted + neutral_sensitivity_weighted + adaptive_sensitivity_weighted + landscape_barriers_weighted)
      cat('Population vulnerability calculated based on 70% weighting for Exposure, and 10% weighting each for Neutral Sensitivity, Adaptive Sensitivity, and Landscape barriers...\n', file=log_file, append=T)
    }else{
      if (params$pop_vulnerability_rule==3){
        exposure_weighted <- (vulnerability$exposure/100)*10 # = 10%
        neutral_sensitivity_weighted <- (vulnerability$neutral_sensitivity/100)*70 # =70%
        adaptive_sensitivity_weighted <- (vulnerability$adaptive_sensitivity/100)*10 # = 10%
        landscape_barriers_weighted <- (vulnerability$landscape_barriers/100)*10 # = 10%
        vulnerability$population_vulnerability <- (exposure_weighted + neutral_sensitivity_weighted + adaptive_sensitivity_weighted + landscape_barriers_weighted)
        cat('Population vulnerability calculated based on 70% weighting for Neutral sensitivity, and 10% weighting each for Exposure, Adaptive Sensitivity, and Landscape barriers...\n', file=log_file, append=T)
      }else{
        if (params$pop_vulnerability_rule==4){
          exposure_weighted <- (vulnerability$exposure/100)*10 # = 10%
          neutral_sensitivity_weighted <- (vulnerability$neutral_sensitivity/100)*10 # =10%
          adaptive_sensitivity_weighted <- (vulnerability$adaptive_sensitivity/100)*70 # = 70%
          landscape_barriers_weighted <- (vulnerability$landscape_barriers/100)*10 # = 10%
          vulnerability$population_vulnerability <- (exposure_weighted + neutral_sensitivity_weighted + adaptive_sensitivity_weighted + landscape_barriers_weighted)
          cat('Population vulnerability calculated based on 70% weighting for Adaptive sensitivity, and 10% weighting each for Exposure, Neutral Sensitivity, and Landscape barriers...\n', file=log_file, append=T)
        }else{
          if (params$pop_vulnerability_rule==5){
            exposure_weighted <- (vulnerability$exposure/100)*10 # = 10%
            neutral_sensitivity_weighted <- (vulnerability$neutral_sensitivity/100)*10 # =10%
            adaptive_sensitivity_weighted <- (vulnerability$adaptive_sensitivity/100)*10 # = 10%
            landscape_barriers_weighted <- (vulnerability$landscape_barriers/100)*70 # = 70%
            vulnerability$population_vulnerability <- (exposure_weighted + neutral_sensitivity_weighted + adaptive_sensitivity_weighted + landscape_barriers_weighted)
            cat('Population vulnerability calculated based on 70% weighting for Landscape barriers, and 10% weighting each for Exposure, Neutral Sensitivity, and Adaptive Sensitivity...\n', file=log_file, append=T)
          }}}}}}
  
  write.csv(vulnerability,paste0('-outputs-/',species_binomial,'/Population_vulnerability/',species_binomial,'_Population_vulnerability.csv'))
  
##### 
# now take quantiles of each metric
# first change all zeros to NA so they don't mess up the quantifications
# exposure
    exposure_q1 <- as.numeric(quantile(vulnerability$exposure, probs=0.1))
    exposure_q2 <- as.numeric(quantile(vulnerability$exposure, probs=0.2))
    exposure_q3 <- as.numeric(quantile(vulnerability$exposure, probs=0.3))
    exposure_q4 <- as.numeric(quantile(vulnerability$exposure, probs=0.4))
    exposure_q5 <- as.numeric(quantile(vulnerability$exposure, probs=0.5))
    exposure_q6 <- as.numeric(quantile(vulnerability$exposure, probs=0.6))
    exposure_q7 <- as.numeric(quantile(vulnerability$exposure, probs=0.7))
    exposure_q8 <- as.numeric(quantile(vulnerability$exposure, probs=0.8))
    exposure_q9 <- as.numeric(quantile(vulnerability$exposure, probs=0.9))
    exposure_q10 <- as.numeric(quantile(vulnerability$exposure, probs=1))
#which pops are within upper quantile?
exposure_upper_q <- vulnerability[which(vulnerability$exposure>=exposure_q8),]
exposure_lower_q <- vulnerability[which(vulnerability$exposure<=exposure_q2),]

# neutral_sensitivity
# make a subset of the dataframe here
neutral_sensitivity_zeros_removed <- vulnerability
neutral_sensitivity_zeros_removed[neutral_sensitivity_zeros_removed==0] <- NA
neutral_sensitivity_zeros_removed <- as.data.frame(neutral_sensitivity_zeros_removed)
neutral_sensitivity_zeros_removed <- na.omit(neutral_sensitivity_zeros_removed)

    neutral_q1 <- as.numeric(quantile(neutral_sensitivity_zeros_removed$neutral_sensitivity, probs=0.1))
    neutral_q2 <- as.numeric(quantile(neutral_sensitivity_zeros_removed$neutral_sensitivity, probs=0.2))
    neutral_q3 <- as.numeric(quantile(neutral_sensitivity_zeros_removed$neutral_sensitivity, probs=0.3))
    neutral_q4 <- as.numeric(quantile(neutral_sensitivity_zeros_removed$neutral_sensitivity, probs=0.4))
    neutral_q5 <- as.numeric(quantile(neutral_sensitivity_zeros_removed$neutral_sensitivity, probs=0.5))
    neutral_q6 <- as.numeric(quantile(neutral_sensitivity_zeros_removed$neutral_sensitivity, probs=0.6))
    neutral_q7 <- as.numeric(quantile(neutral_sensitivity_zeros_removed$neutral_sensitivity, probs=0.7))
    neutral_q8 <- as.numeric(quantile(neutral_sensitivity_zeros_removed$neutral_sensitivity, probs=0.8))
    neutral_q9 <- as.numeric(quantile(neutral_sensitivity_zeros_removed$neutral_sensitivity, probs=0.9))
    neutral_q10 <- as.numeric(quantile(neutral_sensitivity_zeros_removed$neutral_sensitivity, probs=1))
#which pops are within upper quantile?
neutral_sensitivity_upper_q <- neutral_sensitivity_zeros_removed[which(neutral_sensitivity_zeros_removed$neutral_sensitivity>=neutral_q8),]
neutral_sensitivity_lower_q <- neutral_sensitivity_zeros_removed[which(neutral_sensitivity_zeros_removed$neutral_sensitivity<=neutral_q2),]

# adaptive_sensitivity
    adaptive_q1 <- as.numeric(quantile(vulnerability$adaptive_sensitivity, probs=0.1))
    adaptive_q2 <- as.numeric(quantile(vulnerability$adaptive_sensitivity, probs=0.2))
    adaptive_q3 <- as.numeric(quantile(vulnerability$adaptive_sensitivity, probs=0.3))
    adaptive_q4 <- as.numeric(quantile(vulnerability$adaptive_sensitivity, probs=0.4))
    adaptive_q5 <- as.numeric(quantile(vulnerability$adaptive_sensitivity, probs=0.5))
    adaptive_q6 <- as.numeric(quantile(vulnerability$adaptive_sensitivity, probs=0.6))
    adaptive_q7 <- as.numeric(quantile(vulnerability$adaptive_sensitivity, probs=0.7))
    adaptive_q8 <- as.numeric(quantile(vulnerability$adaptive_sensitivity, probs=0.8))
    adaptive_q9 <- as.numeric(quantile(vulnerability$adaptive_sensitivity, probs=0.9))
    adaptive_q10 <- as.numeric(quantile(vulnerability$adaptive_sensitivity, probs=1))
#which pops are within upper quantile?
adaptive_sensitivity_upper_q <- vulnerability[which(vulnerability$adaptive_sensitivity>=adaptive_q8),]
adaptive_sensitivity_lower_q <- vulnerability[which(vulnerability$adaptive_sensitivity<=adaptive_q2),]

# landscape_barriers
    range_q1 <- as.numeric(quantile(vulnerability$landscape_barriers, probs=0.1))
    range_q2 <- as.numeric(quantile(vulnerability$landscape_barriers, probs=0.2))
    range_q3 <- as.numeric(quantile(vulnerability$landscape_barriers, probs=0.3))
    range_q4 <- as.numeric(quantile(vulnerability$landscape_barriers, probs=0.4))
    range_q5 <- as.numeric(quantile(vulnerability$landscape_barriers, probs=0.5))
    range_q6 <- as.numeric(quantile(vulnerability$landscape_barriers, probs=0.6))
    range_q7 <- as.numeric(quantile(vulnerability$landscape_barriers, probs=0.7))
    range_q8 <- as.numeric(quantile(vulnerability$landscape_barriers, probs=0.8))
    range_q9 <- as.numeric(quantile(vulnerability$landscape_barriers, probs=0.9))
    range_q10 <- as.numeric(quantile(vulnerability$landscape_barriers, probs=1))
#which pops are within upper quantile?
landscape_barriers_upper_q <- vulnerability[which(vulnerability$landscape_barriers>=range_q8),]
landscape_barriers_lower_q <- vulnerability[which(vulnerability$landscape_barriers<=range_q2),]


###
# plot interpolated maps
# define coords 
coordinates(exposure_upper_q) <- ~ LONG + LAT
coordinates(exposure_lower_q) <- ~ LONG + LAT
coordinates(neutral_sensitivity_upper_q) <- ~ LONG + LAT
coordinates(neutral_sensitivity_lower_q) <- ~ LONG + LAT
coordinates(adaptive_sensitivity_upper_q) <- ~ LONG + LAT
coordinates(adaptive_sensitivity_lower_q) <- ~ LONG + LAT
coordinates(landscape_barriers_upper_q) <- ~ LONG + LAT
coordinates(landscape_barriers_lower_q) <- ~ LONG + LAT
#coordinates(all_above_means) <- ~ LONG + LAT
#coordinates(all_below_means) <- ~ LONG + LAT

data("World")
  
  ##### pop vulnerability #######
  coordinates(vulnerability) <- ~ LONG + LAT
  
  # Load map
  current_climate_lst <- list.files(path=paste0('-data-/spatial_data/',species_binomial,'/current_climate'),pattern='.tif$',full.names = T)
  current_climate <- stack(current_climate_lst)
  world_shapefile <- readOGR('./-data-/map_data/ne_50m_admin_0_countries.shp')
  xmin <- current_climate[[1]]@extent@xmin; xmin <- xmin - 2
  xmax <- current_climate[[1]]@extent@xmax; xmax <- xmax + 2
  ymin <- current_climate[[1]]@extent@ymin; ymin <- ymin - 2
  ymax <- current_climate[[1]]@extent@ymax; ymax <- ymax + 2
  lhs <- paste0('cropped_shapefile')
  rhs <- paste0('crop(world_shapefile, extent(',xmin,',',xmax,',',ymin,',',ymax,'))')
  eq <- paste(paste(lhs, rhs, sep=' <- '), collapse='; ')
  eval(parse(text=eq))
  
  # Replace point boundary extent with that of our map
  vulnerability@bbox <- cropped_shapefile@bbox
  
  # Now plot Exposure, Neutral sensitivity, Adaptive Sensitivity, Landscape barriers and final population vulnerability
  
  # Exposure
  # plot the observed points
  
  sf::sf_use_s2(FALSE) # turn off spherical geometry s2 processing in sf - sometimes on large datasets this can cause problems
  tmap1 <- tm_shape(cropped_shapefile) + tm_polygons() +
    tm_shape(vulnerability) +
    tm_dots(col="exposure", shape=21, palette = "Oranges", style="cont", breaks=c(seq(1,10)), auto.palette.mapping = FALSE,
            title="", size=0.25) +
    tm_text("exposure", just="left", xmod=.5, size = 0.0001) + 
   	tm_layout(main.title = "Exposure - observed", main.title.position = "center", main.title.size=2.5) + 
    tm_legend(outside = TRUE, legend.text.size=1.3) +

    tm_shape(exposure_upper_q) +
    tm_dots(col="exposure", shape=1, palette = "orange2", style="cont", auto.palette.mapping = FALSE,
            title="", size=3, legend.show = FALSE) +
  
    tm_shape(exposure_lower_q) +
    tm_dots(col="exposure", shape=1, palette = "green4", style="cont", auto.palette.mapping = FALSE,
            title="", size=3, legend.show = FALSE) +
    tm_graticules(alpha=0.4)       
   tmap_save(tmap1, paste0(final_outputs,species_binomial,'_final_exposure_observed.png'), units='cm', width=30, height=30, asp=0)
   
  cat('> Exposure scores calculated, saved and plotted...\n', file=log_file, append=T)
  
  #Thiessen polygons
  #The Thiessen polygons (or proximity interpolation) can be created using spatstat’s dirichlet function.
  
  # Create a tessellated surface
  th  <-  as(dirichlet(as.ppp(vulnerability)), "SpatialPolygons")
  
  # The dirichlet function does not carry over projection information
  # requiring that this information be added manually
  proj4string(th) <- proj4string(vulnerability)
  
  # The tessellated surface does not store attribute information
  # from the point data layer. We'll use the over() function (from the sp
  # package) to join the point attributes to the tesselated surface via
  # a spatial join. The over() function creates a dataframe that will need to
  # be added to the `th` object thus creating a SpatialPolygonsDataFrame object
  th.z     <- over(th, vulnerability, fn=mean)
  th.spdf  <-  SpatialPolygonsDataFrame(th, th.z)
  
  # Finally, we'll clip the tessellated  surface to the Texas boundaries
  th.clp   <- raster::intersect(cropped_shapefile,th.spdf)
  
  # Map the data
  # png(filename=paste0('-outputs-/',species_binomial,'/',species_binomial,'_Thiessen_polygons.png'), type='cairo', units='cm', width=30, height=30, pointsize=10, res=300)
  # tm_shape(th.clp) + 
  #   tm_polygons(col="exposure", palette="-RdYlGn", auto.palette.mapping=FALSE, title="") +
  #   tm_layout(main.title = "Thiessen polygons", main.title.position = "center")
  # # tm_legend(legend.outside=TRUE)
  # dev.off()
  
  #IDW
  #The IDW output is a raster. This requires that we first create an empty raster grid, then interpolate the precipitation values to each unsampled grid cell. An IDW power value of 2 (idp=2.0) will be used.
  library(gstat) # Use gstat's idw routine
  library(sp)    # Used for the spsample function
  
  # Create an empty grid where n is the total number of cells
  grd              <- as.data.frame(spsample(vulnerability, "regular", n=1000000))
  names(grd)       <- c("X", "Y")
  coordinates(grd) <- c("X", "Y")
  gridded(grd)     <- TRUE  # Create SpatialPixel object
  fullgrid(grd)    <- TRUE  # Create SpatialGrid object
  
  # Add vulnerability's projection information to the empty grid
  proj4string(vulnerability) <- proj4string(vulnerability) # Temp fix until new proj env is adopted
  proj4string(grd) <- proj4string(vulnerability)
  
  # Interpolate the grid cells using a power value of 2 (idp=2.0)
  vulnerability.idw <- gstat::idw(exposure ~ 1, vulnerability, newdata=grd, idp=2.0)
  
  # Convert to raster object then clip
  r       <- raster(vulnerability.idw)
  r.m     <- mask(r, cropped_shapefile)
  
  # Plot
  tmap2 <- tm_shape(r.m) + 
    tm_raster(palette = "Oranges", style="cont", breaks=c(seq(1,10)), auto.palette.mapping = FALSE,
              title="") + 
    tm_shape(vulnerability) + tm_dots(size=0.25, shape=21) +
    tm_layout(main.title = "Exposure - interpolated", main.title.position = "center", main.title.size=2) + 
    tm_legend(outside = TRUE, legend.text.size=1.3) +
    tm_shape(cropped_shapefile) + tm_borders("grey20", lwd = .6)+ 
    tm_legend(outside = TRUE) +
     
     tm_shape(exposure_upper_q) +
    tm_dots(col="exposure", shape=1, palette = "orange2", style="cont", auto.palette.mapping = FALSE,
            title="", size=3, legend.show = FALSE) +
  
    tm_shape(exposure_lower_q) +
    tm_dots(col="exposure", shape=1, palette = "green4", style="cont", auto.palette.mapping = FALSE,
            title="", size=3, legend.show = FALSE) +
    tm_graticules(alpha=0.4)
tmap_save(tmap2, paste0(final_outputs,species_binomial,'_final_exposure_interpolated.png'), units='cm', width=30, height=30, asp=0)
    
  # Neutral sensitivity
  # plot the observed points
  tmap3 <- tm_shape(cropped_shapefile) + tm_polygons() +
    tm_shape(vulnerability) +
    tm_dots(col="neutral_sensitivity", shape=21, palette = "Purples", style="cont", breaks=c(seq(1,10)), auto.palette.mapping = FALSE,
            title="", size=0.25) +
    tm_text("neutral_sensitivity", just="left", xmod=.5, size = 0.0001) + 
    tm_layout(main.title = "Neutral sensitivity - observed", main.title.position = "center", main.title.size=2.5) + 
    tm_legend(outside = TRUE, legend.text.size=1.3) + 
    tm_legend(outside = TRUE) +
    
    tm_shape(neutral_sensitivity_upper_q) +
    tm_dots(col="neutral_sensitivity", shape=1, palette = "orange2", style="cont", auto.palette.mapping = FALSE,
            title="", size=3, legend.show = FALSE) +
  
    tm_shape(neutral_sensitivity_lower_q) +
    tm_dots(col="neutral_sensitivity", shape=1, palette = "green4", style="cont", auto.palette.mapping = FALSE,
            title="", size=3, legend.show = FALSE) +
    tm_graticules(alpha=0.4) 
tmap_save(tmap3, paste0(final_outputs,species_binomial,'_final_neutral_sensitivity_observed.png'), units='cm', width=30, height=30, asp=0)
  
  cat('> Neutral sensitivity scores calculated, saved and plotted...\n', file=log_file, append=T)
  
  #Thiessen polygons
  #The Thiessen polygons (or proximity interpolation) can be created using spatstat’s dirichlet function.
  
  # Create a tessellated surface
  th  <-  as(dirichlet(as.ppp(vulnerability)), "SpatialPolygons")
  
  # The dirichlet function does not carry over projection information
  # requiring that this information be added manually
  proj4string(th) <- proj4string(vulnerability)
  
  # The tessellated surface does not store attribute information
  # from the point data layer. We'll use the over() function (from the sp
  # package) to join the point attributes to the tesselated surface via
  # a spatial join. The over() function creates a dataframe that will need to
  # be added to the `th` object thus creating a SpatialPolygonsDataFrame object
  th.z     <- over(th, vulnerability, fn=mean)
  th.spdf  <-  SpatialPolygonsDataFrame(th, th.z)
  
  # Finally, we'll clip the tessellated  surface to the Texas boundaries
  th.clp   <- raster::intersect(cropped_shapefile,th.spdf)
  
  # Map the data
  # png(filename=paste0('-outputs-/',species_binomial,'/',species_binomial,'_Thiessen_polygons.png'), type='cairo', units='cm', width=30, height=30, pointsize=10, res=300)
  # tm_shape(th.clp) + 
  #   tm_polygons(col="neutral_sensitivity", palette="-RdYlGn", auto.palette.mapping=FALSE, title="") +
  #   tm_layout(main.title = "Thiessen polygons", main.title.position = "center")
  # # tm_legend(legend.outside=TRUE)
  # dev.off()
  
  #IDW
  #The IDW output is a raster. This requires that we first create an empty raster grid, then interpolate the precipitation values to each unsampled grid cell. An IDW power value of 2 (idp=2.0) will be used.
  library(gstat) # Use gstat's idw routine
  library(sp)    # Used for the spsample function
  
  # Create an empty grid where n is the total number of cells
  grd              <- as.data.frame(spsample(vulnerability, "regular", n=1000000))
  names(grd)       <- c("X", "Y")
  coordinates(grd) <- c("X", "Y")
  gridded(grd)     <- TRUE  # Create SpatialPixel object
  fullgrid(grd)    <- TRUE  # Create SpatialGrid object
  
  # Add vulnerability's projection information to the empty grid
  proj4string(vulnerability) <- proj4string(vulnerability) # Temp fix until new proj env is adopted
  proj4string(grd) <- proj4string(vulnerability)
  
  # Interpolate the grid cells using a power value of 2 (idp=2.0)
  vulnerability.idw <- gstat::idw(neutral_sensitivity ~ 1, vulnerability, newdata=grd, idp=2.0)
  
  # Convert to raster object then clip to Texas
  r       <- raster(vulnerability.idw)
  r.m     <- mask(r, cropped_shapefile)
  
  # Plot
  tmap4 <- tm_shape(r.m) + 
    tm_raster(palette = "Purples", style="cont", breaks=c(seq(1,10)), auto.palette.mapping = FALSE,
              title="") + 
    tm_shape(vulnerability) + tm_dots(size=0.25, shape=21) +
    tm_layout(main.title = "Neutral sensitivity - interpolated", main.title.position = "center", main.title.size=2) + 
    tm_legend(outside = TRUE, legend.text.size=1.3) +
    tm_shape(cropped_shapefile) + tm_borders("grey20", lwd = .6)+ 
    tm_legend(outside = TRUE) +
    
  	tm_shape(neutral_sensitivity_upper_q) +
    tm_dots(col="neutral_sensitivity", shape=1, palette = "orange2", style="cont", auto.palette.mapping = FALSE,
            title="", size=3, legend.show = FALSE) +
  
    tm_shape(neutral_sensitivity_lower_q) +
    tm_dots(col="neutral_sensitivity", shape=1, palette = "green4", style="cont", auto.palette.mapping = FALSE,
            title="", size=3, legend.show = FALSE) +
    tm_graticules(alpha=0.4) 
  tmap_save(tmap4, paste0(final_outputs,species_binomial,'_final_neutral_sensitivity_interpolated.png'), units='cm', width=30, height=30, asp=0)
    
  # Adaptive sensitivity
  # plot the observed points
  tmap5 <- tm_shape(cropped_shapefile) + tm_polygons() +
    tm_shape(vulnerability) +
    tm_dots(col="adaptive_sensitivity", shape=21, palette = "Greens", style="cont", breaks=c(seq(1,10)), auto.palette.mapping = FALSE,
            title="", size=0.25) +
    tm_text("adaptive_sensitivity", just="left", xmod=.5, size = 0.0001) + 
    tm_layout(main.title = "Adaptive sensitivity - observed", main.title.position = "center", main.title.size=2.5) + 
    tm_legend(outside = TRUE, legend.text.size=1.3) + 
    tm_legend(outside = TRUE) +

 	tm_shape(adaptive_sensitivity_upper_q) +
    tm_dots(col="adaptive_sensitivity", shape=1, palette = "orange2", style="cont", auto.palette.mapping = FALSE,
            title="", size=3, legend.show = FALSE) +
  
    tm_shape(adaptive_sensitivity_lower_q) +
    tm_dots(col="adaptive_sensitivity", shape=1, palette = "green4", style="cont", auto.palette.mapping = FALSE,
            title="", size=3, legend.show = FALSE) +
    tm_graticules(alpha=0.4) 
  tmap_save(tmap5, paste0(final_outputs,species_binomial,'_final_adaptive_sensitivity_observed.png'), units='cm', width=30, height=30, asp=0)
  
  cat('> Adaptive sensitivity scores plotted...\n', file=log_file, append=T)
  
  #Thiessen polygons
  #The Thiessen polygons (or proximity interpolation) can be created using spatstat’s dirichlet function.
  
  # Create a tessellated surface
  th  <-  as(dirichlet(as.ppp(vulnerability)), "SpatialPolygons")
  
  # The dirichlet function does not carry over projection information
  # requiring that this information be added manually
  proj4string(th) <- proj4string(vulnerability)
  
  # The tessellated surface does not store attribute information
  # from the point data layer. We'll use the over() function (from the sp
  # package) to join the point attributes to the tesselated surface via
  # a spatial join. The over() function creates a dataframe that will need to
  # be added to the `th` object thus creating a SpatialPolygonsDataFrame object
  th.z     <- over(th, vulnerability, fn=mean)
  th.spdf  <-  SpatialPolygonsDataFrame(th, th.z)
  
  # Finally, we'll clip the tessellated  surface to the Texas boundaries
  th.clp   <- raster::intersect(cropped_shapefile,th.spdf)
  
  # Map the data
  # png(filename=paste0('-outputs-/',species_binomial,'/',species_binomial,'_Thiessen_polygons.png'), type='cairo', units='cm', width=30, height=30, pointsize=10, res=300)
  # tm_shape(th.clp) + 
  #   tm_polygons(col="adaptive_sensitivity", palette="-RdYlGn", auto.palette.mapping=FALSE, title="") +
  #   tm_layout(main.title = "Thiessen polygons", main.title.position = "center")
  # # tm_legend(legend.outside=TRUE)
  # dev.off()
  
  #IDW
  #The IDW output is a raster. This requires that we first create an empty raster grid, then interpolate the precipitation values to each unsampled grid cell. An IDW power value of 2 (idp=2.0) will be used.
  library(gstat) # Use gstat's idw routine
  library(sp)    # Used for the spsample function
  
  # Create an empty grid where n is the total number of cells
  grd              <- as.data.frame(spsample(vulnerability, "regular", n=1000000))
  names(grd)       <- c("X", "Y")
  coordinates(grd) <- c("X", "Y")
  gridded(grd)     <- TRUE  # Create SpatialPixel object
  fullgrid(grd)    <- TRUE  # Create SpatialGrid object
  
  # Add vulnerability's projection information to the empty grid
  proj4string(vulnerability) <- proj4string(vulnerability) # Temp fix until new proj env is adopted
  proj4string(grd) <- proj4string(vulnerability)
  
  # Interpolate the grid cells using a power value of 2 (idp=2.0)
  vulnerability.idw <- gstat::idw(adaptive_sensitivity ~ 1, vulnerability, newdata=grd, idp=2.0)
  
  # Convert to raster object then clip to Texas
  r       <- raster(vulnerability.idw)
  r.m     <- mask(r, cropped_shapefile)
  
  # Plot
  tmap6 <- tm_shape(r.m) + 
    tm_raster(palette = "Greens", style="cont", breaks=c(seq(1,10)), auto.palette.mapping = FALSE,
              title="") + 
    tm_shape(vulnerability) + tm_dots(size=0.25, shape=21) +
    tm_layout(main.title = "Adaptive sensitivity - interpolated", main.title.position = "center", main.title.size=2) + 
    tm_legend(outside = TRUE, legend.text.size=1.3) +
    tm_shape(cropped_shapefile) + tm_borders("grey20", lwd = .6)+ 
    tm_legend(outside = TRUE) +
    
	tm_shape(adaptive_sensitivity_upper_q) +
    tm_dots(col="adaptive_sensitivity", shape=1, palette = "orange2", style="cont", auto.palette.mapping = FALSE,
            title="", size=3, legend.show = FALSE) +
    tm_shape(adaptive_sensitivity_lower_q) +
    tm_dots(col="adaptive_sensitivity", shape=1, palette = "green4", style="cont", auto.palette.mapping = FALSE,
            title="", size=3, legend.show = FALSE) +
    tm_graticules(alpha=0.4) 
  tmap_save(tmap6, paste0(final_outputs,species_binomial,'_final_adaptive_sensitivity_interpolated.png'), units='cm', width=30, height=30, asp=0)
  
  
  # Landscape barriers
    # plot the observed points
  tmap7 <- tm_shape(cropped_shapefile) + tm_polygons() +
    tm_shape(vulnerability) +
    tm_dots(col="landscape_barriers", shape=21, palette = "-viridis", style="cont", breaks=c(seq(1,10)), auto.palette.mapping = FALSE,
            title="", size=0.25) +
    tm_text("landscape_barriers", just="left", xmod=.5, size = 0.0001) + 
    tm_layout(main.title = "Landscape barriers - observed", main.title.position = "center", main.title.size=2.5) + 
    tm_legend(outside = TRUE, legend.text.size=1.3) + 
    tm_legend(outside = TRUE) +
    
	tm_shape(landscape_barriers_upper_q) +
    tm_dots(col="landscape_barriers", shape=1, palette = "orange2", style="cont", auto.palette.mapping = FALSE,
            title="", size=3, legend.show = FALSE) +
    tm_shape(landscape_barriers_lower_q) +
    tm_dots(col="landscape_barriers", shape=1, palette = "green4", style="cont", auto.palette.mapping = FALSE,
            title="", size=3, legend.show = FALSE) +
    tm_graticules(alpha=0.4) 
  tmap_save(tmap7, paste0(final_outputs,species_binomial,'_final_landscape_barriers_observed.png'), units='cm', width=30, height=30, asp=0)
  
  cat('> Landscape barriers scores saved and plotted...\n', file=log_file, append=T)
  
  #Thiessen polygons
  #The Thiessen polygons (or proximity interpolation) can be created using spatstat’s dirichlet function.
  
  # Create a tessellated surface
  th  <-  as(dirichlet(as.ppp(vulnerability)), "SpatialPolygons")
  
  # The dirichlet function does not carry over projection information
  # requiring that this information be added manually
  proj4string(th) <- proj4string(vulnerability)
  
  # The tessellated surface does not store attribute information
  # from the point data layer. We'll use the over() function (from the sp
  # package) to join the point attributes to the tesselated surface via
  # a spatial join. The over() function creates a dataframe that will need to
  # be added to the `th` object thus creating a SpatialPolygonsDataFrame object
  th.z     <- over(th, vulnerability, fn=mean)
  th.spdf  <-  SpatialPolygonsDataFrame(th, th.z)
  
  # Finally, we'll clip the tessellated  surface to the Texas boundaries
  th.clp   <- raster::intersect(cropped_shapefile,th.spdf)
  
  # Map the data
  # png(filename=paste0('-outputs-/',species_binomial,'/',species_binomial,'_Thiessen_polygons.png'), type='cairo', units='cm', width=30, height=30, pointsize=10, res=300)
  # tm_shape(th.clp) + 
  #   tm_polygons(col="landscape_barriers", palette="-RdYlGn", auto.palette.mapping=FALSE, title="") +
  #   tm_layout(main.title = "Thiessen polygons", main.title.position = "center")
  # # tm_legend(legend.outside=TRUE)
  # dev.off()
  
  #IDW
  #The IDW output is a raster. This requires that we first create an empty raster grid, then interpolate the precipitation values to each unsampled grid cell. An IDW power value of 2 (idp=2.0) will be used.
  library(gstat) # Use gstat's idw routine
  library(sp)    # Used for the spsample function
  
  # Create an empty grid where n is the total number of cells
  grd              <- as.data.frame(spsample(vulnerability, "regular", n=1000000))
  names(grd)       <- c("X", "Y")
  coordinates(grd) <- c("X", "Y")
  gridded(grd)     <- TRUE  # Create SpatialPixel object
  fullgrid(grd)    <- TRUE  # Create SpatialGrid object
  
  # Add vulnerability's projection information to the empty grid
  proj4string(vulnerability) <- proj4string(vulnerability) # Temp fix until new proj env is adopted
  proj4string(grd) <- proj4string(vulnerability)
  
  # Interpolate the grid cells using a power value of 2 (idp=2.0)
  vulnerability.idw <- gstat::idw(landscape_barriers ~ 1, vulnerability, newdata=grd, idp=2.0)
  
  # Convert to raster object then clip to Texas
  r       <- raster(vulnerability.idw)
  r.m     <- mask(r, cropped_shapefile)
  
  # Plot
  tmap8 <- tm_shape(r.m) + 
    tm_raster(palette = "-viridis", style="cont", breaks=c(seq(1,10)), auto.palette.mapping = FALSE,
              title="") + 
    tm_shape(vulnerability) + tm_dots(size=0.25, shape=21) +
    tm_layout(main.title = "Landscape barriers - interpolated", main.title.position = "center", main.title.size=2) + 
    tm_legend(outside = TRUE, legend.text.size=1.3) +
    tm_shape(cropped_shapefile) + tm_borders("grey20", lwd = .6)+ 
    tm_legend(outside = TRUE) +
    
	tm_shape(landscape_barriers_upper_q) +
    tm_dots(col="landscape_barriers", shape=1, palette = "orange2", style="cont", auto.palette.mapping = FALSE,
            title="", size=3, legend.show = FALSE) +
    tm_shape(landscape_barriers_lower_q) +
    tm_dots(col="landscape_barriers", shape=1, palette = "green4", style="cont", auto.palette.mapping = FALSE,
            title="", size=3, legend.show = FALSE) +
    tm_graticules(alpha=0.4) 
  tmap_save(tmap8, paste0(final_outputs,species_binomial,'_final_landscape_barriers_interpolated.png'), units='cm', width=30, height=30, asp=0)
  
  
  # Plot the 4 panels together for observed and interpolated data...
  
  tmap_4_panels_observed <- tmap_arrange(tmap1, tmap3, tmap5, tmap7, widths = c(1, 1))
  tmap_4_panels_interpolated <- tmap_arrange(tmap2, tmap4, tmap6, tmap8, widths = c(1, 1))
  
  tmap_save(tmap_4_panels_observed, paste0(final_outputs,species_binomial,'_final_4_maps_observed.png'), units='cm', width=30, height=30, asp=0)
  tmap_save(tmap_4_panels_interpolated, paste0(final_outputs,species_binomial,'_final_4_maps_interpolated.png'), units='cm', width=30, height=30, asp=0)
  cat('> Plotting composite panels of Exposure, Neutral/Adaptive diversity, Landscape barriers...\n\n', file=log_file, append=T)
  
  # Plotting Vulnerability
  # plot the observed points
  tmap9 <- tm_shape(cropped_shapefile) + tm_polygons() +
    tm_shape(vulnerability) +
    tm_dots(col="population_vulnerability", shape=21, palette = "-RdYlGn", style="cont", breaks=c(seq(1,10)), auto.palette.mapping = FALSE,
            title="", size=0.25) +
    tm_text("population_vulnerability", just="left", xmod=.5, size = 0.0001) + 
    tm_layout(main.title = "Population vulnerability - observed", main.title.position = "center", main.title.size=2.5) + 
    tm_legend(outside = TRUE, legend.text.size=1.3) + 
    tm_legend(outside = TRUE) +
    tm_graticules(alpha=0.4)
    tmap_save(tmap9, paste0(final_outputs,species_binomial,'_final_population_vulnerability_observed.png'), units='cm', width=30, height=30, asp=0)
  
  cat('> Population vulnerability scores calculated, saved and plotted...\n', file=log_file, append=T)
  
  #Thiessen polygons
  #The Thiessen polygons (or proximity interpolation) can be created using spatstat’s dirichlet function.
  
  # Create a tessellated surface
  th  <-  as(dirichlet(as.ppp(vulnerability)), "SpatialPolygons")
  
  # The dirichlet function does not carry over projection information
  # requiring that this information be added manually
  proj4string(th) <- proj4string(vulnerability)
  
  # The tessellated surface does not store attribute information
  # from the point data layer. We'll use the over() function (from the sp
  # package) to join the point attributes to the tesselated surface via
  # a spatial join. The over() function creates a dataframe that will need to
  # be added to the `th` object thus creating a SpatialPolygonsDataFrame object
  th.z     <- over(th, vulnerability, fn=mean)
  th.spdf  <-  SpatialPolygonsDataFrame(th, th.z)
  
  # Finally, we'll clip the tessellated  surface to the Texas boundaries
  th.clp   <- raster::intersect(cropped_shapefile,th.spdf)
  
  # Map the data
  # png(filename=paste0('-outputs-/',species_binomial,'/',species_binomial,'_Thiessen_polygons.png'), type='cairo', units='cm', width=30, height=30, pointsize=10, res=300)
  # tm_shape(th.clp) + 
  #   tm_polygons(col="population_vulnerability", palette="-RdYlGn", auto.palette.mapping=FALSE, title="") +
  #   tm_layout(main.title = "Thiessen polygons", main.title.position = "center")
  # # tm_legend(legend.outside=TRUE)
  # dev.off()
  
  #IDW
  #The IDW output is a raster. This requires that we first create an empty raster grid, then interpolate the precipitation values to each unsampled grid cell. An IDW power value of 2 (idp=2.0) will be used.
  library(gstat) # Use gstat's idw routine
  library(sp)    # Used for the spsample function
  
  # Create an empty grid where n is the total number of cells
  grd              <- as.data.frame(spsample(vulnerability, "regular", n=1000000))
  names(grd)       <- c("X", "Y")
  coordinates(grd) <- c("X", "Y")
  gridded(grd)     <- TRUE  # Create SpatialPixel object
  fullgrid(grd)    <- TRUE  # Create SpatialGrid object
  
  # Add vulnerability's projection information to the empty grid
  proj4string(vulnerability) <- proj4string(vulnerability) # Temp fix until new proj env is adopted
  proj4string(grd) <- proj4string(vulnerability)
  
  # Interpolate the grid cells using a power value of 2 (idp=2.0)
  vulnerability.idw <- gstat::idw(population_vulnerability ~ 1, vulnerability, newdata=grd, idp=2.0)
  
  # Convert to raster object then clip to Texas
  r       <- raster(vulnerability.idw)
  r.m     <- mask(r, cropped_shapefile)
  
  # Plot
  tmap10 <- tm_shape(r.m) + 
    tm_raster(palette = "-RdYlGn", style="cont", breaks=c(seq(1,10)), auto.palette.mapping = FALSE,
              title="") + 
    tm_shape(vulnerability) + tm_dots(size=0.25, shape=21) +
    tm_layout(main.title = "Population vulnerability - interpolated", main.title.position = "center", main.title.size=2.5) + 
    tm_legend(outside = TRUE, legend.text.size=1.3) +
    tm_shape(cropped_shapefile) + tm_borders("grey20", lwd = .6)+ 
    tm_legend(outside = TRUE) +
    tm_graticules(alpha=0.4) 
      tmap_save(tmap10, paste0(final_outputs,species_binomial,'_final_population_vulnerability_interpolated.png'), units='cm', width=30, height=30, asp=0)
  
  cat('> Final Population vulnerability scores interpolated and plotted...\n', file=log_file, append=T)

# now plot the max and min values per population
coordinates(vulnerability_max_min) <- ~ LONG + LAT

custom_palette <- c('#35d213','#f38400','#037fdd','#a008c0')

  sf::sf_use_s2(FALSE) # turn off spherical geometry s2 processing in sf - sometimes on large datasets this can cause problems
  tmap11 <- tm_shape(cropped_shapefile) + tm_polygons() +
    tm_shape(vulnerability_max_min) +
    tm_dots(col="max", shape=21, palette = custom_palette, style="cont", breaks=c(seq(1,10)), auto.palette.mapping = FALSE,
            title="", size=0.25) +
    tm_text("max", just="left", xmod=.5, size = 0.0001) + 
   	tm_layout(main.title = "Maximum ranked metric", main.title.position = "center", main.title.size=2) + 
    tm_legend(outside = TRUE, legend.text.size=1.2) + 
    tm_legend(outside = TRUE) +
    tm_graticules(alpha=0.4)
   tmap_save(tmap11, paste0(final_outputs,species_binomial,'_max_complementarity.png'), units='cm', width=20, height=20, asp=0)
  
    tmap12 <- tm_shape(cropped_shapefile) + tm_polygons() +
    tm_shape(vulnerability_max_min) +
    tm_dots(col="min", shape=21, palette = custom_palette, style="cont", breaks=c(seq(1,10)), auto.palette.mapping = FALSE,
            title="", size=0.25) +
    tm_text("min", just="left", xmod=.5, size = 0.0001) + 
   	tm_layout(main.title = "Minimum ranked metric", main.title.position = "center", main.title.size=2) + 
tm_legend(outside = TRUE, legend.text.size=1.2) + 
    tm_legend(outside = TRUE) +
    tm_graticules(alpha=0.4)
   tmap_save(tmap12, paste0(final_outputs,species_binomial,'_min_complementarity.png'), units='cm', width=20, height=20, asp=0)
  
  cat('> Plotting composite panels of Maximum and Minumum ranked metrics per population...\n', file=log_file, append=T)
  tmap_2_panels_max_min <- tmap_arrange(tmap11, tmap12, widths = c(1, 1))
  tmap_save(tmap_2_panels_max_min, paste0(final_outputs,species_binomial,'_max_min_per_population.png'), units='cm', width=30, height=15, asp=0)

  cat('> Population vulnerability completed successfully...\n\n', file=log_file, append=T)
 
 # and write out the final population vulnerability score as a raster...
 writeRaster(r.m, paste0('./-outputs-/',species_binomial, '/Population_vulnerability/',species_binomial,'_population_vulnerability.asc'), overwrite=TRUE) 
}
  
#############################################################################################################################################################################################
summary_pdfs <- function(species_binomial) {
#############################################################################################################################################################################################

  # Create final summary PDFs of all outputs for each species
  
  library (grobblR) # for making nice summary PDFs
  library(stringr)
  
  rm(list=ls(all=TRUE))

  root_dir <- ('$YOUR_WORK_DIR')
  setwd(root_dir)
  
 # read args
  args <- commandArgs()
  print(args)
  species_binomial <- args[8]  # This may vary between systems depending on your HPC setup, the list of arguments will be printed at the beginning of your SLURM job logfile so if the jobs fail, make sure that this number matches the number in args[] that matches your species name
  
  # set params file
  params_all <- read.delim('./Params.tsv')
  
  # Species in the loop and line nums in params file defined in the run_life_on_the_edge.sh script
  params <- params_all[which(params_all$species_binomial==species_binomial),]
  species_binomial <- params$species_binomial
  log_file <- paste0('-outputs-/log_files/',species_binomial,'.log')
  sensitivity_path <- paste0('./-outputs-/',species_binomial,'/Sensitivity/')
  output_path <- paste0(sensitivity_path,'Adaptive_sensitivity/')
    
    ############################
    
    # Summary PDFs
    
    cat('-------------------------------------------------------------------------------\n', file=log_file, append=T)
    cat('Generating final PDFs with all summary statistics, plots and information...  \n', file=log_file, append=T)
    cat('-------------------------------------------------------------------------------\n', file=log_file, append=T)
    
    
    cat('Summarising relevant outputs to create summary PDFs...  \n', file=log_file, append=T)
    
    # Define images/text we want to have in the summary PDF

    #LOtE logo
    logo <- paste0('./-data-/map_data/LOtE_logo.png')

    # Exposure grob
    presence_records <- paste0('./-outputs-/',species_binomial,'/Exposure/SDMs/',species_binomial,'_presence_records.png')
	env_dissimilarity <- paste0('./-outputs-/',species_binomial,'/Exposure/',species_binomial,'_environmental_dissimilarity_current_and_future.png')
    sdm_current_future <- paste0('./-outputs-/',species_binomial,'/Exposure/SDMs/',species_binomial,'_SDMs_current_and_future.png')
    exposure <- paste0('./-outputs-/',species_binomial,'/Population_vulnerability/',species_binomial,'_final_exposure_observed.png')

    exposure_table <- eval(parse(text=(paste0('read.csv("./-outputs-/',species_binomial,'/Exposure/',species_binomial,'_Exposure.csv")'))))
    exposure_table$pop <- c(1:nrow(exposure_table))
    exposure_table <- exposure_table[,c(17,11,13,15,16)]
    names(exposure_table) <- c('Pop', 'SDM exposure', 'env1 exposure', 'env2 exposure', 'exposure')
    
    # text info extracted from logfile
    # box 1
    log_file_read <- readLines(log_file)
    N_georef_samples <- grep("\\Number of georeferenced",log_file_read, value=TRUE)
    N_gbif_records <- grep("\\Number of GBIF",log_file_read, value=TRUE)
  
  # if loop to take user supplied presences if supplied (rather than downloaded gbif)
    if ((params$user_specified_presences) == 'yes'){
        user_specified_presences <- eval(parse(text=(paste0('read.csv("',params$user_specified_presences,'")'))))
        N_gbif_records <- nrow(user_specified_presences)
    }
    N_presences_pre_rarefication <- grep("\\Total number of presences before spatial rarefication",log_file_read, value=TRUE)
    N_presences_post_rarefication <- grep("\\Total number of presences after spatial rarefication",log_file_read, value=TRUE)

      if (params$skip_sdm=='yes') { 
      cat('Skipping summaries of SDM analyses as they have been performed outside of the LotE toolbox...\n\n', file=log_file, append=T)
		
			text_box_1 <- paste0('SPATIAL DATA\n', N_georef_samples, '\n', N_gbif_records,'\n', N_presences_pre_rarefication, '\n',N_presences_post_rarefication, '\n')
    
    exposure_1_grob = grob_layout(
      grob_row(border = TRUE, grob_col(text_box_1,aes_list=ga_list(cell_text_cex = 0.3, text_just="left", text_v_just = 1))),
      grob_row(border = FALSE, grob_col(border = FALSE, presence_records,aes_list = ga_list()), grob_col(border = FALSE, sdm_current_future)),
      grob_row(border = FALSE, grob_col(border = FALSE, env_dissimilarity)),
       height = 150, width = 125) 
    # to pdf
    grob_to_pdf(list(exposure_1_grob),
                file_name =  paste0('./-outputs-/',species_binomial,'/Exposure/Exposure_summary_1.pdf'))
        
    exposure_2_grob = grob_layout(
      grob_row(border = FALSE, grob_col(border = FALSE, exposure_table),grob_col(border = FALSE, exposure)),
      height = 150, width = 125) 
    # to pdf
    grob_to_pdf(list(exposure_2_grob),
                file_name =  paste0('./-outputs-/',species_binomial,'/Exposure/Exposure_summary_2.pdf'))

    } else { 

    bg_points <- paste0('./-outputs-/',species_binomial,'/Exposure/SDMs/',species_binomial,'_background_points.png')
    sdm_predictors <- paste0('./-outputs-/',species_binomial,'/Exposure/SDMs/',species_binomial,'_SDM_predictors.png')
    variable_importance <- paste0('./-outputs-/',species_binomial,'/Exposure/SDMs/',species_binomial,'_biomod_variable_importance_general.png')
    
    # box 1 (if SDMs are actually run in LotE)
    N_background_points1 <- (grep("\\ background points generated in a buffer radius of",log_file_read, value=TRUE)[1]); N_background_points2 <- (sub(" background points generated in a buffer radius of.*", "", N_background_points1)); N_background_points3 <- paste0('> Number of background points:',N_background_points2)
    mapping_extent1 <- (grep("extent",log_file_read, value=TRUE)[1]); mapping_extent2 <- (sub(".*extent     :", "", mapping_extent1));mapping_extent3 <- (sub("crs.*", "", mapping_extent2)); mapping_extent4 <- paste0('> Mapping extent:',mapping_extent3)
    resolution1 <- (grep("\\Current environmental data",log_file_read, value=TRUE)[1]); resolution2 <- (sub(".*at", "", resolution1));resolution3 <- paste0("> Resolution:",resolution2)
	
	# box 2 (SDMs)
    N_reps <- paste0("Number of replicates per SDM algorithm: ",params$sdm_reps_per_algorithm)
    data_split_percentage <- paste0("Data split: training/testing: ",params$data_split_percentage,"%")
    AUC_threshold <- paste0("Min ROC threshold for model to be included in final ensemble:",params$ROC_min)
    TSS_threshold <- paste0("Min TSS threshold for model to be included in final ensemble:",params$TSS_min)
    models_in_final_ensemble <- paste0("Algorithms:",params$biomod_algorithms)
	  
	title <- paste0(species_binomial)
	
	text_box_1 <- paste0('SPATIAL DATA\n', N_georef_samples, '\n', N_gbif_records,'\n', N_presences_pre_rarefication, '\n',N_presences_post_rarefication, '\n',N_background_points3, '\n',mapping_extent4, '\n',resolution3,'\n')
    text_box_2 <-paste0('SDMs\n', N_reps, '\n', data_split_percentage, '\n',AUC_threshold, '\n',TSS_threshold, '\n',models_in_final_ensemble, '\n')
    text_box_3 <-  paste0('Future environmental data from: ',params$future_climate_data_path, '\n')

	   exposure_1_grob = grob_layout(
        grob_row(border = FALSE, grob_col(border = FALSE, logo, aes_list=ga_list(aspect_ratio_multiplier=0.3))),
      grob_row(border = FALSE, grob_col(title, aes_list=ga_list(cell_text_cex = 1.2, text_just="center", text_v_just = 1))),
       grob_row(border = TRUE, grob_col(text_box_1,aes_list=ga_list(cell_text_cex = 0.3, text_just="left", text_v_just = 1,)),grob_col(text_box_2,aes_list=ga_list(cell_text_cex = 0.3, text_just="left", text_v_just = 1))),
        height = 150, width = 125)
    # to pdf
    grob_to_pdf(list(exposure_1_grob),
                file_name =  paste0('./-outputs-/',species_binomial,'/Exposure/Exposure_summary_1.pdf'))
   
    	   exposure_2_grob = grob_layout(
       grob_row(border = FALSE, grob_col(border = FALSE, presence_records),grob_col(border = FALSE, bg_points)),
      grob_row(border = FALSE, grob_col(border = FALSE, title='SDM predictors', title_height=3, sdm_predictors)),
       height = 150, width = 125) 
    # to pdf
    grob_to_pdf(list(exposure_2_grob),
                file_name =  paste0('./-outputs-/',species_binomial,'/Exposure/Exposure_summary_2.pdf'))

    exposure_3_grob = grob_layout(
      grob_row(border=FALSE, grob_col(border = FALSE, sdm_current_future)),
      grob_row(border=FALSE, grob_col(border = FALSE, variable_importance, title='Variable importance', title_height=3)), 
      height = 150, width = 125) 
    # to pdf
    grob_to_pdf(list(exposure_3_grob),
                file_name =  paste0('./-outputs-/',species_binomial,'/Exposure/Exposure_summary_3.pdf'))
    
      exposure_4_grob = grob_layout(
      grob_row(border = TRUE, grob_col(text_box_3,aes_list=ga_list(cell_text_cex = 0.3, text_just="left", text_v_just = 1))),
      grob_row(border = FALSE, grob_col(border = FALSE, env_dissimilarity, title='Environmental dissimilarity', title_height=3)),
      height = 150, width = 125) 
    # to pdf
    grob_to_pdf(list(exposure_4_grob),
                file_name =  paste0('./-outputs-/',species_binomial,'/Exposure/Exposure_summary_4.pdf'))

 exposure_5_grob = grob_layout(
      grob_row(border = FALSE, grob_col(border = FALSE, exposure_table, title='Exposure', title_height=3),grob_col(border = FALSE, exposure)),
      height = 150, width = 125) 
    # to pdf
    grob_to_pdf(list(exposure_5_grob),
                file_name =  paste0('./-outputs-/',species_binomial,'/Exposure/Exposure_summary_5.pdf'))
}
         
    # Sensitivity grob

# get the info for numbers of adapted individuals (this is done regardless if skip_gea is used)
    lhs1 <- paste0('n_',params$category_1,sep='')
    rhs1 <- paste0("nrow(read.csv('./-outputs-/",species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_categorised_individuals_',params$category_1,".csv'))")
    eq1  <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
    eval(parse(text=eq1))
    
    lhs2 <- paste0('n_',params$category_2,sep='')
    rhs2 <- paste0("nrow(read.csv('./-outputs-/",species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_categorised_individuals_',params$category_2,".csv'))")
    eq2  <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
    eval(parse(text=eq2))
    
    lhs3 <- paste0('n_intermediate',sep='')
    rhs3 <- paste0("nrow(read.csv('./-outputs-/",species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,"_categorised_individuals_intermediate.csv'))")
    eq3  <- paste(paste(lhs3, rhs3, sep=' <- '), collapse='; ')
    eval(parse(text=eq3))
 
    category_1 <- paste0('Number of ', params$category_1,' adapted individuals: ',eval(parse(text=lhs1)))
    category_2 <- paste0('Number of ', params$category_2,' adapted individuals: ',eval(parse(text=lhs2)))
    intermediate <- paste0('Number of intermediate (i.e. not locally adapted) individuals: ',n_intermediate)    
        
   if (params$skip_gea=='yes') { 
      cat('Skipping summaries of Genotype Environment Association analysis (LFMM and RDA) as they have been performed outside of the LotE toolbox...\n\n', file=log_file, append=T)
 	text_box_5 <- paste0('LOCALLY ADAPTED INDIVIDUALS\n', category_1, '\n',category_2,'\n', intermediate, '\n')
   } else { 
    
    # pop structure
    snmf_barplot <- paste0('./-outputs-/',species_binomial,'/Sensitivity/',species_binomial,'_pop_structure_snmf_barplot.png')
    snmf_cross_entropy <- paste0('./-outputs-/',species_binomial,'/Sensitivity/',species_binomial,'_pop_structure_snmf_cross_entropy.png')
    pca_and_eigenvalues <- paste0('./-outputs-/',species_binomial,'/Sensitivity/',species_binomial,'_pop_structure_PCA.png')
    # lfmm
    env_correlations <- paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_env_correlations.png')
    env1_p_values <- paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_LFMM_p_value_distribution_',params$env_predictor_1,'.png')
    env2_p_values <- paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_LFMM_p_value_distribution_',params$env_predictor_2,'.png')
    # RDA
    env_p_values <- paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_RDA_p_value_distribution.png')
    histogram_loadings_sd <- paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_RDA_histogram_loadings_SD_',params$rda_SD,'.png')
    rda_plot <- paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_RDA_plot.png')
    rda_snps <- paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_RDA_SNPs.png')
    
    # box 3
    # read in the output files from previous RDA and LFMM analyses
    #RDA SD
    RDA_adaptive_list <- read.csv(paste0(output_path,species_binomial,'_RDA_candidate_SNPs_by_predictor_SD_',params$rda_SD_threshold,'.csv'))
    #RDA_adaptive_list_gif_adjusted <- read.csv(paste0(output_path,species_binomial,'_RDA_candidate_SNPs',params$rda_SD_threshold,'.csv'))
    LFMM_adaptive_list <- read.csv(paste0(output_path,species_binomial,'_LFMM_candidate_SNPs_by_predictor_FDR_',params$lfmm_FDR_threshold,'.csv'))
 #   LFMM_candidate_loci_FDR_0.1 <- length(LFMM_adaptive_list$LFMM.FDR.1)
 #   LFMM_candidate_loci_FDR_0.05 <- length(na.omit(LFMM_adaptive_list$LFMM.FDR.05))
 #   LFMM_candidate_loci_FDR_0.01 <- length(na.omit(LFMM_adaptive_list$LFMM.FDR.01))
 #   RDA_candidate_loci_FDR_0.1 <- length(RDA_adaptive_list_gif_adjusted$rda.FDR.1)
 #   RDA_candidate_loci_FDR_0.05 <- length(na.omit(RDA_adaptive_list_gif_adjusted$rda.FDR.05))
  #  RDA_candidate_loci_FDR_0.01 <- length(na.omit(RDA_adaptive_list_gif_adjusted$rda.FDR.01))
    
    RDA_candidate_loci_env_pred_1 <- grep("\\Number of RDA candidate SNPs for env. predictor 1",log_file_read, value=TRUE)
    RDA_candidate_loci_env_pred_2 <- grep("\\Number of RDA candidate SNPs for env. predictor 2",log_file_read, value=TRUE)
    RDA_candidate_loci_stat_significant <- grep("\\Number of statistically significant RDA candidate SNPs",log_file_read, value=TRUE)
    RDA_candidate_loci_stat_non_significant <- grep("\\Number of non-statistically significant RDA candidate SNPs",log_file_read, value=TRUE)
    LFMM_candidate_loci_env_pred_1 <- grep("\\Number of LFMM candidate SNPs for env. predictor 1",log_file_read, value=TRUE)
    LFMM_candidate_loci_env_pred_2 <- grep("\\Number of LFMM candidate SNPs for env. predictor 2",log_file_read, value=TRUE)
    LFMM_candidate_loci_stat_significant <- grep("\\Number of statistically significant LFMM candidate SNPs",log_file_read, value=TRUE)
    LFMM_candidate_loci_stat_non_significant <- grep("\\Number of non-statistically significant LFMM candidate SNPs",log_file_read, value=TRUE)

    
   # LFMM_candidates <- as.character(paste0('Number of LFMM candidates FDR<0.1: ',LFMM_candidate_loci_FDR_0.1,' \nNumber of LFMM candidates FDR<0.05: ',LFMM_candidate_loci_FDR_0.05,' \nNumber of LFMM candidates FDR<0.01: ',LFMM_candidate_loci_FDR_0.01,''))
   # RDA_candidates <- as.character(paste0('\nNumber of RDA candidates loci FDR<0.1: ',RDA_candidate_loci_FDR_0.1,' \nNumber of RDA candidates FDR<0.05: ',RDA_candidate_loci_FDR_0.05,'\nNumber of RDA candidates FDR<0.01: ',RDA_candidate_loci_FDR_0.01,''))
   # RDA_candidates_SD_threshold <-  as.character(paste0('\nNumber of RDA candidates SD<',params$rda_SD,': ',nrow(RDA_adaptive_list),''))
     
    text_box_4 <- paste0('ADAPTIVE LOCI:\n', RDA_candidate_loci_env_pred_1, RDA_candidate_loci_env_pred_1, RDA_candidate_loci_stat_significant, RDA_candidate_loci_stat_non_significant, LFMM_candidate_loci_env_pred_1, LFMM_candidate_loci_env_pred_1, LFMM_candidate_loci_stat_significant, LFMM_candidate_loci_stat_non_significant,'\n')
	text_box_5 <- paste0('LOCALLY ADAPTED INDIVIDUALS:\n', category_1, '\n',category_2,'\n', intermediate, '\n')

    sensitivity_1_grob = grob_layout(
      grob_row(border = TRUE, grob_col(text_box_4,aes_list=ga_list(cell_text_cex = 0.3, text_just="left", text_v_just = 1))),
      grob_row(border = FALSE, grob_col(border = FALSE, snmf_barplot)),
      grob_row(border = FALSE, grob_col(border = FALSE, snmf_cross_entropy), grob_col(border = FALSE, pca_and_eigenvalues)),
      height = 150, width = 125) 
    grob_to_pdf(list(sensitivity_1_grob),
                file_name =  paste0('./-outputs-/',species_binomial,'/Sensitivity/Sensitivity_1_summary.pdf'))
    
    sensitivity_2_grob = grob_layout(
      grob_row(border = FALSE, grob_col(border = FALSE, env_correlations, title='Environmental predictor correlations', title_height=3)),
      grob_row(border = FALSE, grob_col(border = FALSE, env1_p_values, title=paste0(params$env_predictor_1,' LFMM p-values'), title_height=3),grob_col(border = FALSE, env2_p_values, title=paste0(params$env_predictor_2,' LFMM p-values'), title_height=3)),
      height = 150, width = 125) 
    grob_to_pdf(list(sensitivity_2_grob),
                file_name =  paste0('./-outputs-/',species_binomial,'/Sensitivity/Sensitivity_2_summary.pdf'))
    
    sensitivity_3_grob = grob_layout(
      grob_row(border = FALSE, grob_col(border = FALSE, env_p_values, title = 'RDA p-values', title_height=3)),
      grob_row(border = FALSE, grob_col(border = FALSE, histogram_loadings_sd, title = 'RDA loadings', title_height=3),grob_col(border = FALSE, rda_snps, title = 'RDA candidate SNPs', title_height=3)),
      grob_row(border = FALSE, grob_col(border = FALSE, rda_plot)),
      height = 150, width = 125) 
    grob_to_pdf(list(sensitivity_3_grob),
                file_name =  paste0('./-outputs-/',species_binomial,'/Sensitivity/Sensitivity_3_summary.pdf'))              
       }
 
 # Below code anyway runs regardless if adaptive SNPs have been provided      
    lhs1 <- paste0('n_',params$category_1,sep='')
    rhs1 <- paste0("nrow(read.csv('./-outputs-/",species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_categorised_individuals_',params$category_1,".csv'))")
    eq1  <- paste(paste(lhs1, rhs1, sep=' <- '), collapse='; ')
    eval(parse(text=eq1))
    
    lhs2 <- paste0('n_',params$category_2,sep='')
    rhs2 <- paste0("nrow(read.csv('./-outputs-/",species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_categorised_individuals_',params$category_2,".csv'))")
    eq2  <- paste(paste(lhs2, rhs2, sep=' <- '), collapse='; ')
    eval(parse(text=eq2))
    
    lhs3 <- paste0('n_intermediate',sep='')
    rhs3 <- paste0("nrow(read.csv('./-outputs-/",species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,"_categorised_individuals_intermediate.csv'))")
    eq3  <- paste(paste(lhs3, rhs3, sep=' <- '), collapse='; ')
    eval(parse(text=eq3))
 
    category_1 <- paste0(params$category_1,' adapted individuals: ',eval(parse(text=lhs1)))
    category_2 <- paste0(params$category_2,' adapted individuals: ',eval(parse(text=lhs2)))
    intermediate <- paste0('intermediate (i.e. not locally adapted) individuals: ',n_intermediate)    
     
    # individual categorisation/sensitivity grob
    ind_categorisation_RDA_plot <- paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_RDA_individual_categorisation.png')
    ind_categorisation_geographic_distribution <- paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_adaptive_categorisation_maps.png')
    ind_categorisation_SDMs <- paste0('./-outputs-/',species_binomial,'/Exposure/SDMs/adaptive_SDMs/',species_binomial,'_binary_SDMs_current_and_future.png')
    
    # genomic offset
    genomic_offset <- paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_genomic_offset_plot.png')

    #ind_categorisation_SDM_var_imp_hot_dry <- paste0('./-outputs-/',species_binomial,'/Exposure/SDMs/adaptive_SDMs/',species_binomial,'_SDM_variable_importance_',params$category_1,'.png')
    #ind_categorisation_SDM_var_imp_cold_wet <- paste0('./-outputs-/',species_binomial,'/Exposure/SDMs/adaptive_SDMs/',species_binomial,'_SDM_variable_importance_',params$category_2,'.png')
    
    lhs3 <- paste0('ind_categorisation_SDM_var_imp_',params$category_1,sep='')
    rhs3 <- paste0("paste0('./-outputs-/",species_binomial,"/Exposure/SDMs/adaptive_SDMs/",species_binomial,"_SDM_variable_importance_",params$category_1,".png')")
    eq3  <- paste(paste(lhs3, rhs3, sep=' <- '), collapse='; ')
    eval(parse(text=eq3))
    
    lhs4 <- paste0('ind_categorisation_SDM_var_imp_',params$category_2,sep='')
    rhs4 <- paste0("paste0('./-outputs-/",species_binomial,"/Exposure/SDMs/adaptive_SDMs/",species_binomial,"_SDM_variable_importance_",params$category_2,".png')")
    eq4  <- paste(paste(lhs4, rhs4, sep=' <- '), collapse='; ')
    eval(parse(text=eq4))
    
    neutral_sensitivity <- paste0('./-outputs-/',species_binomial,'/Population_vulnerability/',species_binomial,'_final_neutral_sensitivity_observed.png')
    adaptive_sensitivity <- paste0('./-outputs-/',species_binomial,'/Population_vulnerability/',species_binomial,'_final_adaptive_sensitivity_observed.png')
    
    neutral_sensitivity_table <- eval(parse(text=(paste0('read.csv("./-outputs-/',species_binomial,'/Sensitivity/Neutral_sensitivity/',species_binomial,'_neutral_sensitivity.csv")'))))
    neutral_sensitivity_table$Neutral_heterozygosity <- round(neutral_sensitivity_table$Neutral_heterozygosity, digits=2)
    neutral_sensitivity_table$Neutral_nucleotide_diversity <- round(neutral_sensitivity_table$Neutral_nucleotide_diversity, digits=2)
    neutral_sensitivity_table$pop <- c(1:nrow(neutral_sensitivity_table))
    neutral_sensitivity_table <- neutral_sensitivity_table[,c(6,3,4,5)]
    neutral_sensitivity_table <- round(neutral_sensitivity_table, digits=2)
    names(neutral_sensitivity_table) <- c('Pop', 'Neutral observed heterozygosity', 'Neutral nucleotide diversity', 'Neutral sensitivity')
    
    adaptive_sensitivity_table <- eval(parse(text=(paste0('read.csv("./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_adaptive_sensitivity.csv")'))))
    adaptive_sensitivity_table$pop <- c(1:nrow(adaptive_sensitivity_table))
    
    # which col names are actually in adaptive sensitivity? grab these and use to select the columns (in case one or more category is not present)
 	 expected_categories <- c(params$category_1, params$category_2,'intermediate','category_1_sensitivity', 'category_2_sensitivity','genomic_offset')
 	 column_names <- colnames(adaptive_sensitivity_table)
 	 actual_categories <- intersect(expected_categories,column_names)

     adaptive_sensitivity_table <- adaptive_sensitivity_table[,c("pop",actual_categories,"adaptive_sensitivity")]
	 adaptive_sensitivity_table <- round(adaptive_sensitivity_table, digits=2)
    
    #names(adaptive_sensitivity_table) <- eval(parse(text=(paste0("c('Pop', '",params$category_1,"_sensitivity', '",params$category_2,"_sensitivity', 'adaptive sensitivity')"))))
    
    LFMM_sensitivity_plot <- paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/-simulations-/LFMM_sensitivity.png')
    RDA_sensitivity_plot <- paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/-simulations-/RDA_sensitivity.png')
    simulation_validation_plot <- paste0('./-outputs-/',species_binomial,'/Sensitivity/Adaptive_sensitivity/',species_binomial,'_adaptive_SNPs_simulation_validation.png')

      sensitivity_4_grob = grob_layout(
#      grob_row(border=FALSE, grob_col(border = TRUE, text_box_5,aes_list=ga_list(cell_text_cex = 0.3, text_just="left", text_v_just = 1))),
      grob_row(border=FALSE, grob_col(border = FALSE, LFMM_sensitivity_plot, title = 'LFMM sensitivity analyses', title_height=3), grob_col(border = FALSE, RDA_sensitivity_plot, title = 'RDA sensitivity analyses', title_height=3)),
      grob_row(border = FALSE, grob_col(border = FALSE, simulation_validation_plot, title = 'Adaptive SNP validation based on simulated data', title_height=3)),
     # grob_row(border = FALSE, grob_col(border = FALSE, ind_categorisation_SDMs)),
    #  grob_row(border = FALSE, grob_col(border = FALSE, ind_categorisation_SDM_var_imp_hot_dry),grob_col(border = FALSE, ind_categorisation_SDM_var_imp_cold_wet)),
      height = 150, width = 100) 
    # to pdf
    grob_to_pdf(list(sensitivity_4_grob),
                file_name =  paste0('./-outputs-/',species_binomial,'/Sensitivity/Sensitivity_4_summary.pdf'))


    sensitivity_5_grob = grob_layout(
#      grob_row(border=FALSE, grob_col(border = TRUE, text_box_5,aes_list=ga_list(cell_text_cex = 0.3, text_just="left", text_v_just = 1))),
      grob_row(border=FALSE, grob_col(border = FALSE, ind_categorisation_RDA_plot, title = 'Individual categorisation in RDA', title_height=3)),
      grob_row(border = FALSE, grob_col(border = FALSE, ind_categorisation_geographic_distribution, title = 'Mapped local adaptations', title_height=3)),
     # grob_row(border = FALSE, grob_col(border = FALSE, ind_categorisation_SDMs)),
    #  grob_row(border = FALSE, grob_col(border = FALSE, ind_categorisation_SDM_var_imp_hot_dry),grob_col(border = FALSE, ind_categorisation_SDM_var_imp_cold_wet)),
      height = 150, width = 100) 
    # to pdf
    grob_to_pdf(list(sensitivity_4_grob),
                file_name =  paste0('./-outputs-/',species_binomial,'/Sensitivity/Sensitivity_5_summary.pdf'))
    
    sensitivity_6_grob = grob_layout(
      grob_row(border = FALSE, grob_col(border = FALSE, genomic_offset)),
      height = 150, width = 100) # to pdf  
    # to pdf
    grob_to_pdf(list(sensitivity_5_grob),
                file_name =  paste0('./-outputs-/',species_binomial,'/Sensitivity/Sensitivity_6_summary.pdf'))

    sensitivity_7_grob = grob_layout(
      grob_row(border = FALSE, grob_col(border = FALSE, neutral_sensitivity_table)), 
      grob_row(border = FALSE, grob_col(border = FALSE, neutral_sensitivity)),
      height = 150, width = 100) # to pdf
    # to pdf
    grob_to_pdf(list(sensitivity_6_grob),
                file_name =  paste0('./-outputs-/',species_binomial,'/Sensitivity/Sensitivity_7_summary.pdf'))
 
    sensitivity_8_grob = grob_layout(
      grob_row(border = FALSE, grob_col(border = FALSE, adaptive_sensitivity_table)), 
      grob_row(border = FALSE, grob_col(border = FALSE, adaptive_sensitivity)),
      height = 150, width = 100) # to pdf
    # to pdf
    grob_to_pdf(list(sensitivity_7_grob),
                file_name =  paste0('./-outputs-/',species_binomial,'/Sensitivity/Sensitivity_8_summary.pdf'))

    # Landscape barriers grob
 
    circuitscape_results <-  paste0('./-outputs-/',species_binomial,'/Landscape_barriers/circuitscape/',species_binomial,'_circuitscape_landscape_connectivity.png')
    landscape_barriers <- paste0('./-outputs-/',species_binomial,'/Population_vulnerability/',species_binomial,'_final_landscape_barriers_observed.png')
	cumulative_resistance_surface <- paste0('./-outputs-/',species_binomial,'/Landscape_barriers/circuitscape/circuitscape_cumulative_layer.png')
    circuitscape_table <- eval(parse(text=(paste0('read.csv("./-outputs-/',species_binomial,'/Landscape_barriers/',species_binomial,'_Landscape_barriers.csv")'))))
    circuitscape_table <- circuitscape_table[,c(1,5,6)]
    circuitscape_table <- round(circuitscape_table, digits=2)
    names(circuitscape_table) <- c('Pop', 'mean_connectivity_normalised', 'landscape barriers')
 
    if (params$skip_circuitscape_layer_parameterisation=='yes') { 
    cat('Skipping summary of Circuitscape connectivity surface parameterisation as it has been performed outside of the LotE toolbox...\n\n', file=log_file, append=T)
    landscape_barriers_1_grob = grob_layout(
      grob_row(border = FALSE, grob_col(border = FALSE, cumulative_resistance_surface)),
      grob_row(border = FALSE, grob_col(border = FALSE, circuitscape_results),grob_col(border = FALSE, landscape_barriers)),
      grob_row(border = FALSE, grob_col(border = FALSE, circuitscape_table)),
      height = 150, width = 100)
    # to pdf
    grob_to_pdf(list(landscape_barriers_grob),
                file_name =  paste0('./-outputs-/',species_binomial,'/Landscape_barriers/Landscape_barriers_1_summary.pdf'))
    }else{ 

    resistance_layers <- paste0('./-outputs-/',species_binomial,'/Landscape_barriers/circuitscape/circuitscape_layers.png')

    landscape_barriers_1_grob = grob_layout(
      grob_row(border = FALSE, grob_col(border = FALSE, resistance_layers, title = 'Circuitscape layer parameterisation and weights', title_height=3)),
      grob_row(border = FALSE, grob_col(border = FALSE, cumulative_resistance_surface)),
      height = 150, width = 100)
    # to pdf
    grob_to_pdf(list(landscape_barriers_1_grob),
                file_name =  paste0('./-outputs-/',species_binomial,'/Landscape_barriers/Landscape_barriers_1_summary.pdf'))
	}
    landscape_barriers_2_grob = grob_layout(
      grob_row(border = FALSE, grob_col(border = FALSE, circuitscape_results)),
      grob_row(border = FALSE, grob_col(border = FALSE, landscape_barriers)),
      height = 150, width = 100)
    # to pdf
    grob_to_pdf(list(landscape_barriers_2_grob),
                file_name =  paste0('./-outputs-/',species_binomial,'/Landscape_barriers/Landscape_barriers_2_summary.pdf'))
    
     landscape_barriers_3_grob = grob_layout(
      grob_row(border = FALSE, grob_col(border = FALSE, circuitscape_table)),
      grob_row(border = FALSE, grob_col(border = FALSE, landscape_barriers)),
      height = 150, width = 100)
    # to pdf
    grob_to_pdf(list(landscape_barriers_3_grob),
                file_name =  paste0('./-outputs-/',species_binomial,'/Landscape_barriers/Landscape_barriers_3_summary.pdf'))

   # Population vulnerability grob
    four_maps_observed <- paste0('./-outputs-/',species_binomial,'/Population_vulnerability/',species_binomial,'_final_4_maps_observed.png')
    #four_maps_interpolated<- paste0('./-outputs-/',species_binomial,'/Population_vulnerability/',species_binomial,'_final_4_maps_interpolated.png')
    min_complementarity<- paste0('./-outputs-/',species_binomial,'/Population_vulnerability/',species_binomial,'_min_complementarity.png')
    max_complementarity<- paste0('./-outputs-/',species_binomial,'/Population_vulnerability/',species_binomial,'_max_complementarity.png')
    population_vulnerability_observed<- paste0('./-outputs-/',species_binomial,'/Population_vulnerability/',species_binomial,'_final_population_vulnerability_observed.png')
    
    population_vulnerability_table <- eval(parse(text=(paste0('read.csv("./-outputs-/',species_binomial,'/Population_vulnerability/',species_binomial,'_Population_vulnerability.csv")'))))
#    population_vulnerability_table$pop <- c(1:nrow(population_vulnerability_table))
#    population_vulnerability_table <- population_vulnerability_table[,c(9,2,3,4,5,6,7)]
    population_vulnerability_table <- round(population_vulnerability_table, digits=2)
    names(population_vulnerability_table) <- c('Pop', 'LAT', 'LONG', 'Exposure', 'Neutral_sensitivity', 'Adaptive_sensitivity', 'Landscape_barriers' ,'Population vulnerability')
     
    population_vulnerability_1_grob = grob_layout(
     grob_row(border = FALSE, grob_col(border = FALSE,population_vulnerability_table)),
      grob_row(border = FALSE, grob_col(border = FALSE, min_complementarity),grob_col(border = FALSE, max_complementarity)),
      height = 150, width = 100)  
    grob_to_pdf(list(population_vulnerability_1_grob),
                file_name =  paste0('./-outputs-/',species_binomial,'/Population_vulnerability/population_vulnerability_1.pdf'))

    population_vulnerability_2_grob = grob_layout(
      grob_row(border = FALSE, grob_col(border = FALSE, population_vulnerability_observed)),
      height = 150, width = 100) 
    grob_to_pdf(list(population_vulnerability_2_grob),
                file_name =  paste0('./-outputs-/',species_binomial,'/Population_vulnerability/population_vulnerability_2.pdf'))
    
    ### combined grob
    # to pdf
if ((params$skip_sdm=='yes') & (params$skip_gea=='yes') & (params$skip_circuitscape_layer_parameterisation=='yes')) { 
    cat('SDM model summaries, LFMM and RDA analyses, and Circuitscape cumulative surface preparation in the final summary PDF are skipped because you chose to supply your SDMs, adaptive SNPs and Circuitscape input resistance layer rather than calculate them here...\n\n', file=log_file, append=T)
    grob_to_pdf(
    list(exposure_1_grob,exposure_2_grob,sensitivity_4_grob,sensitivity_5_grob,sensitivity_6_grob,landscape_barriers_grob,population_vulnerability_1_grob,population_vulnerability_2_grob),
    file_name =  paste0('./-outputs-/',species_binomial,'/Final_summary.pdf'))
    } else { 
if ((params$skip_sdm=='yes') & (params$skip_gea=='yes')) { 
    cat('SDM model summaries, LFMM and RDA analyses in the final summary PDF are skipped because you chose to supply your SDMs and adaptive SNPs rather than calculate them here...\n\n', file=log_file, append=T)
    grob_to_pdf(
    list(exposure_1_grob,exposure_2_grob,sensitivity_4_grob,sensitivity_5_grob,sensitivity_6_grob,landscape_barriers_grob,population_vulnerability_1_grob,population_vulnerability_2_grob),
    file_name =  paste0('./-outputs-/',species_binomial,'/Final_summary.pdf'))
    } else { 
  if (params$skip_gea=='yes') { 
      cat('LFMM and RDA analyses in the final summary PDF are skipped because you chose to supply your adaptive SNPs rather than calculate them here...\n\n', file=log_file, append=T)
    	grob_to_pdf(
      	list(exposure_1_grob,exposure_2_grob,exposure_3_grob,sensitivity_4_grob,sensitivity_5_grob,sensitivity_6_grob,landscape_barriers_grob,population_vulnerability_1_grob,population_vulnerability_2_grob),
      	file_name =  paste0('./-outputs-/',species_binomial,'/Final_summary.pdf'))
		} else {
      if (params$skip_sdm=='yes') { 
     	  cat('SDM model summaries in the final summary PDF are skipped because you chose to supply your SDMs rather than calculate them here...\n\n', file=log_file, append=T)
     	  grob_to_pdf(
      	  list(exposure_1_grob,exposure_2_grob,sensitivity_4_grob,sensitivity_1_grob,sensitivity_2_grob,sensitivity_3_grob,sensitivity_4_grob,sensitivity_5_grob,sensitivity_6_grob,sensitivity_7_grob,landscape_barriers_grob,population_vulnerability_1_grob,population_vulnerability_2_grob),
      	  file_name =  paste0('./-outputs-/',species_binomial,'/Final_summary.pdf'))
    	  } else {

    grob_to_pdf(
      list(exposure_1_grob, exposure_2_grob, exposure_3_grob, exposure_4_grob, exposure_5_grob, sensitivity_1_grob,sensitivity_2_grob,sensitivity_3_grob,sensitivity_4_grob,sensitivity_5_grob,sensitivity_6_grob,sensitivity_7_grob,sensitivity_8_grob,landscape_barriers_1_grob,landscape_barriers_2_grob,population_vulnerability_1_grob,population_vulnerability_2_grob),
      file_name =  paste0('./-outputs-/',species_binomial,'/Final_summary.pdf'))

}
}
}    
}

    cat('DONE!  \n', file=log_file, append=T)
    cat('END... \n\n', file=log_file, append=T)
    cat('Life on the edge pipeline completed for',species_binomial,'at', format(Sys.time(),usetz = TRUE),'\n', file=log_file, append=T)

}
